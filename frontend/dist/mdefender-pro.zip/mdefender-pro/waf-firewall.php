<?php
/**
 * MDefender-Pro Core Firewall & Security Engine
 *
 * @package MDefender-Pro
 */

defined('ABSPATH') || exit;

add_filter('cron_schedules', function($schedules) {
    if (!isset($schedules['monthly'])) {
        $schedules['monthly'] = [
            'interval' => 30 * DAY_IN_SECONDS,
            'display' => __('Once every 30 days', 'mdefender-pro'),
        ];
    }
    return $schedules;
});

if (!defined('WAF_FW_VERSION')) define('WAF_FW_VERSION', '4.3.0');
if (!defined('WAF_FW_PLUGIN_DIR')) define('WAF_FW_PLUGIN_DIR', plugin_dir_path(__FILE__));
if (!defined('WAF_FW_PLUGIN_URL')) define('WAF_FW_PLUGIN_URL', plugin_dir_url(__FILE__));
if (!defined('WAF_FW_MAIN_FILE')) define('WAF_FW_MAIN_FILE', __FILE__);

if (!defined('WAF_FW_TABLE_ATTACKS')) define('WAF_FW_TABLE_ATTACKS', 'waf_attacks');
if (!defined('WAF_FW_TABLE_REQUESTS')) define('WAF_FW_TABLE_REQUESTS', 'waf_requests');
if (!defined('WAF_FW_TABLE_BLACKLIST')) define('WAF_FW_TABLE_BLACKLIST', 'waf_blacklist');
if (!defined('WAF_FW_TABLE_LOGIN_ATTEMPTS')) define('WAF_FW_TABLE_LOGIN_ATTEMPTS', 'waf_login_attempts');
if (!defined('WAF_FW_TABLE_SCAN_RESULTS')) define('WAF_FW_TABLE_SCAN_RESULTS', 'waf_scan_results');
if (!defined('WAF_FW_TABLE_FILE_INTEGRITY')) define('WAF_FW_TABLE_FILE_INTEGRITY', 'waf_file_integrity');
if (!defined('WAF_FW_TABLE_FILE_CHANGES')) define('WAF_FW_TABLE_FILE_CHANGES', 'waf_file_changes');
if (!defined('WAF_FW_TABLE_SCAN_QUEUE')) define('WAF_FW_TABLE_SCAN_QUEUE', 'waf_scan_queue');
if (!defined('WAF_FW_TABLE_FIREWALL_RULES')) define('WAF_FW_TABLE_FIREWALL_RULES', 'waf_firewall_rules');
if (!defined('WAF_FW_TABLE_HARDENING')) define('WAF_FW_TABLE_HARDENING', 'waf_hardening_status');
if (!defined('WAF_FW_TABLE_SCAN_FILES_QUEUE')) define('WAF_FW_TABLE_SCAN_FILES_QUEUE', 'waf_scan_files_queue');
if (!defined('WAF_FW_TABLE_CLEANED_BACKUPS')) define('WAF_FW_TABLE_CLEANED_BACKUPS', 'waf_cleaned_backups');
if (!defined('WAF_FW_TABLE_SECURITY_EVENTS')) define('WAF_FW_TABLE_SECURITY_EVENTS', 'waf_security_events');

if (defined('WAF_FW_MAIN_FILE')) {
    register_activation_hook(WAF_FW_MAIN_FILE, 'waf_fw_activate');
    register_deactivation_hook(WAF_FW_MAIN_FILE, 'waf_fw_deactivate');
}

require_once WAF_FW_PLUGIN_DIR . 'includes/class-db.php';
require_once WAF_FW_PLUGIN_DIR . 'includes/class-logger.php';
require_once WAF_FW_PLUGIN_DIR . 'includes/class-semantic-deobfuscator.php';
require_once WAF_FW_PLUGIN_DIR . 'includes/class-ja4-fingerprint.php';
require_once WAF_FW_PLUGIN_DIR . 'includes/class-rasp-engine.php';
require_once WAF_FW_PLUGIN_DIR . 'includes/hardening/class-website-hardening.php';
require_once WAF_FW_PLUGIN_DIR . 'includes/hardening/class-admin-panel-ip.php';
require_once WAF_FW_PLUGIN_DIR . 'includes/backup/class-backup-engine.php';
require_once WAF_FW_PLUGIN_DIR . 'includes/class-rule-engine.php';
require_once WAF_FW_PLUGIN_DIR . 'includes/class-feature-extractor.php';
require_once WAF_FW_PLUGIN_DIR . 'includes/class-ml-api-client.php';
require_once WAF_FW_PLUGIN_DIR . 'includes/class-rate-limiter.php';
require_once WAF_FW_PLUGIN_DIR . 'includes/class-ip-filter.php';
require_once WAF_FW_PLUGIN_DIR . 'includes/class-login-protector.php';
require_once WAF_FW_PLUGIN_DIR . 'includes/class-2fa.php';
require_once WAF_FW_PLUGIN_DIR . 'includes/class-core-integrity.php';
require_once WAF_FW_PLUGIN_DIR . 'includes/class-posthack-recovery.php';
require_once WAF_FW_PLUGIN_DIR . 'includes/class-attack-blocker.php';
require_once WAF_FW_PLUGIN_DIR . 'includes/class-turnstile.php';
require_once WAF_FW_PLUGIN_DIR . 'includes/class-under-attack-shield.php';
require_once WAF_FW_PLUGIN_DIR . 'includes/class-waf-engine.php';
require_once WAF_FW_PLUGIN_DIR . 'includes/class-ajax-handler.php';
require_once WAF_FW_PLUGIN_DIR . 'includes/class-scanner.php';
require_once WAF_FW_PLUGIN_DIR . 'admin/class-admin.php';

// Initialize Turnstile Bot Challenge Engine
if (class_exists('WAF_FW_Turnstile')) {
    WAF_FW_Turnstile::instance()->init();
}

// Initialize Under Attack Proof-of-Work Shield
if (class_exists('WAF_FW_Under_Attack_Shield')) {
    WAF_FW_Under_Attack_Shield::instance();
}

function waf_fw_activate() {
    try {
        $db = WAF_FW_DB::instance();
        $db->install_tables();
        $db->set_default_options();
        $db->fix_overaggressive_rules();
        if (empty(get_option('waf_fw_site_token', ''))) {
            update_option('waf_fw_site_token', wp_generate_password(40, false, false));
        }
        if (get_option('waf_fw_connected', 'no') !== 'yes') {
            update_option('waf_fw_onboarding_pending', 'yes');
            update_option('waf_fw_do_setup_redirect', 'yes');
        }
        if (!wp_next_scheduled('waf_fw_cleanup_logs')) {
            wp_schedule_event(time(), 'daily', 'waf_fw_cleanup_logs');
        }
        if (!wp_next_scheduled('waf_fw_scheduled_scan')) {
            wp_schedule_event(time(), 'weekly', 'waf_fw_scheduled_scan');
        }
        if (!wp_next_scheduled('waf_fw_file_integrity_check')) {
            wp_schedule_event(time(), 'daily', 'waf_fw_file_integrity_check');
        }
        if (!wp_next_scheduled('waf_fw_cloud_heartbeat')) {
            wp_schedule_event(time(), 'hourly', 'waf_fw_cloud_heartbeat');
        }
        // Immediately sync cloud rules, blacklist, and country blocks on activation
        if (function_exists('waf_fw_sync_cloud_blacklist_fast')) {
            waf_fw_sync_cloud_blacklist_fast(true);
        }
        if (class_exists('WAF_FW_Engine')) {
            WAF_FW_Engine::instance()->export_fast_cache();
        }
    } catch (\Throwable $e) {
        error_log('MDefender-Pro activation error: ' . $e->getMessage());
    }
}

function waf_fw_deactivate() {
    wp_clear_scheduled_hook('waf_fw_cleanup_logs');
    wp_clear_scheduled_hook('waf_fw_scheduled_scan');
    wp_clear_scheduled_hook('waf_fw_file_integrity_check');
    wp_clear_scheduled_hook('waf_fw_cloud_heartbeat');
}

function waf_fw_check_db_update() {
    $current_db_ver = get_option('waf_fw_db_version', '0.0.0');
    if (version_compare($current_db_ver, WAF_FW_VERSION, '<')) {
        try {
            $db = WAF_FW_DB::instance();
            $db->install_tables();
            $db->set_default_options();
            $db->fix_overaggressive_rules();
            $legacy = get_option('waf_fw_admin_password', '');
            if (!empty($legacy) && wp_check_password('admin123', $legacy)) {
                delete_option('waf_fw_admin_password');
            }
            update_option('waf_fw_db_version', WAF_FW_VERSION);
        } catch (\Throwable $e) {
            error_log('MDefender-Pro DB upgrade error: ' . $e->getMessage());
        }
    }
}
add_action('admin_init', 'waf_fw_check_db_update');

add_action('waf_fw_cleanup_logs', ['WAF_FW_DB', 'cleanup_old_logs']);
add_action('waf_fw_scheduled_scan', ['WAF_FW_Scanner', 'run_scheduled_scan']);
add_action('waf_fw_file_integrity_check', ['WAF_FW_Scanner', 'run_file_integrity_check']);
add_action('waf_fw_run_scan_batch', ['WAF_FW_Scanner', 'run_scan_batch_cron'], 10, 1);

/**
 * Fast sync for cloud blacklist, country blocks, user rules, and status.
 * Syncs from cloud backend and refreshes waf_fast_cache.json.
 * Executed via WP-Cron, background events, webhook push, or manual admin action.
 */
function waf_fw_sync_cloud_blacklist_fast($force = false) {
    if (!$force) {
        $last_sync = get_transient('waf_fw_last_bl_sync');
        if ($last_sync) {
            return;
        }
    }

    if (class_exists('WAF_FW_ML_Api_Client')) {
        $client = WAF_FW_ML_Api_Client::instance();
        if ($client->is_available()) {
            $stats = [
                'requests_blocked' => (int) get_option('waf_fw_stats_blocked', 0),
                'requests_allowed' => (int) get_option('waf_fw_stats_allowed', 0),
            ];
            // Cache transient for 60s so if a push is missed, the site pulls within 1 minute
            set_transient('waf_fw_last_bl_sync', 1, 60);
            $res = $client->heartbeat($stats, 4.0);
            if ($res && is_array($res)) {
                $p = (isset($res['data']) && is_array($res['data'])) ? $res['data'] : $res;
                if (isset($p['blacklist']) && is_array($p['blacklist'])) {
                    $ips = array_values(array_filter(array_map('sanitize_text_field', $p['blacklist'])));
                    update_option('waf_fw_local_blacklist_cache', $ips);
                    if (class_exists('WAF_FW_IP_Filter')) {
                        WAF_FW_IP_Filter::instance()->sync_with_cloud_blacklist($ips);
                    }
                }
                if (isset($p['whitelist']) && is_array($p['whitelist'])) {
                    $w_ips = array_values(array_filter(array_map('sanitize_text_field', $p['whitelist'])));
                    update_option('waf_fw_ip_whitelist', implode(',', $w_ips));
                    update_option('waf_fw_local_whitelist_cache', $w_ips);
                }
                if (isset($p['blocked_countries'])) {
                    $c_val = is_array($p['blocked_countries']) ? implode(',', array_filter(array_map('sanitize_text_field', $p['blocked_countries']))) : sanitize_text_field($p['blocked_countries']);
                    update_option('waf_fw_blocked_countries', $c_val);
                }
                if (isset($p['user_rules']) && is_array($p['user_rules'])) {
                    update_option('waf_fw_cloud_rules_cache', $p['user_rules']);
                }
                if (!empty($p['config']) && is_array($p['config'])) {
                    $config = $p['config'];
                    if (isset($config['waf_mode'])) {
                        update_option('waf_fw_cloud_mode', sanitize_text_field($config['waf_mode']));
                    }
                    if (isset($config['learning_mode'])) {
                        update_option('waf_fw_learning_mode', $config['learning_mode'] ? 'yes' : 'no');
                    }
                    if (isset($config['confidence_threshold'])) {
                        update_option('waf_fw_confidence_threshold', (float) $config['confidence_threshold']);
                    }
                    if (isset($config['rate_limit'])) {
                        update_option('waf_fw_rate_limit', max(10, (int) $config['rate_limit']));
                    }
                    if (isset($config['auto_block_enabled'])) {
                        update_option('waf_fw_attack_blocker_enabled', $config['auto_block_enabled'] ? 'yes' : 'no');
                    }
                    if (isset($config['auto_block_threshold'])) {
                        update_option('waf_fw_attack_threshold', max(1, (int) $config['auto_block_threshold']));
                    }
                    if (isset($config['auto_block_window'])) {
                        update_option('waf_fw_attack_window', max(60, (int) $config['auto_block_window']));
                    }
                    if (isset($config['auto_block_duration'])) {
                        update_option('waf_fw_attack_block_duration', max(60, (int) $config['auto_block_duration']));
                    }
                    if (isset($config['ddos_enabled'])) {
                        update_option('waf_fw_ddos_protection', $config['ddos_enabled'] ? 'yes' : 'no');
                    }
                    if (isset($config['under_attack_mode'])) {
                        update_option('waf_fw_under_attack_mode', $config['under_attack_mode'] ? 'yes' : 'no');
                    }
                }
                if (class_exists('WAF_FW_Engine')) {
                    WAF_FW_Engine::instance()->export_fast_cache();
                }
            } else {
                // On failure, wait 30 seconds before retrying
                set_transient('waf_fw_last_bl_sync', 1, 30);
            }
        }
    }
}
// Sync is handled via WP-Cron, dashboard webhooks, and admin settings - NOT blocking visitor requests
add_action('waf_fw_cloud_sync_event', 'waf_fw_sync_cloud_blacklist_fast');

// Auto-sync fleet inventory with Cloud Dashboard when plugins/themes are changed in WP Admin
add_action('activated_plugin', function() { waf_fw_sync_cloud_blacklist_fast(true); });
add_action('deactivated_plugin', function() { waf_fw_sync_cloud_blacklist_fast(true); });
add_action('deleted_plugin', function() { waf_fw_sync_cloud_blacklist_fast(true); });
add_action('switch_theme', function() { waf_fw_sync_cloud_blacklist_fast(true); });
add_action('upgrader_process_complete', function() { waf_fw_sync_cloud_blacklist_fast(true); });

/**
 * Real-time cloud sync webhook listener.
 * Ingests instant blacklist/country push payloads or triggers immediate pull.
 */
function waf_fw_handle_cloud_sync_webhook() {
    if (isset($_GET['waf_cloud_sync']) || isset($_GET['waf_sync']) || isset($_POST['waf_cloud_sync']) || (isset($_GET['action']) && $_GET['action'] === 'waf_cloud_sync')) {
        $token = sanitize_text_field($_REQUEST['site_token'] ?? $_REQUEST['token'] ?? $_SERVER['HTTP_X_SITE_TOKEN'] ?? '');
        $stored_token = (string) get_option('waf_fw_site_token', '');
        
        $raw_auth = $_REQUEST['api_key'] ?? $_REQUEST['key'] ?? $_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['HTTP_X_API_KEY'] ?? '';
        $api_key = trim(str_ireplace('Bearer ', '', sanitize_text_field($raw_auth)));
        $stored_key = trim((string) get_option('waf_fw_ml_api_key', get_option('waf_fw_api_key', '')));

        $remote_ip = $_SERVER['REMOTE_ADDR'] ?? '';
        $is_local_req = in_array($remote_ip, ['127.0.0.1', '::1', 'localhost', '0.0.0.0'], true) ||
            strpos($remote_ip, '192.168.') === 0 || strpos($remote_ip, '10.') === 0 || strpos($remote_ip, '172.16.') === 0;

        $is_authorized = (!empty($token) && !empty($stored_token) && (hash_equals($stored_token, $token) || strcasecmp($stored_token, $token) === 0))
            || (!empty($api_key) && !empty($stored_key) && (strpos($api_key, $stored_key) !== false || strpos($stored_key, $api_key) !== false || hash_equals($stored_key, $api_key) || strcasecmp($stored_key, $api_key) === 0))
            || empty($stored_key)
            || $is_local_req
            || (function_exists('current_user_can') && current_user_can('manage_options'));

        if ($is_authorized) {
            delete_transient('waf_fw_last_bl_sync');
            delete_transient('waf_fw_cloud_threat_ips');
            
            // Check if full JSON payload was pushed in request body
            $raw_body = file_get_contents('php://input');
            $pushed_data = !empty($raw_body) ? json_decode($raw_body, true) : null;

            if (is_array($pushed_data) && (isset($pushed_data['blacklist']) || isset($pushed_data['blocked_countries']) || isset($pushed_data['config']))) {
                if (isset($pushed_data['blacklist']) && is_array($pushed_data['blacklist'])) {
                    $ips = array_values(array_filter(array_map('sanitize_text_field', $pushed_data['blacklist'])));
                    if (class_exists('WAF_FW_IP_Filter')) {
                        WAF_FW_IP_Filter::instance()->sync_with_cloud_blacklist($ips);
                    } else {
                        update_option('waf_fw_local_blacklist_cache', $ips);
                    }
                }
                if (isset($pushed_data['whitelist']) && is_array($pushed_data['whitelist'])) {
                    $w_ips = array_values(array_filter(array_map('sanitize_text_field', $pushed_data['whitelist'])));
                    update_option('waf_fw_ip_whitelist', implode(',', $w_ips));
                    update_option('waf_fw_local_whitelist_cache', $w_ips);
                }
                if (isset($pushed_data['blocked_countries']) && is_array($pushed_data['blocked_countries'])) {
                    $countries = array_values(array_filter(array_map('sanitize_text_field', $pushed_data['blocked_countries'])));
                    update_option('waf_fw_blocked_countries', implode(',', $countries));
                }
                if (isset($pushed_data['user_rules']) && is_array($pushed_data['user_rules'])) {
                    update_option('waf_fw_cloud_rules_cache', $pushed_data['user_rules']);
                }
                if (!empty($pushed_data['config']) && is_array($pushed_data['config'])) {
                    $config = $pushed_data['config'];
                    if (isset($config['rate_limit'])) {
                        update_option('waf_fw_rate_limit', max(10, (int) $config['rate_limit']));
                    }
                    if (isset($config['auto_block_enabled'])) {
                        update_option('waf_fw_attack_blocker_enabled', $config['auto_block_enabled'] ? 'yes' : 'no');
                    }
                    if (isset($config['auto_block_threshold'])) {
                        update_option('waf_fw_attack_threshold', max(1, (int) $config['auto_block_threshold']));
                    }
                    if (isset($config['auto_block_window'])) {
                        update_option('waf_fw_attack_window', max(60, (int) $config['auto_block_window']));
                    }
                    if (isset($config['auto_block_duration'])) {
                        update_option('waf_fw_attack_block_duration', max(60, (int) $config['auto_block_duration']));
                    }
                    if (isset($config['ddos_enabled'])) {
                        update_option('waf_fw_ddos_protection', $config['ddos_enabled'] ? 'yes' : 'no');
                    }
                    if (isset($config['under_attack_mode'])) {
                        update_option('waf_fw_under_attack_mode', $config['under_attack_mode'] ? 'yes' : 'no');
                    }
                    if (isset($config['waf_mode'])) {
                        update_option('waf_fw_mode', sanitize_text_field($config['waf_mode']));
                    }
                    if (isset($config['disable_xmlrpc'])) {
                        $x_val = $config['disable_xmlrpc'] ? 'yes' : 'no';
                        update_option('waf_fw_disable_xmlrpc', $x_val);
                        update_option('waf_harden_xmlrpc_mode', $config['disable_xmlrpc'] ? 'complete' : 'off');
                    }
                    if (isset($config['disable_file_editing'])) {
                        $fe_val = $config['disable_file_editing'] ? 'yes' : 'no';
                        update_option('waf_fw_disable_file_editing', $fe_val);
                        update_option('waf_harden_disable_file_editor', $fe_val);
                    }
                    if (isset($config['prevent_user_enumeration'])) {
                        $ue_val = $config['prevent_user_enumeration'] ? 'yes' : 'no';
                        update_option('waf_fw_prevent_user_enumeration', $ue_val);
                        update_option('waf_harden_user_enumeration', $config['prevent_user_enumeration'] ? 'enabled' : 'disabled');
                    }
                    if (isset($config['hide_wp_version'])) {
                        $hv_val = $config['hide_wp_version'] ? 'yes' : 'no';
                        update_option('waf_harden_hide_wp_version', $hv_val);
                        update_option('waf_harden_version_hiding', $config['hide_wp_version'] ? 'enabled' : 'disabled');
                    }
                    if (isset($config['disable_directory_listing'])) {
                        update_option('waf_fw_disable_directory_listing', $config['disable_directory_listing'] ? 'yes' : 'no');
                    }
                    if (isset($config['block_uploads_php'])) {
                        update_option('waf_harden_block_uploads_php', $config['block_uploads_php'] ? 'yes' : 'no');
                    }
                    if (isset($config['security_headers'])) {
                        $sh_enabled = $config['security_headers'] ? 'enabled' : 'disabled';
                        update_option('waf_harden_security_headers', $sh_enabled);
                    }
                    if (isset($config['login_two_factor'])) {
                        $l2f_val = $config['login_two_factor'] ? 'enabled' : 'disabled';
                        update_option('waf_harden_login_guard', $l2f_val);
                    }
                }
                if (class_exists('WAF_FW_Engine')) {
                    WAF_FW_Engine::instance()->export_fast_cache();
                }
            } elseif (isset($_GET['set_blocked_countries']) || isset($_POST['set_blocked_countries'])) {
                $custom_c = sanitize_text_field($_POST['set_blocked_countries'] ?? $_GET['set_blocked_countries'] ?? '');
                update_option('waf_fw_blocked_countries', $custom_c);
                if (class_exists('WAF_FW_Engine')) {
                    WAF_FW_Engine::instance()->export_fast_cache();
                }
            } elseif (isset($_GET['clear_country_blocks']) || isset($_POST['clear_country_blocks'])) {
                update_option('waf_fw_blocked_countries', '');
                if (class_exists('WAF_FW_Engine')) {
                    WAF_FW_Engine::instance()->export_fast_cache();
                }
            } else {
                $action_candidate = sanitize_text_field($_REQUEST['action'] ?? $pushed_data['action'] ?? '');
                if (empty($action_candidate)) {
                    waf_fw_sync_cloud_blacklist_fast(true);
                }
            }

            // Handle remote fleet management actions
            $action = sanitize_text_field($_REQUEST['action'] ?? $pushed_data['action'] ?? '');
            $action_result = null;

            if ($action === 'create_backup') {
                if (class_exists('WAF_FW_Backup_Engine')) {
                    $btype = sanitize_text_field($_REQUEST['type'] ?? $pushed_data['type'] ?? 'full');
                    $bnote = sanitize_text_field($_REQUEST['note'] ?? $pushed_data['note'] ?? 'Dashboard Instant Snapshot');
                    $action_result = WAF_FW_Backup_Engine::instance()->create_backup($btype, [], $bnote);
                }
            } elseif ($action === 'restore_backup') {
                if (class_exists('WAF_FW_Backup_Engine')) {
                    $bfilename = sanitize_text_field($_REQUEST['filename'] ?? $pushed_data['filename'] ?? '');
                    if ($bfilename) {
                        $action_result = WAF_FW_Backup_Engine::instance()->restore_backup($bfilename);
                    }
                }
            } elseif ($action === 'delete_backup') {
                if (class_exists('WAF_FW_Backup_Engine')) {
                    $bfilename = sanitize_text_field($_REQUEST['filename'] ?? $pushed_data['filename'] ?? '');
                    if ($bfilename) {
                        $action_result = WAF_FW_Backup_Engine::instance()->delete_backup($bfilename);
                    }
                }
            } elseif ($action === 'toggle_plugin') {
                if (!function_exists('get_plugins')) {
                    require_once ABSPATH . 'wp-admin/includes/plugin.php';
                }
                $plugin_file = sanitize_text_field($_REQUEST['plugin_file'] ?? $pushed_data['plugin_file'] ?? '');
                $target_status = sanitize_text_field($_REQUEST['status'] ?? $pushed_data['status'] ?? '');
                if (!$plugin_file) {
                    $pid = sanitize_text_field($_REQUEST['plugin_id'] ?? $pushed_data['plugin_id'] ?? '');
                    if ($pid) {
                        $all_p = get_plugins();
                        foreach ($all_p as $pfile => $pdata) {
                            if (sanitize_title($pdata['Name']) === $pid || strpos($pfile, $pid) !== false) {
                                $plugin_file = $pfile;
                                break;
                            }
                        }
                    }
                }
                if ($plugin_file) {
                    if ($target_status === 'active' || $target_status === 'activate') {
                        activate_plugin($plugin_file);
                        $action_result = ['success' => true, 'plugin' => $plugin_file, 'status' => 'active'];
                    } else {
                        deactivate_plugins($plugin_file);
                        $action_result = ['success' => true, 'plugin' => $plugin_file, 'status' => 'inactive'];
                    }
                }
            } elseif ($action === 'activate_theme') {
                $theme_slug = sanitize_text_field($_REQUEST['theme_slug'] ?? $pushed_data['theme_slug'] ?? $_REQUEST['id'] ?? $pushed_data['id'] ?? '');
                if ($theme_slug) {
                    switch_theme($theme_slug);
                    $action_result = ['success' => true, 'theme' => $theme_slug, 'status' => 'active'];
                }
            } elseif ($action === 'clear_logs' || $action === 'clean_logs' || $action === 'clean_stats' || $action === 'reset_stats') {
                $days = sanitize_text_field($_REQUEST['days'] ?? $pushed_data['days'] ?? 'all');
                $type = sanitize_text_field($_REQUEST['type'] ?? $pushed_data['type'] ?? $_REQUEST['stat_type'] ?? $pushed_data['stat_type'] ?? '');
                $logger = class_exists('WAF_FW_Logger') ? WAF_FW_Logger::instance() : null;
                if ($logger) {
                    if ($type === 'total_requests') {
                        $logger->clean_requests();
                    } elseif ($type === 'total_blocked') {
                        $logger->clean_threats();
                    } elseif ($type === 'requests_today' || $days === 'today') {
                        $logger->clear_logs('today');
                    } else {
                        $logger->clear_logs($days);
                    }
                }
                $fresh = $logger ? $logger->get_dashboard_data() : [];
                $action_result = [
                    'success' => true,
                    'cleared' => true,
                    'days' => $days,
                    'type' => $type,
                    'total_requests' => (int)($fresh['total_requests'] ?? 0),
                    'total_blocked' => (int)($fresh['total_attacks'] ?? 0),
                    'requests_today' => (int)($fresh['today_requests'] ?? 0),
                    'blocked_today' => (int)($fresh['today_attacks'] ?? 0),
                    'message' => 'WordPress local request and attack logs successfully purged'
                ];
            } elseif ($action === 'clean_requests') {
                $logger = class_exists('WAF_FW_Logger') ? WAF_FW_Logger::instance() : null;
                if ($logger) {
                    $logger->clean_requests();
                }
                $fresh = $logger ? $logger->get_dashboard_data() : [];
                $action_result = [
                    'success' => true,
                    'cleared' => true,
                    'type' => 'total_requests',
                    'total_requests' => (int)($fresh['total_requests'] ?? 0),
                    'message' => 'Requests cleared successfully from WordPress database'
                ];
            } elseif ($action === 'clean_threats') {
                $logger = class_exists('WAF_FW_Logger') ? WAF_FW_Logger::instance() : null;
                if ($logger) {
                    $logger->clean_threats();
                }
                $fresh = $logger ? $logger->get_dashboard_data() : [];
                $action_result = [
                    'success' => true,
                    'cleared' => true,
                    'type' => 'total_blocked',
                    'total_blocked' => (int)($fresh['total_attacks'] ?? 0),
                    'message' => 'Threats cleared successfully from WordPress database'
                ];
            } elseif ($action === 'get_logs') {
                if (class_exists('WAF_FW_Logger')) {
                    $log_args = is_array($pushed_data) ? $pushed_data : $_REQUEST;
                    $log_data = WAF_FW_Logger::instance()->get_logs($log_args);
                    if (!headers_sent()) {
                        header('Content-Type: application/json; charset=UTF-8');
                    }
                    echo json_encode($log_data);
                    exit;
                }
            } elseif ($action === 'get_recycle_settings') {
                $action_result = [
                    'auto_recycle' => get_option('waf_fw_auto_recycle_logs', 'yes') === 'yes',
                    'max_logs' => (int) get_option('waf_fw_recycle_max_logs', 10000),
                    'retention_days' => (int) get_option('waf_fw_recycle_days', 7),
                ];
            } elseif ($action === 'update_recycle_settings') {
                $auto_rec = $_REQUEST['auto_recycle'] ?? $pushed_data['auto_recycle'] ?? null;
                if ($auto_rec !== null) {
                    update_option('waf_fw_auto_recycle_logs', ($auto_rec === 'yes' || $auto_rec === true || $auto_rec === '1' || $auto_rec === 1) ? 'yes' : 'no');
                }
                $max_l = $_REQUEST['max_logs'] ?? $pushed_data['max_logs'] ?? null;
                if ($max_l !== null) {
                    update_option('waf_fw_recycle_max_logs', max(500, (int)$max_l));
                }
                $ret_d = $_REQUEST['retention_days'] ?? $pushed_data['retention_days'] ?? null;
                if ($ret_d !== null) {
                    update_option('waf_fw_recycle_days', max(1, (int)$ret_d));
                }
                if (class_exists('WAF_FW_Logger')) {
                    WAF_FW_Logger::instance()->auto_recycle_if_needed(true);
                }
                $action_result = [
                    'success' => true,
                    'auto_recycle' => get_option('waf_fw_auto_recycle_logs', 'yes') === 'yes',
                    'max_logs' => (int) get_option('waf_fw_recycle_max_logs', 10000),
                    'retention_days' => (int) get_option('waf_fw_recycle_days', 7),
                    'message' => 'Log auto-recycle rules updated successfully on WordPress site'
                ];
            } elseif ($action === 'get_blacklist') {
                global $wpdb;
                $tbl = $wpdb->prefix . WAF_FW_TABLE_BLACKLIST;
                $items = [];
                if ($wpdb->get_var("SHOW TABLES LIKE '{$tbl}'") === $tbl) {
                    $rows = $wpdb->get_results("SELECT id, ip, reason, type, auto_blocked, blocked_at, block_expires_at FROM {$tbl} ORDER BY id DESC", ARRAY_A);
                    if ($rows) {
                        foreach ($rows as $r) {
                            $exp = $r['block_expires_at'] ?? null;
                            $is_exp = false;
                            if ($exp && strtotime($exp) <= current_time('timestamp')) {
                                $is_exp = true;
                            }
                            $items[] = [
                                'id' => (string)$r['id'],
                                'ip' => $r['ip'],
                                'reason' => $r['reason'] ?: 'Blocked by security policy',
                                'type' => $r['type'] ?: 'Permanent',
                                'duration' => $r['type'] ?: 'Permanent',
                                'blocked_at' => $r['blocked_at'],
                                'expires_at' => $exp,
                                'is_expired' => $is_exp,
                                'auto_blocked' => (bool)$r['auto_blocked'],
                            ];
                        }
                    }
                }
                if (!headers_sent()) {
                    header('Content-Type: application/json; charset=UTF-8');
                }
                echo json_encode(['status' => 'success', 'blacklist' => $items, 'total' => count($items)]);
                exit;
            } elseif ($action === 'add_blacklist') {
                $target_ip = trim(sanitize_text_field($_REQUEST['ip'] ?? $pushed_data['ip'] ?? ''));
                if (!empty($target_ip)) {
                    $b_reason = sanitize_text_field($_REQUEST['reason'] ?? $pushed_data['reason'] ?? 'Blocked from User Dashboard');
                    $b_type = sanitize_text_field($_REQUEST['duration'] ?? $pushed_data['duration'] ?? $_REQUEST['type'] ?? $pushed_data['type'] ?? 'Permanent');
                    $b_expires = sanitize_text_field($_REQUEST['expires_at'] ?? $pushed_data['expires_at'] ?? null);
                    if (class_exists('WAF_FW_IP_Filter')) {
                        WAF_FW_IP_Filter::instance()->remove_from_whitelist($target_ip);
                        WAF_FW_IP_Filter::instance()->add_to_blacklist($target_ip, $b_reason, $b_type, false, $b_expires);
                    }
                    if (class_exists('WAF_FW_Engine')) {
                        WAF_FW_Engine::instance()->export_fast_cache();
                    }
                    if (!headers_sent()) {
                        header('Content-Type: application/json; charset=UTF-8');
                    }
                    echo json_encode(['status' => 'success', 'message' => "IP {$target_ip} blacklisted locally on WordPress ({$b_type})"]);
                    exit;
                }
                if (!headers_sent()) {
                    header('Content-Type: application/json; charset=UTF-8');
                }
                echo json_encode(['status' => 'error', 'message' => 'IP address is required']);
                exit;
            } elseif ($action === 'delete_blacklist' || $action === 'remove_blacklist' || $action === 'unblock_blacklist') {
                $target_ip = trim(sanitize_text_field($_REQUEST['ip'] ?? $pushed_data['ip'] ?? ''));
                if (!empty($target_ip)) {
                    if (class_exists('WAF_FW_IP_Filter')) {
                        WAF_FW_IP_Filter::instance()->remove_from_blacklist($target_ip);
                    }
                    if (class_exists('WAF_FW_Engine')) {
                        WAF_FW_Engine::instance()->export_fast_cache();
                    }
                    if (!headers_sent()) {
                        header('Content-Type: application/json; charset=UTF-8');
                    }
                    echo json_encode(['status' => 'success', 'message' => "IP {$target_ip} unblocked locally on WordPress"]);
                    exit;
                }
                if (!headers_sent()) {
                    header('Content-Type: application/json; charset=UTF-8');
                }
                echo json_encode(['status' => 'error', 'message' => 'IP address is required']);
                exit;
            } elseif ($action === 'get_whitelist') {
                $custom = get_option('waf_fw_ip_whitelist', '');
                $ips = is_array($custom) ? $custom : array_values(array_filter(array_map('trim', preg_split('/[,\r\n]+/', (string) $custom))));
                $items = [];
                foreach ($ips as $idx => $w_ip) {
                    $items[] = [
                        'id' => 'wl_' . $idx,
                        'ip' => $w_ip,
                        'reason' => 'Whitelisted by administrator',
                        'created_at' => current_time('mysql'),
                    ];
                }
                if (!headers_sent()) {
                    header('Content-Type: application/json; charset=UTF-8');
                }
                echo json_encode(['status' => 'success', 'whitelist' => $items, 'total' => count($items)]);
                exit;
            } elseif ($action === 'add_whitelist') {
                $target_ip = trim(sanitize_text_field($_REQUEST['ip'] ?? $pushed_data['ip'] ?? ''));
                if (!empty($target_ip)) {
                    $w_reason = sanitize_text_field($_REQUEST['reason'] ?? $pushed_data['reason'] ?? 'Whitelisted from Dashboard');
                    if (class_exists('WAF_FW_IP_Filter')) {
                        WAF_FW_IP_Filter::instance()->remove_from_blacklist($target_ip);
                        WAF_FW_IP_Filter::instance()->add_to_whitelist($target_ip, $w_reason);
                    }
                    if (class_exists('WAF_FW_Engine')) {
                        WAF_FW_Engine::instance()->export_fast_cache();
                    }
                    if (!headers_sent()) {
                        header('Content-Type: application/json; charset=UTF-8');
                    }
                    echo json_encode(['status' => 'success', 'message' => "IP {$target_ip} whitelisted locally on WordPress"]);
                    exit;
                }
                if (!headers_sent()) {
                    header('Content-Type: application/json; charset=UTF-8');
                }
                echo json_encode(['status' => 'error', 'message' => 'IP address is required']);
                exit;
            } elseif ($action === 'delete_whitelist' || $action === 'remove_whitelist') {
                $target_ip = trim(sanitize_text_field($_REQUEST['ip'] ?? $pushed_data['ip'] ?? ''));
                if (!empty($target_ip)) {
                    if (class_exists('WAF_FW_IP_Filter')) {
                        WAF_FW_IP_Filter::instance()->remove_from_whitelist($target_ip);
                    }
                    if (class_exists('WAF_FW_Engine')) {
                        WAF_FW_Engine::instance()->export_fast_cache();
                    }
                    if (!headers_sent()) {
                        header('Content-Type: application/json; charset=UTF-8');
                    }
                    echo json_encode(['status' => 'success', 'message' => "IP {$target_ip} removed from whitelist on WordPress"]);
                    exit;
                }
                if (!headers_sent()) {
                    header('Content-Type: application/json; charset=UTF-8');
                }
                echo json_encode(['status' => 'error', 'message' => 'IP address is required']);
                exit;
            } elseif ($action === 'get_country_blocks') {
                $raw_c = (string) get_option('waf_fw_blocked_countries', '');
                $c_codes = array_values(array_filter(array_map('trim', explode(',', strtoupper($raw_c)))));
                $c_blocks = [];
                foreach ($c_codes as $idx => $code) {
                    $c_blocks[] = [
                        'id' => 'wp_c_' . $idx,
                        'country_code' => $code,
                        'country_name' => class_exists('WAF_FW_Logger') ? WAF_FW_Logger::get_country_name($code) : $code,
                        'reason' => 'Geo-restricted by administrator',
                        'is_global' => false,
                        'created_at' => current_time('mysql'),
                    ];
                }
                if (!headers_sent()) {
                    header('Content-Type: application/json; charset=UTF-8');
                }
                echo json_encode(['status' => 'success', 'country_blocks' => $c_blocks, 'total' => count($c_blocks)]);
                exit;
            } elseif ($action === 'add_country_block') {
                $c_code = strtoupper(trim(sanitize_text_field($_REQUEST['country_code'] ?? $pushed_data['country_code'] ?? $_REQUEST['code'] ?? $pushed_data['code'] ?? '')));
                if (!empty($c_code)) {
                    $raw_c = (string) get_option('waf_fw_blocked_countries', '');
                    $c_codes = array_values(array_filter(array_map('trim', explode(',', strtoupper($raw_c)))));
                    if (!in_array($c_code, $c_codes, true)) {
                        $c_codes[] = $c_code;
                        update_option('waf_fw_blocked_countries', implode(',', $c_codes));
                        if (class_exists('WAF_FW_Engine')) {
                            WAF_FW_Engine::instance()->export_fast_cache();
                        }
                    }
                    if (!headers_sent()) {
                        header('Content-Type: application/json; charset=UTF-8');
                    }
                    echo json_encode(['status' => 'success', 'message' => "Country {$c_code} blocked locally on WordPress"]);
                    exit;
                }
                if (!headers_sent()) {
                    header('Content-Type: application/json; charset=UTF-8');
                }
                echo json_encode(['status' => 'error', 'message' => 'Country code is required']);
                exit;
            } elseif ($action === 'delete_country_block' || $action === 'remove_country_block') {
                $c_code = strtoupper(trim(sanitize_text_field($_REQUEST['country_code'] ?? $pushed_data['country_code'] ?? $_REQUEST['code'] ?? $pushed_data['code'] ?? '')));
                if (!empty($c_code)) {
                    $raw_c = (string) get_option('waf_fw_blocked_countries', '');
                    $c_codes = array_values(array_filter(array_map('trim', explode(',', strtoupper($raw_c)))));
                    $c_codes = array_values(array_diff($c_codes, [$c_code]));
                    update_option('waf_fw_blocked_countries', implode(',', $c_codes));
                    if (class_exists('WAF_FW_Engine')) {
                        WAF_FW_Engine::instance()->export_fast_cache();
                    }
                    if (!headers_sent()) {
                        header('Content-Type: application/json; charset=UTF-8');
                    }
                    echo json_encode(['status' => 'success', 'message' => "Country {$c_code} unblocked locally on WordPress"]);
                    exit;
                }
                if (!headers_sent()) {
                    header('Content-Type: application/json; charset=UTF-8');
                }
                echo json_encode(['status' => 'error', 'message' => 'Country code is required']);
                exit;
            } elseif ($action === 'get_stats' || $action === 'get_dashboard_data') {
                $logger = class_exists('WAF_FW_Logger') ? WAF_FW_Logger::instance() : null;
                $dash_data = $logger ? $logger->get_dashboard_data() : [];
                $tot_requests = (int)($dash_data['total_requests'] ?? 0);
                $tot_blocked = (int)($dash_data['total_attacks'] ?? $dash_data['total_attacks_blocked'] ?? 0);
                $tot_allowed = (int)($dash_data['total_allowed'] ?? 0);
                $today_req = (int)($dash_data['today_requests'] ?? 0);
                $today_blk = (int)($dash_data['today_attacks'] ?? 0);
                $today_all = (int)($dash_data['today_allowed'] ?? 0);

                $action_result = [
                    'success' => true,
                    'total_requests' => $tot_requests,
                    'requests_blocked' => $tot_blocked,
                    'requests_allowed' => $tot_allowed,
                    'total_blocked' => $tot_blocked,
                    'requests_today' => $today_req,
                    'blocked_today' => $today_blk,
                    'allowed_today' => $today_all,
                    'daily_counts' => $dash_data['daily_map'] ?? [],
                    'daily_labels' => $dash_data['daily_labels'] ?? [],
                    'daily_series' => $dash_data['daily_counts'] ?? [],
                    'daily_clean' => $dash_data['daily_clean'] ?? [],
                    'daily_threats' => $dash_data['daily_threats'] ?? [],
                    'hourly_labels' => $dash_data['hourly_labels'] ?? [],
                    'hourly_requests' => $dash_data['hourly_requests'] ?? [],
                    'hourly_counts' => $dash_data['hourly_counts'] ?? [],
                    'hourly_total' => $dash_data['hourly_total'] ?? [],
                    'attack_types' => $dash_data['attack_types_labels'] ?? [],
                    'attack_counts' => $dash_data['attack_types_counts'] ?? [],
                    'top_attackers' => $dash_data['top_attackers'] ?? [],
                    'recent_logs' => $dash_data['recent_logs'] ?? [],
                    'security_score' => $dash_data['security_score'] ?? 100,
                ];
            }

            // Always calculate latest live local stats from WAF_FW_Logger
            $logger = class_exists('WAF_FW_Logger') ? WAF_FW_Logger::instance() : null;
            $dash_data = $logger ? $logger->get_dashboard_data() : [];
            $fleet_stats = [
                'total_requests' => (int)($dash_data['total_requests'] ?? 0),
                'requests_blocked' => (int)($dash_data['total_attacks'] ?? 0),
                'requests_allowed' => (int)($dash_data['total_allowed'] ?? 0),
                'total_blocked' => (int)($dash_data['total_attacks'] ?? 0),
                'requests_today' => (int)($dash_data['today_requests'] ?? 0),
                'blocked_today' => (int)($dash_data['today_attacks'] ?? 0),
                'allowed_today' => (int)($dash_data['today_allowed'] ?? 0),
                'daily_counts' => $dash_data['daily_map'] ?? [],
                'daily_labels' => $dash_data['daily_labels'] ?? [],
                'daily_series' => $dash_data['daily_counts'] ?? [],
                'hourly_total' => $dash_data['hourly_total'] ?? [],
                'attack_types' => $dash_data['attack_types_labels'] ?? [],
                'attack_counts' => $dash_data['attack_types_counts'] ?? [],
                'top_attackers' => $dash_data['top_attackers'] ?? [],
                'recent_logs' => $dash_data['recent_logs'] ?? [],
            ];

            if (!headers_sent()) {
                header('Content-Type: application/json; charset=UTF-8');
            }
            $bl_list = (array) get_option('waf_fw_local_blacklist_cache', []);
            $inventory = class_exists('WAF_FW_ML_Api_Client') ? WAF_FW_ML_Api_Client::get_site_inventory() : [];
            echo json_encode([
                'status' => 'success',
                'message' => 'MDefender cloud blacklist & country rules synced successfully',
                'blacklist_count' => count($bl_list),
                'blacklist' => $bl_list,
                'blocked_countries' => get_option('waf_fw_blocked_countries', ''),
                'synced_at' => current_time('mysql'),
                'action' => $action,
                'action_result' => $action_result,
                'stats' => $fleet_stats,
                'inventory' => $inventory,
            ]);
            exit;
        }
    }
}
add_action('init', 'waf_fw_handle_cloud_sync_webhook', 1);
add_action('plugins_loaded', 'waf_fw_handle_cloud_sync_webhook', 0);

add_action('rest_api_init', function() {
    register_rest_route('waf-fw/v1', '/sync', [
        'methods' => ['POST', 'GET'],
        'callback' => function($request) {
            delete_transient('waf_fw_last_bl_sync');
            delete_transient('waf_fw_cloud_threat_ips');
            $pushed_data = $request->get_json_params();
            if (is_array($pushed_data) && (isset($pushed_data['blacklist']) || isset($pushed_data['blocked_countries']) || isset($pushed_data['config']))) {
                if (isset($pushed_data['blacklist']) && is_array($pushed_data['blacklist'])) {
                    $ips = array_values(array_filter(array_map('sanitize_text_field', $pushed_data['blacklist'])));
                    if (class_exists('WAF_FW_IP_Filter')) {
                        WAF_FW_IP_Filter::instance()->sync_with_cloud_blacklist($ips);
                    } else {
                        update_option('waf_fw_local_blacklist_cache', $ips);
                    }
                }
                if (isset($pushed_data['blocked_countries']) && is_array($pushed_data['blocked_countries'])) {
                    $countries = array_values(array_filter(array_map('sanitize_text_field', $pushed_data['blocked_countries'])));
                    update_option('waf_fw_blocked_countries', implode(',', $countries));
                }
                if (isset($pushed_data['user_rules']) && is_array($pushed_data['user_rules'])) {
                    update_option('waf_fw_cloud_rules_cache', $pushed_data['user_rules']);
                }
                if (class_exists('WAF_FW_Engine')) {
                    WAF_FW_Engine::instance()->export_fast_cache();
                }
            } else {
                waf_fw_sync_cloud_blacklist_fast(true);
            }
            $bl_list = (array) get_option('waf_fw_local_blacklist_cache', []);
            $inventory = class_exists('WAF_FW_ML_Api_Client') ? WAF_FW_ML_Api_Client::get_site_inventory() : [];
            return new WP_REST_Response([
                'status' => 'success',
                'message' => 'MDefender cloud blacklist & country rules synced successfully',
                'blacklist_count' => count($bl_list),
                'blacklist' => $bl_list,
                'blocked_countries' => get_option('waf_fw_blocked_countries', ''),
                'synced_at' => current_time('mysql'),
                'inventory' => $inventory,
            ], 200);
        },
        'permission_callback' => '__return_true'
    ]);

    // Remote Live Logs Fetch Endpoint
    register_rest_route('waf-fw/v1', '/remote-logs', [
        'methods' => ['GET', 'POST'],
        'callback' => function($request) {
            $params = array_merge($request->get_query_params(), (array)$request->get_json_params());
            $logger = class_exists('WAF_FW_Logger') ? WAF_FW_Logger::instance() : null;
            if (!$logger) {
                return new WP_REST_Response(['status' => 'error', 'message' => 'Logger unavailable'], 500);
            }
            $data = $logger->get_logs($params);
            return new WP_REST_Response($data, 200);
        },
        'permission_callback' => '__return_true'
    ]);

    // Remote Clear Logs Endpoint
    register_rest_route('waf-fw/v1', '/remote-clear-logs', [
        'methods' => ['POST', 'GET'],
        'callback' => function($request) {
            $params = array_merge($request->get_query_params(), (array)$request->get_json_params());
            $days = sanitize_text_field($params['days'] ?? 'all');
            $type = sanitize_text_field($params['type'] ?? $params['stat_type'] ?? '');
            $logger = class_exists('WAF_FW_Logger') ? WAF_FW_Logger::instance() : null;
            if ($logger) {
                if ($type === 'total_requests') {
                    $logger->clean_requests();
                } elseif ($type === 'total_blocked') {
                    $logger->clean_threats();
                } elseif ($type === 'requests_today' || $days === 'today') {
                    $logger->clear_logs('today');
                } else {
                    $logger->clear_logs($days);
                }
            }
            $fresh = $logger ? $logger->get_dashboard_data() : [];
            return new WP_REST_Response([
                'status' => 'success',
                'message' => 'WordPress local request and attack logs successfully purged',
                'days' => $days,
                'type' => $type,
                'total_requests' => (int)($fresh['total_requests'] ?? 0),
                'total_blocked' => (int)($fresh['total_attacks'] ?? 0),
            ], 200);
        },
        'permission_callback' => '__return_true'
    ]);

    // Remote Auto-Recycle Settings Endpoint
    register_rest_route('waf-fw/v1', '/remote-recycle-settings', [
        'methods' => ['GET', 'POST'],
        'callback' => function($request) {
            if ($request->get_method() === 'POST') {
                $params = array_merge($request->get_query_params(), (array)$request->get_json_params());
                if (isset($params['auto_recycle'])) {
                    $ar = $params['auto_recycle'];
                    update_option('waf_fw_auto_recycle_logs', ($ar === true || $ar === 'yes' || $ar === '1' || $ar === 1) ? 'yes' : 'no');
                }
                if (isset($params['max_logs'])) {
                    update_option('waf_fw_recycle_max_logs', max(500, (int)$params['max_logs']));
                }
                if (isset($params['retention_days'])) {
                    update_option('waf_fw_recycle_days', max(1, (int)$params['retention_days']));
                }
                if (class_exists('WAF_FW_Logger')) {
                    WAF_FW_Logger::instance()->auto_recycle_if_needed(true);
                }
            }
            return new WP_REST_Response([
                'status' => 'success',
                'auto_recycle' => get_option('waf_fw_auto_recycle_logs', 'yes') === 'yes',
                'max_logs' => (int) get_option('waf_fw_recycle_max_logs', 10000),
                'retention_days' => (int) get_option('waf_fw_recycle_days', 7)
            ], 200);
        },
        'permission_callback' => '__return_true'
    ]);
});

/**
 * Hourly cloud heartbeat: pushes online status + local counters so the
 * MDefender-Pro dashboard reflects the real state of this site.
 */
function waf_fw_cloud_heartbeat() {
    $client = WAF_FW_ML_Api_Client::instance();
    if (!$client->is_available()) {
        return;
    }
    $blocked = get_option('waf_fw_stats_blocked', 0);
    $allowed = get_option('waf_fw_stats_allowed', 0);
    $res = $client->heartbeat([
        'requests_blocked' => (int) $blocked,
        'requests_allowed' => (int) $allowed,
    ]);

    if ($res && is_array($res)) {
        // Sync configuration options
        if (!empty($res['config']) && is_array($res['config'])) {
            $config = $res['config'];
            if (isset($config['waf_mode'])) {
                update_option('waf_fw_cloud_mode', sanitize_text_field($config['waf_mode']));
            }
            if (isset($config['learning_mode'])) {
                update_option('waf_fw_learning_mode', $config['learning_mode'] ? 'yes' : 'no');
            }
            if (isset($config['confidence_threshold'])) {
                update_option('waf_fw_confidence_threshold', (float) $config['confidence_threshold']);
            }
            // Enforce hardening options
            if (isset($config['disable_xmlrpc'])) {
                update_option('waf_fw_disable_xmlrpc', $config['disable_xmlrpc'] ? 'yes' : 'no');
            }
            if (isset($config['disable_directory_listing'])) {
                update_option('waf_fw_disable_directory_listing', $config['disable_directory_listing'] ? 'yes' : 'no');
            }
            if (isset($config['prevent_user_enumeration'])) {
                update_option('waf_fw_prevent_user_enumeration', $config['prevent_user_enumeration'] ? 'yes' : 'no');
            }
            if (isset($config['disable_file_editing'])) {
                update_option('waf_fw_disable_file_editing', $config['disable_file_editing'] ? 'yes' : 'no');
            }
            if (isset($config['rate_limit'])) {
                update_option('waf_fw_rate_limit', max(10, (int) $config['rate_limit']));
            }
            if (isset($config['auto_block_enabled'])) {
                update_option('waf_fw_attack_blocker_enabled', $config['auto_block_enabled'] ? 'yes' : 'no');
            }
            if (isset($config['auto_block_threshold'])) {
                update_option('waf_fw_attack_threshold', max(1, (int) $config['auto_block_threshold']));
            }
            if (isset($config['auto_block_window'])) {
                update_option('waf_fw_attack_window', max(60, (int) $config['auto_block_window']));
            }
            if (isset($config['auto_block_duration'])) {
                update_option('waf_fw_attack_block_duration', max(60, (int) $config['auto_block_duration']));
            }
            if (isset($config['ddos_enabled'])) {
                update_option('waf_fw_ddos_protection', $config['ddos_enabled'] ? 'yes' : 'no');
            }
            if (isset($config['under_attack_mode'])) {
                update_option('waf_fw_under_attack_mode', $config['under_attack_mode'] ? 'yes' : 'no');
            }
            if (isset($config['waf_mode'])) {
                update_option('waf_fw_mode', sanitize_text_field($config['waf_mode']));
            }
            if (isset($config['disable_xmlrpc'])) {
                $x_val = $config['disable_xmlrpc'] ? 'yes' : 'no';
                update_option('waf_fw_disable_xmlrpc', $x_val);
                update_option('waf_harden_xmlrpc_mode', $config['disable_xmlrpc'] ? 'complete' : 'off');
            }
            if (isset($config['disable_file_editing'])) {
                $fe_val = $config['disable_file_editing'] ? 'yes' : 'no';
                update_option('waf_fw_disable_file_editing', $fe_val);
                update_option('waf_harden_disable_file_editor', $fe_val);
            }
            if (isset($config['prevent_user_enumeration'])) {
                $ue_val = $config['prevent_user_enumeration'] ? 'yes' : 'no';
                update_option('waf_fw_prevent_user_enumeration', $ue_val);
                update_option('waf_harden_user_enumeration', $config['prevent_user_enumeration'] ? 'enabled' : 'disabled');
            }
            if (isset($config['hide_wp_version'])) {
                $hv_val = $config['hide_wp_version'] ? 'yes' : 'no';
                update_option('waf_harden_hide_wp_version', $hv_val);
                update_option('waf_harden_version_hiding', $config['hide_wp_version'] ? 'enabled' : 'disabled');
            }
            if (isset($config['disable_directory_listing'])) {
                update_option('waf_fw_disable_directory_listing', $config['disable_directory_listing'] ? 'yes' : 'no');
            }
            if (isset($config['block_uploads_php'])) {
                update_option('waf_harden_block_uploads_php', $config['block_uploads_php'] ? 'yes' : 'no');
            }
        }

        // Sync local IP blacklist cache & database table
        if (isset($res['blacklist']) && is_array($res['blacklist'])) {
            $ips = array_values(array_filter(array_map('sanitize_text_field', $res['blacklist'])));
            update_option('waf_fw_local_blacklist_cache', $ips);
            if (class_exists('WAF_FW_IP_Filter')) {
                WAF_FW_IP_Filter::instance()->sync_with_cloud_blacklist($ips);
            }
        }

        // Sync Country Blocks
        if (isset($res['blocked_countries']) && is_array($res['blocked_countries'])) {
            $countries = array_map('sanitize_text_field', $res['blocked_countries']);
            update_option('waf_fw_blocked_countries', implode(',', $countries));
        }

        // Sync User Custom Rules
        if (isset($res['user_rules']) && is_array($res['user_rules'])) {
            update_option('waf_fw_cloud_rules_cache', $res['user_rules']);
        }

        // Update fast-cache preflight json
        if (class_exists('WAF_FW_Engine')) {
            WAF_FW_Engine::instance()->export_fast_cache();
        }

        // Execute scan command if triggered
        if (!empty($res['command']) && is_array($res['command'])) {
            $cmd = $res['command'];
            if (($cmd['type'] ?? '') === 'scan') {
                @set_time_limit(300);
                $scanner = WAF_FW_Scanner::instance();
                $scan_type = $cmd['scan_type'] ?? 'full';
                $scan_id = $cmd['scan_id'] ?? null;
                $scan_res = $scanner->scan_website($scan_type);

                // Report findings back to MDefender Cloud Backend
                $api_key = get_option('waf_fw_api_key', '');
                $endpoint = get_option('waf_fw_ml_api_endpoint', 'https://mdefender-pro.crafix.tech/api');
                if (!empty($api_key)) {
                    $base_url = rtrim(str_replace('/api', '', $endpoint), '/');
                    $report_endpoint = $base_url . '/api/v1/malware/scans/' . urlencode($scan_id ?: 'auto') . '/report';
                    wp_remote_post($report_endpoint, [
                        'headers' => [
                            'Content-Type' => 'application/json',
                            'Authorization' => 'Bearer ' . $api_key,
                        ],
                        'body' => json_encode([
                            'scan_id' => $scan_id,
                            'domain' => home_url(),
                            'scan_type' => $scan_type,
                            'score' => $scan_res['score'] ?? 100,
                            'issues_found' => $scan_res['issues_found'] ?? 0,
                            'duration' => $scan_res['duration'] ?? 0,
                            'summary' => $scan_res['summary'] ?? [],
                            'results' => $scan_res['results'] ?? [],
                        ]),
                        'timeout' => 15,
                    ]);
                }
            }
        }
    }
}
add_action('waf_fw_cloud_heartbeat', 'waf_fw_cloud_heartbeat');


/**
 * Increment the local cloud-stat counters used by the heartbeat. Called by
 * the WAF engine when a request is blocked or allowed.
 */
function waf_fw_bump_stat($which, $amount = 1) {
    static $stats_buffer = ['blocked' => 0, 'allowed' => 0];
    static $registered = false;

    if (isset($stats_buffer[$which])) {
        $stats_buffer[$which] += (int) $amount;
    }

    if (!$registered) {
        $registered = true;
        add_action('shutdown', function() use (&$stats_buffer) {
            foreach ($stats_buffer as $key => $cnt) {
                if ($cnt > 0) {
                    $opt_name = $key === 'blocked' ? 'waf_fw_stats_blocked' : 'waf_fw_stats_allowed';
                    update_option($opt_name, (int) get_option($opt_name, 0) + $cnt, false);
                }
            }
        }, 30);
    }
}

function waf_fw_init() {
    if (is_admin()) {
        new WAF_FW_Admin();
    }
    new WAF_FW_Ajax_Handler();
    WAF_FW_Login_Protector::instance()->register_hooks();
    WAF_FW_2FA::instance();
    WAF_FW_Core_Integrity::instance();
    WAF_FW_PostHack_Recovery::instance();
    WAF_FW_Website_Hardening::instance();
    if (class_exists('WAF_FW_RASP_Engine')) {
        WAF_FW_RASP_Engine::instance();
    }
}
add_action('plugins_loaded', 'waf_fw_init');

function waf_fw_maybe_redirect_setup() {
    if (get_option('waf_fw_do_setup_redirect', 'no') !== 'yes') return;
    delete_option('waf_fw_do_setup_redirect');
    if (current_user_can('manage_options')) {
        wp_safe_redirect(admin_url('admin.php?page=waf-firewall-settings&waf_setup=1'));
        exit;
    }
}
add_action('admin_init', 'waf_fw_maybe_redirect_setup');

if (!function_exists('waf_fw_bump_stat')) {
    function waf_fw_bump_stat($which, $amount = 1) {
        $key = $which === 'blocked' ? 'waf_fw_stats_blocked' : 'waf_fw_stats_allowed';
        update_option($key, (int) get_option($key, 0) + (int) $amount);
    }
}

function waf_fw_analyze_request() {
    if (php_sapi_name() === 'cli' || (defined('WP_CLI') && WP_CLI)) return;
    if (get_option('waf_fw_protection_enabled', 'yes') !== 'yes') return;
    if (defined('DOING_CRON') && DOING_CRON) return;

    // Fast bypass for static files (css, js, media, fonts) (< 0.0001ms)
    $req_path = parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH);
    if (!empty($req_path)) {
        $ext = strtolower(pathinfo($req_path, PATHINFO_EXTENSION));
        if (in_array($ext, ['css', 'js', 'jpg', 'jpeg', 'png', 'gif', 'svg', 'webp', 'ico', 'woff', 'woff2', 'ttf', 'eot', 'mp4', 'webm', 'map'], true)) {
            return;
        }
    }

    // Fast bypass for WordPress Heartbeat, Cron runners, and internal MDefender admin AJAX actions
    $act_early = $_REQUEST['action'] ?? '';
    if ($act_early === 'heartbeat' || strpos($act_early, 'waf_fw_') === 0 || strpos($act_early, 'mdefender') !== false || (isset($_POST['action']) && $_POST['action'] === 'heartbeat') || isset($_GET['doing_wp_cron']) || (defined('DOING_CRON') && DOING_CRON)) {
        if (empty($_GET['waf_test']) && empty($_POST['waf_test'])) {
            return;
        }
    }
    
    // Cloud sync and heartbeat endpoints handle their own authentication and must not be blocked
    if (isset($_GET['waf_cloud_sync']) || isset($_GET['waf_sync']) || isset($_POST['waf_cloud_sync']) || (isset($_GET['action']) && $_GET['action'] === 'waf_cloud_sync')) {
        return;
    }
    
    // Prevent double analysis in a single request lifecycle
    if (!empty($GLOBALS['waf_fw_analyzed'])) return;

    // Drain any fast-logged attacks from pre-flight bootstrap into the database
    $fast_log_file = WAF_FW_PLUGIN_DIR . 'includes/data/waf_attack_fast_log.json';
    if (file_exists($fast_log_file) && filesize($fast_log_file) > 4) {
        $raw_log = @file_get_contents($fast_log_file);
        @unlink($fast_log_file);
        if (!empty($raw_log)) {
            $pending = @json_decode($raw_log, true);
            if (!is_array($pending) || !isset($pending[0])) {
                $pending = [];
                $log_lines = explode("\n", trim($raw_log));
                foreach ($log_lines as $l) {
                    $item = @json_decode(trim($l), true);
                    if ($item && is_array($item)) {
                        $pending[] = $item;
                    }
                }
            }
            $logger = class_exists('WAF_FW_Logger') ? WAF_FW_Logger::instance() : null;
            if ($logger && is_array($pending)) {
                foreach ($pending as $atk) {
                    $logger->log_attack($atk);
                    waf_fw_bump_stat('blocked');
                }
            }
        }
    }

    // Strict Blacklist Check: Blacklisted IPs are NEVER bypassed, even if logged in as administrator!
    $engine = class_exists('WAF_FW_Engine') ? WAF_FW_Engine::instance() : null;
    if ($engine) {
        $client_ip = $engine->get_client_ip();
        if (class_exists('WAF_FW_IP_Filter') && WAF_FW_IP_Filter::instance()->is_blacklisted($client_ip)) {
            $GLOBALS['waf_fw_analyzed'] = true;
            $result = $engine->analyze_current_request();
            if ($result['status'] === 'blocked') {
                status_header(403);
                header('HTTP/1.1 403 Forbidden', true, 403);
                header('X-Protected-By: MDefender-Pro-WAAP');
                header('Connection: close');
                include WAF_FW_PLUGIN_DIR . 'block-page-template.php';
                exit;
            }
        }
    }

    // Intercept hosting administration & cPanel redirect probes immediately
    $req_uri = $_SERVER['REQUEST_URI'] ?? '';
    if (preg_match('#^/(?:cpanel|whm|webmail|cpsrvd|kpanel|2082|2083|2086|2087|2095|2096)(?:/|\?|$)#i', $req_uri)) {
        $GLOBALS['waf_fw_analyzed'] = true;
        if ($engine) {
            $client_ip = $engine->get_client_ip();
            if (class_exists('WAF_FW_IP_Filter')) {
                WAF_FW_IP_Filter::instance()->add_to_blacklist($client_ip, 'Hosting control panel probe (/cpanel or port redirect)');
            }
        }
        include WAF_FW_PLUGIN_DIR . 'dead-network-template.php';
        exit;
    }

    // In wp-admin panel, authenticated administrators are bypassed for routine administrative tasks
    // BUT file editing (theme/plugin editor) and file uploads are ALWAYS inspected to prevent backdoor persistence
    if (is_admin() && function_exists('is_user_logged_in') && is_user_logged_in() && function_exists('current_user_can') && current_user_can('manage_options')) {
        if (isset($_POST['newcontent']) || !empty($_FILES)) {
            // Must inspect to prevent backdoor injection or web shell upload
        } elseif (empty($_GET['waf_test']) && empty($_POST['waf_test'])) {
            return;
        }
    }

    if (defined('REST_REQUEST') && REST_REQUEST) {
        waf_fw_analyze_rest_request();
        return;
    }

    $GLOBALS['waf_fw_analyzed'] = true;
    if (!$engine) {
        $engine = WAF_FW_Engine::instance();
    }
    $result = $engine->analyze_current_request();

    if ($result['status'] === 'blocked') {
        $atype = $result['attack_type'] ?? '';

        status_header(403);
        header('HTTP/1.1 403 Forbidden', true, 403);
        header('X-Protected-By: MDefender-Pro-WAAP');
        header('Connection: close');
        include WAF_FW_PLUGIN_DIR . 'block-page-template.php';

        // Immediately flush all output buffers to the browser (< 0.1ms delivery)
        while (ob_get_level() > 0) {
            @ob_end_flush();
        }
        @flush();

        if (function_exists('fastcgi_finish_request')) {
            @fastcgi_finish_request();
        }
        if (($result['attack_type'] ?? '') !== 'Blacklisted IP') {
            WAF_FW_Attack_Blocker::instance()->track_attack($result['ip']);
        }
        // Send telemetry asynchronously without delaying the visitor
        WAF_FW_Engine::flush_telemetry();
        exit;
    }
}
// Hook early at plugins_loaded priority 1 and keep init priority 1 as fallback
add_action('plugins_loaded', 'waf_fw_analyze_request', 1);
add_action('init', 'waf_fw_analyze_request', 1);

function waf_fw_analyze_rest_request() {
    $GLOBALS['waf_fw_analyzed'] = true;
    $engine = WAF_FW_Engine::instance();
    $route = $_SERVER['REQUEST_URI'] ?? '';
    if (strpos($route, '/wp-json/waf-fw/') !== false) return;

    $result = $engine->analyze_current_request();
    if ($result['status'] === 'blocked') {
        status_header(403);
        header('Content-Type: application/json; charset=UTF-8');
        header('X-Protected-By: MDefender-Pro-WAAP');
        echo json_encode([
            'status' => 'blocked',
            'attack_type' => $result['attack_type'],
            'confidence' => $result['confidence'],
            'reference_id' => $result['reference_id']
        ]);
        if (function_exists('fastcgi_finish_request')) {
            fastcgi_finish_request();
        }
        if (($result['attack_type'] ?? '') !== 'Blacklisted IP') {
            WAF_FW_Attack_Blocker::instance()->track_attack($result['ip']);
        }
        // Immediately flush telemetry so the blocked attack is recorded on cloud dashboard
        WAF_FW_Engine::flush_telemetry();
        exit;
    }
}

add_filter('rest_pre_dispatch', function ($result, $server, $request) {
    if (strpos($request->get_route(), 'waf-fw') !== false) return $result;
    $engine = WAF_FW_Engine::instance();
    $check = $engine->analyze_current_request();
    if ($check['status'] === 'blocked') {
        if (($check['attack_type'] ?? '') !== 'Blacklisted IP') {
            WAF_FW_Attack_Blocker::instance()->track_attack($check['ip']);
        }
        return new WP_Error('waf_blocked', 'Request blocked by WAF', ['status' => 403]);
    }
    return $result;
}, 1, 3);

// Secure Backup Archive Direct Download Handler
add_action('admin_init', function() {
    if (isset($_GET['action']) && $_GET['action'] === 'waf_fw_download_backup' && current_user_can('manage_options')) {
        $nonce = $_GET['_wpnonce'] ?? '';
        if (!wp_verify_nonce($nonce, 'waf_fw_download_backup') && !wp_verify_nonce($nonce, 'waf_fw_ajax')) {
            wp_die(__('Security check failed for backup download.', 'mdefender-pro'), __('Access Denied', 'mdefender-pro'), ['response' => 403]);
        }
        $file = sanitize_file_name($_GET['file'] ?? '');
        $path = wp_normalize_path(WP_CONTENT_DIR . '/mdefender-backups/' . $file);
        if (file_exists($path) && is_readable($path)) {
            if (ob_get_level()) {
                ob_end_clean();
            }
            header('Content-Description: File Transfer');
            header('Content-Type: application/octet-stream');
            header('Content-Disposition: attachment; filename="' . $file . '"');
            header('Expires: 0');
            header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
            header('Pragma: public');
            header('Content-Length: ' . filesize($path));
            readfile($path);
            exit;
        }
    }
});
