<?php
defined('ABSPATH') || exit;

class WAF_FW_Ajax_Handler {
    public function __construct() {
        add_action('wp_ajax_waf_fw_get_stats', [$this, 'get_stats']);
        add_action('wp_ajax_waf_fw_get_dashboard', [$this, 'get_dashboard']);
        add_action('wp_ajax_waf_fw_get_logs', [$this, 'get_logs']);
        add_action('wp_ajax_waf_fw_get_rules', [$this, 'get_rules']);
        add_action('wp_ajax_waf_fw_save_rule', [$this, 'save_rule']);
        add_action('wp_ajax_waf_fw_update_rule', [$this, 'update_rule']);
        add_action('wp_ajax_waf_fw_delete_rule', [$this, 'delete_rule']);
        add_action('wp_ajax_waf_fw_toggle_rule', [$this, 'toggle_rule']);
        add_action('wp_ajax_waf_fw_get_blacklist', [$this, 'get_blacklist']);
        add_action('wp_ajax_waf_fw_add_blacklist', [$this, 'add_blacklist']);
        add_action('wp_ajax_waf_fw_remove_blacklist', [$this, 'remove_blacklist']);
        add_action('wp_ajax_waf_fw_get_settings', [$this, 'get_settings']);
        add_action('wp_ajax_waf_fw_save_settings', [$this, 'save_settings']);
        add_action('wp_ajax_waf_fw_change_password', [$this, 'change_password']);
        add_action('wp_ajax_waf_fw_export_logs', [$this, 'export_logs']);
        add_action('wp_ajax_waf_fw_clear_logs', [$this, 'clear_logs']);
        add_action('wp_ajax_waf_fw_block_ip', [$this, 'block_ip']);
        add_action('wp_ajax_waf_fw_whitelist_ip', [$this, 'whitelist_ip']);
        add_action('wp_ajax_waf_fw_get_live_feed', [$this, 'get_live_feed']);
        add_action('wp_ajax_waf_fw_toggle_protection', [$this, 'toggle_protection']);
        add_action('wp_ajax_waf_fw_clean_stats', [$this, 'clean_stats']);

        add_action('wp_ajax_waf_fw_scan_website', [$this, 'scan_website']);
        add_action('wp_ajax_waf_fw_get_scan_history', [$this, 'get_scan_history']);
        add_action('wp_ajax_waf_fw_test_ml_connection', [$this, 'test_ml_connection']);
        add_action('wp_ajax_waf_fw_get_ml_status', [$this, 'get_ml_status']);
        add_action('wp_ajax_waf_fw_get_cloud_dashboard', [$this, 'get_cloud_dashboard']);
        add_action('wp_ajax_waf_fw_complete_onboarding', [$this, 'complete_onboarding']);
        add_action('wp_ajax_waf_fw_get_backups', [$this, 'get_backups']);
        add_action('wp_ajax_waf_fw_clean_file', [$this, 'clean_file']);
        add_action('wp_ajax_waf_fw_restore_file', [$this, 'restore_file']);
        add_action('wp_ajax_waf_fw_delete_backup', [$this, 'delete_backup']);

        add_action('wp_ajax_waf_fw_start_progressive_scan', [$this, 'start_progressive_scan']);
        add_action('wp_ajax_waf_fw_continue_scan', [$this, 'continue_scan']);
        add_action('wp_ajax_waf_fw_get_scan_status', [$this, 'get_scan_status_ajax']);
        add_action('wp_ajax_waf_fw_get_file_integrity_status', [$this, 'get_file_integrity_status']);
        add_action('wp_ajax_waf_fw_get_file_changes', [$this, 'get_file_changes_ajax']);
        add_action('wp_ajax_waf_fw_save_scheduled_scan_settings', [$this, 'save_scheduled_scan_settings']);
        add_action('wp_ajax_waf_fw_clear_scan_history', [$this, 'clear_scan_history']);
        add_action('wp_ajax_waf_fw_pause_scan', [$this, 'pause_scan']);
        add_action('wp_ajax_waf_fw_cancel_scan', [$this, 'cancel_scan']);
        add_action('wp_ajax_waf_fw_email_scan_report', [$this, 'email_scan_report']);
        add_action('wp_ajax_waf_fw_get_scan_metrics', [$this, 'get_scan_metrics']);
        add_action('wp_ajax_waf_fw_get_scan_stage_detail', [$this, 'get_scan_stage_detail']);
        add_action('wp_ajax_waf_harden_apply', [$this, 'harden_apply']);
        add_action('wp_ajax_waf_fw_get_active_or_last_scan', [$this, 'get_active_or_last_scan']);
        add_action('wp_ajax_waf_harden_remove', [$this, 'harden_remove']);
        add_action('wp_ajax_waf_harden_one_click', [$this, 'harden_one_click']);
        add_action('wp_ajax_waf_harden_report', [$this, 'harden_report']);
        add_action('wp_ajax_waf_harden_get_status', [$this, 'harden_get_status']);
        add_action('wp_ajax_waf_harden_admin_ip_save', [$this, 'harden_admin_ip_save']);
        add_action('wp_ajax_waf_harden_apply_profile', [$this, 'harden_apply_profile']);
        add_action('wp_ajax_waf_harden_create_baseline', [$this, 'harden_create_baseline']);
        add_action('wp_ajax_waf_harden_check_drift', [$this, 'harden_check_drift']);
        add_action('wp_ajax_waf_harden_remediate_drift', [$this, 'harden_remediate_drift']);
        add_action('wp_ajax_waf_harden_rollback', [$this, 'harden_rollback']);
        add_action('wp_ajax_waf_harden_scan_integrity', [$this, 'harden_scan_integrity']);
        add_action('wp_ajax_waf_harden_scan_uploads', [$this, 'harden_scan_uploads']);
        add_action('wp_ajax_waf_harden_db_audit', [$this, 'harden_db_audit']);
        add_action('wp_ajax_waf_harden_scan_permissions', [$this, 'harden_scan_permissions']);
        add_action('wp_ajax_waf_harden_fix_permissions', [$this, 'harden_fix_permissions']);
        add_action('wp_ajax_waf_harden_fix_single_permission', [$this, 'harden_fix_single_permission']);
        add_action('wp_ajax_waf_harden_apply_recommended_headers', [$this, 'harden_apply_recommended_headers']);
        add_action('wp_ajax_waf_harden_get_activity_log', [$this, 'harden_get_activity_log']);
        add_action('wp_ajax_waf_harden_clear_activity_log', [$this, 'harden_clear_activity_log']);
        add_action('wp_ajax_waf_fw_whois_lookup', [$this, 'whois_lookup']);
        add_action('wp_ajax_waf_fw_delete_scan_file', [$this, 'delete_scan_file']);
        add_action('wp_ajax_waf_fw_restore_core_file', [$this, 'restore_core_file']);
        add_action('wp_ajax_waf_fw_diff_core_file', [$this, 'diff_core_file']);
        add_action('wp_ajax_waf_fw_bulk_restore_core_files', [$this, 'bulk_restore_core_files']);
        add_action('wp_ajax_waf_fw_bulk_clean_malware', [$this, 'bulk_clean_malware']);
        add_action('wp_ajax_waf_fw_view_scan_file', [$this, 'view_scan_file']);
        add_action('wp_ajax_waf_fw_ignore_scan_issue', [$this, 'ignore_scan_issue']);
        add_action('wp_ajax_waf_fw_get_admin_attacks', [$this, 'get_admin_attacks']);
        add_action('wp_ajax_waf_fw_get_security_events', [$this, 'get_security_events']);
        add_action('wp_ajax_waf_fw_get_real_metrics', [$this, 'get_real_metrics']);
        add_action('wp_ajax_waf_fw_get_diagnostics', [$this, 'get_diagnostics']);
        add_action('wp_ajax_waf_fw_create_backup', [$this, 'create_backup_ajax']);
        add_action('wp_ajax_waf_fw_restore_backup', [$this, 'restore_backup_ajax']);
        add_action('wp_ajax_waf_fw_delete_site_backup', [$this, 'delete_site_backup_ajax']);
        add_action('wp_ajax_waf_fw_get_backups', [$this, 'get_backups_ajax']);
        add_action('wp_ajax_waf_fw_save_backup_schedule', [$this, 'save_backup_schedule_ajax']);
        add_action('wp_ajax_waf_fw_upload_backup', [$this, 'upload_backup_ajax']);

        // Core Integrity & Post-Hack Recovery Actions (Wordfence/Sucuri inspired)
        add_action('wp_ajax_waf_tools_core_integrity_scan', [$this, 'tools_core_integrity_scan']);
        add_action('wp_ajax_waf_tools_core_integrity_restore', [$this, 'tools_core_integrity_restore']);
        add_action('wp_ajax_waf_tools_core_integrity_delete_unknown', [$this, 'tools_core_integrity_delete_unknown']);
        add_action('wp_ajax_waf_tools_posthack_terminate_sessions', [$this, 'tools_posthack_terminate_sessions']);
        add_action('wp_ajax_waf_tools_posthack_regenerate_salts', [$this, 'tools_posthack_regenerate_salts']);
        add_action('wp_ajax_waf_tools_posthack_force_password_reset', [$this, 'tools_posthack_force_password_reset']);
        add_action('wp_ajax_waf_tools_posthack_audit_admins', [$this, 'tools_posthack_audit_admins']);
        add_action('wp_ajax_waf_tools_posthack_check_pwned', [$this, 'tools_posthack_check_pwned']);
        add_action('wp_ajax_waf_tools_posthack_toggle_lockdown', [$this, 'tools_posthack_toggle_lockdown']);

        // Diagnostics 1-Click Component Updater & Outdated Vulnerability Checker
        add_action('wp_ajax_waf_diagnostics_update_component', [$this, 'diagnostics_update_component']);
        add_action('wp_ajax_waf_diagnostics_check_updates', [$this, 'diagnostics_check_updates']);
    }

    private function check_access() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Unauthorized'], 403);
        }
    }

    /**
     * CSRF protection for mutating AJAX endpoints. Verifies the plugin nonce
     * is present in the request or confirms valid administrator privileges.
     */
    private function verify_nonce() {
        $nonce = $_REQUEST['nonce'] ?? $_SERVER['HTTP_X_WP_NONCE'] ?? '';
        if (empty($nonce)) {
            $raw = json_decode(file_get_contents('php://input'), true);
            if (is_array($raw) && !empty($raw['nonce'])) {
                $nonce = sanitize_text_field($raw['nonce']);
            }
        }
        if (!empty($nonce) && wp_verify_nonce($nonce, 'waf_fw_ajax')) {
            return;
        }
        if (current_user_can('manage_options')) {
            return;
        }
        wp_send_json_error(['message' => 'Security check failed'], 403);
    }

    /**
     * Safely parses JSON or form POST payloads across all web server environments.
     */
    private function get_json_input() {
        $raw = file_get_contents('php://input');
        if (!empty($raw)) {
            $data = json_decode($raw, true);
            if (is_array($data)) {
                return $data;
            }
        }
        if (!empty($_POST)) {
            $first_key = array_key_first($_POST);
            if (is_string($first_key) && str_starts_with(trim($first_key), '{')) {
                $json_parsed = json_decode($first_key, true);
                if (is_array($json_parsed)) {
                    return $json_parsed;
                }
            }
            return $_POST;
        }
        return [];
    }

    public function get_stats() {
        $this->check_access();
        $logger = WAF_FW_Logger::instance();
        $stats = $logger->get_stats();
        wp_send_json_success($stats);
    }

    public function get_dashboard() {
        $this->check_access();
        $logger = WAF_FW_Logger::instance();
        $data = $logger->get_dashboard_data();
        wp_send_json_success($data);
    }

    public function get_live_feed() {
        $this->check_access();
        $logger = WAF_FW_Logger::instance();
        $logs = $logger->get_logs(['per_page' => 15]);
        wp_send_json_success($logs);
    }

    public function toggle_protection() {
        $this->check_access();
        $this->verify_nonce();
        $enabled = !empty($_POST['enabled']);
        update_option('waf_fw_protection_enabled', $enabled ? 'yes' : 'no');
        wp_send_json_success(['enabled' => $enabled]);
    }

    public function clean_stats() {
        $this->check_access();
        $this->verify_nonce();
        $type = sanitize_text_field($_POST['type'] ?? '');
        $logger = WAF_FW_Logger::instance();

        switch ($type) {
            case 'total_requests':
                $logger->clean_requests();
                break;
            case 'blocked_requests':
                $logger->clean_blocked();
                break;
            case 'threats_detected':
                $logger->clean_threats();
                break;
            default:
                wp_send_json_error(['message' => 'Invalid clean type']);
        }

        wp_send_json_success(['message' => 'Stats cleaned successfully', 'type' => $type]);
    }

    public function get_logs() {
        $this->check_access();
        $logger = WAF_FW_Logger::instance();
        $logs = $logger->get_logs($_GET);
        wp_send_json_success($logs);
    }

    public function get_rules() {
        $this->check_access();
        $engine = WAF_FW_Rule_Engine::instance();
        $rules = [];
        foreach ($engine->get_rules() as $i => $rule) {
            $rule['id'] = $i;
            $rules[] = $rule;
        }
        wp_send_json_success($rules);
    }

    public function save_rule() {
        $this->check_access();
        $this->verify_nonce();
        $data = $this->get_json_input();
        $engine = WAF_FW_Rule_Engine::instance();
        $engine->add_rule([
            'name' => sanitize_text_field($data['name'] ?? ''),
            'pattern' => $data['pattern'] ?? '',
            'action' => sanitize_text_field($data['action'] ?? 'block'),
            'severity' => sanitize_text_field($data['severity'] ?? 'high'),
        ]);
        wp_send_json_success(['message' => 'Rule created successfully']);
    }

    public function update_rule() {
        $this->check_access();
        $this->verify_nonce();
        $data = $this->get_json_input();
        $id = intval($_REQUEST['id'] ?? $data['id'] ?? -1);
        if ($id < 0) {
            wp_send_json_error(['message' => 'Invalid rule ID']);
        }
        $engine = WAF_FW_Rule_Engine::instance();
        $update = [];
        if (isset($data['name'])) $update['name'] = sanitize_text_field($data['name']);
        if (isset($data['pattern'])) $update['pattern'] = $data['pattern'];
        if (isset($data['action'])) $update['action'] = sanitize_text_field($data['action']);
        if (isset($data['severity'])) $update['severity'] = sanitize_text_field($data['severity']);
        if (isset($data['enabled'])) $update['enabled'] = (bool) $data['enabled'];
        $result = $engine->update_rule($id, $update);
        if ($result) {
            wp_send_json_success(['message' => 'Rule updated']);
        }
        wp_send_json_error(['message' => 'Rule not found']);
    }

    public function delete_rule() {
        $this->check_access();
        $this->verify_nonce();
        $engine = WAF_FW_Rule_Engine::instance();
        $id = intval($_REQUEST['id'] ?? -1);
        if ($engine->delete_rule($id)) {
            wp_send_json_success(['message' => 'Rule deleted']);
        }
        wp_send_json_error(['message' => 'Rule not found']);
    }

    public function toggle_rule() {
        $this->check_access();
        $this->verify_nonce();
        $data = $this->get_json_input();
        $id = intval($_REQUEST['id'] ?? $data['id'] ?? -1);
        $engine = WAF_FW_Rule_Engine::instance();
        $engine->update_rule($id, ['enabled' => !empty($data['enabled'])]);
        wp_send_json_success();
    }

    public function get_blacklist() {
        $this->check_access();
        $filter = WAF_FW_IP_Filter::instance();
        wp_send_json_success($filter->get_blacklist());
    }

    public function add_blacklist() {
        $this->check_access();
        $this->verify_nonce();
        $data = $this->get_json_input();
        $ip = sanitize_text_field($_POST['ip'] ?? $data['ip'] ?? $_REQUEST['ip'] ?? '');
        $reason = sanitize_text_field($_POST['reason'] ?? $data['reason'] ?? $_REQUEST['reason'] ?? 'Manually blocked');
        $type = sanitize_text_field($_POST['type'] ?? $data['type'] ?? $_REQUEST['type'] ?? 'permanent');
        if (empty($ip)) {
            wp_send_json_error(['message' => 'IP is required']);
        }
        $filter = WAF_FW_IP_Filter::instance();
        $filter->add_to_blacklist($ip, $reason, $type, false);
        wp_send_json_success(['message' => "IP $ip blocked"]);
    }

    public function remove_blacklist() {
        $this->check_access();
        $this->verify_nonce();
        $data = $this->get_json_input();
        $ip = sanitize_text_field($_POST['ip'] ?? $_REQUEST['ip'] ?? $data['ip'] ?? '');
        if (empty($ip)) {
            wp_send_json_error(['message' => 'IP is required']);
        }
        $filter = WAF_FW_IP_Filter::instance();
        $filter->remove_from_blacklist($ip);
        wp_send_json_success(['message' => "IP $ip unblocked"]);
    }

    public function get_settings() {
        $this->check_access();
        wp_send_json_success([
            'security_level' => get_option('waf_fw_security_level', 'high'),
            'confidence_threshold' => (float) get_option('waf_fw_confidence_threshold', 0.7),
            'rate_limit' => (int) get_option('waf_fw_rate_limit', 100),
            'ml_api_url' => (strpos(get_option('waf_fw_ml_api_url', ''), 'localhost:8000') !== false || !get_option('waf_fw_ml_api_url') || get_option('waf_fw_ml_api_url') === 'http://217.15.170.82') ? 'https://mdefender-pro.crafix.tech' : get_option('waf_fw_ml_api_url'),
            'ml_api_key' => get_option('waf_fw_ml_api_key', ''),
            'website_id' => get_option('waf_fw_website_id', ''),
            'cloud_mode' => get_option('waf_fw_cloud_mode', 'protect'),
            'cloud_scope' => get_option('waf_fw_cloud_scope', 'signal'),
            'connected' => get_option('waf_fw_connected', 'no'),
            'connected_at' => get_option('waf_fw_connected_at', ''),
            'block_message' => get_option('waf_fw_block_message', 'This request has been blocked by Web Application Firewall'),
            'block_colors' => get_option('waf_fw_block_colors', '#667eea,#764ba2'),
            'email_alerts' => get_option('waf_fw_email_alerts', 'no'),
            'log_retention_days' => (int) get_option('waf_fw_log_retention_days', 30),
            'login_lockout_enabled' => get_option('waf_fw_login_lockout_enabled', 'yes'),
            'login_threshold' => (int) get_option('waf_fw_login_threshold', 10),
            'login_block_duration' => (int) get_option('waf_fw_login_block_duration', 86400),
            'attack_blocker_enabled' => get_option('waf_fw_attack_blocker_enabled', 'yes'),
            'attack_threshold' => (int) get_option('waf_fw_attack_threshold', 20),
            'attack_block_duration' => (int) get_option('waf_fw_attack_block_duration', 86400),
            'attack_window' => (int) get_option('waf_fw_attack_window', 86400),
            'protection_enabled' => get_option('waf_fw_protection_enabled', 'yes'),
            'main_waf_api_url' => get_option('waf_fw_main_waf_api_url', 'https://mdefender-pro.crafix.tech/api'),
            'main_waf_admin_url' => get_option('waf_fw_main_waf_admin_url', 'https://mdefender-pro.crafix.tech'),
            'scheduled_scan_enabled' => get_option('waf_fw_scheduled_scan_enabled', 'no'),
            'scheduled_scan_frequency' => get_option('waf_fw_scheduled_scan_frequency', 'weekly'),
            'scheduled_scan_type' => get_option('waf_fw_scheduled_scan_type', 'full'),
            'learning_mode' => get_option('waf_fw_learning_mode', 'no'),
            'blocked_countries' => get_option('waf_fw_blocked_countries', ''),
            'turnstile_enabled' => get_option('waf_fw_turnstile_enabled', get_option('waf_turnstile_enabled', 'no')),
            'turnstile_mode' => get_option('waf_fw_turnstile_mode', get_option('waf_turnstile_mode', 'login_only')),
            'turnstile_theme' => get_option('waf_fw_turnstile_theme', get_option('waf_turnstile_theme', 'auto')),
        ]);
    }

    public function save_settings() {
        $this->check_access();
        $data = $this->get_json_input();
        $allowed = [
            'security_level', 'confidence_threshold', 'rate_limit',
            'ml_api_url', 'ml_api_key', 'website_id', 'cloud_mode', 'cloud_scope',
            'block_message', 'block_colors',
            'email_alerts', 'log_retention_days',
            'login_lockout_enabled', 'login_threshold', 'login_block_duration',
            'attack_blocker_enabled', 'attack_threshold', 'attack_block_duration', 'attack_window',
            'main_waf_api_url', 'main_waf_admin_url',
            'learning_mode', 'blocked_countries',
            'dashboard_url',
            'turnstile_enabled', 'turnstile_mode', 'turnstile_theme',
        ];

        if (isset($data['learning_mode'])) {
            WAF_FW_Engine::instance()->set_learning_mode($data['learning_mode'] === 'yes');
        }

        if (isset($data['turnstile_enabled'])) {
            $val = $data['turnstile_enabled'] === 'yes' ? 'yes' : 'no';
            update_option('waf_fw_turnstile_enabled', $val);
            update_option('waf_turnstile_enabled', $val);
        }
        if (isset($data['turnstile_mode'])) {
            $mode = in_array($data['turnstile_mode'], ['login_only', 'site_wide'], true) ? $data['turnstile_mode'] : 'login_only';
            update_option('waf_fw_turnstile_mode', $mode);
            update_option('waf_turnstile_mode', $mode);
        }
        if (isset($data['turnstile_theme'])) {
            $theme = sanitize_text_field($data['turnstile_theme']);
            update_option('waf_fw_turnstile_theme', $theme);
            update_option('waf_turnstile_theme', $theme);
        }
        
        foreach ($allowed as $key) {
            if (isset($data[$key])) {
                if ($key === 'cloud_mode' && !in_array($data[$key], ['monitor', 'protect', 'off'], true)) {
                    continue;
                }
                if ($key === 'cloud_scope' && !in_array($data[$key], ['signal', 'all'], true)) {
                    continue;
                }
                update_option('waf_fw_' . $key, $data[$key]);
            }
        }

        // Ensure default cloud API URL is set
        $ml_url = get_option('waf_fw_ml_api_url', '');
        if (empty($ml_url) || strpos($ml_url, 'onrender.com') !== false || strpos($ml_url, 'mdefender-pro.io') !== false || $ml_url === 'http://217.15.170.82') {
            update_option('waf_fw_ml_api_url', 'https://mdefender-pro.crafix.tech');
        }

        // Cloud credentials changed -> attempt a connect handshake so the
        // dashboard marks this site online immediately.
        $connection = null;
        if (isset($data['ml_api_key']) || isset($data['ml_api_url']) || isset($data['website_id'])) {
            $ml_key = get_option('waf_fw_ml_api_key', '');
            if (empty($ml_key)) {
                update_option('waf_fw_connected', 'no');
                update_option('waf_fw_site_token', '');
                update_option('waf_fw_website_id', '');
                $connection = [
                    'success' => false,
                    'message' => 'Disconnected from cloud.',
                ];
            } else {
                $client = WAF_FW_ML_Api_Client::instance();
                $connection = $client->connect();
                if (!empty($connection['success'])) {
                    update_option('waf_fw_connected', 'yes');
                    if (function_exists('waf_fw_sync_cloud_blacklist_fast')) {
                        waf_fw_sync_cloud_blacklist_fast(true);
                    }
                } else {
                    update_option('waf_fw_connected', 'no');
                    // Never delete/erase the user's entered API key!
                }
            }
        }

        if (class_exists('WAF_FW_Engine')) {
            WAF_FW_Engine::instance()->export_fast_cache();
        }

        $response = ['message' => 'Settings saved'];
        if ($connection !== null) {
            $response['connected'] = !empty($connection['success']);
            $response['connection_message'] = $connection['message'];
        } else {
            $response['connected'] = get_option('waf_fw_connected', 'no') === 'yes';
            $response['connection_message'] = $response['connected'] ? 'Cloud service connected.' : 'Not connected.';
        }
        wp_send_json_success($response);
    }

    public function change_password() {
        $this->check_access();
        $this->verify_nonce();
        $data = json_decode(file_get_contents('php://input'), true);
        $old = $data['old_password'] ?? '';
        $new = $data['new_password'] ?? '';
        $stored = get_option('waf_fw_admin_password');
        if (empty($stored)) {
            if (empty($new)) {
                wp_send_json_error(['message' => 'New password is required']);
            }
            update_option('waf_fw_admin_password', wp_hash_password($new));
            wp_send_json_success(['message' => 'Password set successfully']);
        }
        if (!wp_check_password($old, $stored)) {
            wp_send_json_error(['message' => 'Current password is incorrect']);
        }
        update_option('waf_fw_admin_password', wp_hash_password($new));
        wp_send_json_success(['message' => 'Password changed successfully']);
    }

    public function clear_logs() {
        $this->check_access();
        $this->verify_nonce();
        $logger = WAF_FW_Logger::instance();
        $logger->clear_logs();
        wp_send_json_success(['message' => 'All logs cleared']);
    }

    public function block_ip() {
        $this->check_access();
        $this->verify_nonce();
        $data = $this->get_json_input();
        $ip = sanitize_text_field($_POST['ip'] ?? $data['ip'] ?? $_REQUEST['ip'] ?? '');
        $reason = sanitize_text_field($_POST['reason'] ?? $data['reason'] ?? 'Manually blocked from attack log details');
        if (empty($ip)) {
            wp_send_json_error(['message' => 'IP address is required']);
        }
        $filter = WAF_FW_IP_Filter::instance();
        $filter->add_to_blacklist($ip, $reason, 'permanent', false);

        // Also add to local cloud blacklist cache and refresh fast cache
        $cached_bl = get_option('waf_fw_local_blacklist_cache', []);
        if (is_array($cached_bl)) {
            $cached_bl[] = $ip;
            update_option('waf_fw_local_blacklist_cache', array_values(array_unique($cached_bl)));
        }
        if (class_exists('WAF_FW_Engine')) {
            WAF_FW_Engine::instance()->export_fast_cache();
        }

        wp_send_json_success(['message' => "IP $ip blacklisted successfully"]);
    }

    public function whitelist_ip() {
        $this->check_access();
        $this->verify_nonce();
        $data = $this->get_json_input();
        $ip = sanitize_text_field($_POST['ip'] ?? $data['ip'] ?? $_REQUEST['ip'] ?? '');
        $reason = sanitize_text_field($_POST['reason'] ?? $data['reason'] ?? 'Whitelisted from attack log details');
        if (empty($ip)) {
            wp_send_json_error(['message' => 'IP address is required']);
        }
        $filter = WAF_FW_IP_Filter::instance();
        $filter->add_to_whitelist($ip, $reason);

        // Remove from local cloud blacklist cache as well
        $cached_bl = get_option('waf_fw_local_blacklist_cache', []);
        if (is_array($cached_bl)) {
            $cached_bl = array_values(array_diff($cached_bl, [$ip]));
            update_option('waf_fw_local_blacklist_cache', $cached_bl);
        }
        if (class_exists('WAF_FW_Engine')) {
            WAF_FW_Engine::instance()->export_fast_cache();
        }

        wp_send_json_success(['message' => "IP $ip added to Whitelist successfully"]);
    }

    public function export_logs() {
        $this->check_access();
        $logger = WAF_FW_Logger::instance();
        $logs = $logger->get_logs(array_merge($_GET, ['per_page' => 10000]));
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="waf-logs-' . date('Y-m-d') . '.csv"');
        $out = fopen('php://output', 'w');
        fputcsv($out, ['IP', 'URL', 'Method', 'Attack Type', 'Confidence', 'Status', 'Rule Matched', 'Timestamp']);
        foreach ($logs['logs'] as $log) {
            fputcsv($out, [
                $log->ip, $log->url, $log->method, $log->attack_type,
                $log->confidence, $log->status, $log->rule_matched, $log->created_at,
            ]);
        }
        fclose($out);
        exit;
    }

    public function scan_website() {
        $this->check_access();
        $this->verify_nonce();
        $data = json_decode(file_get_contents('php://input'), true);
        $scan_type = sanitize_text_field($data['scan_type'] ?? 'full');
        $scanner = WAF_FW_Scanner::instance();
        $result = $scanner->scan_website($scan_type);
        if ($result['success']) {
            wp_send_json_success($result);
        } else {
            wp_send_json_error(['message' => 'Scan failed']);
        }
    }

    public function get_scan_history() {
        $this->check_access();
        $scanner = WAF_FW_Scanner::instance();
        $history = $scanner->get_scan_history();
        wp_send_json_success($history);
    }

    public function get_active_or_last_scan() {
        $this->check_access();
        global $wpdb;
        $queue_table = WAF_FW_DB::instance()->get_scan_queue_table();
        $results_table = WAF_FW_DB::instance()->get_scan_results_table();
        
        // Clean up stale scans older than 2 minutes
        $wpdb->query("UPDATE $queue_table SET status = 'interrupted' WHERE status = 'running' AND created_at < DATE_SUB(NOW(), INTERVAL 2 MINUTE)");

        $requested_id = intval($_REQUEST['scan_id'] ?? 0);

        if ($requested_id > 0) {
            $scan_res = $wpdb->get_row($wpdb->prepare("SELECT * FROM $results_table WHERE id = %d", $requested_id));
            if ($scan_res) {
                $results = !empty($scan_res->vulnerabilities) ? json_decode($scan_res->vulnerabilities, true) : [];
                if (is_string($results)) {
                    $results = json_decode($results, true);
                }
                $summary = !empty($scan_res->summary) ? json_decode($scan_res->summary, true) : [];
                if (is_string($summary)) {
                    $summary = json_decode($summary, true);
                }
                wp_send_json_success([
                    'type' => 'completed',
                    'scan_id' => intval($scan_res->id),
                    'status' => $scan_res->status,
                    'progress' => 100,
                    'score' => intval($scan_res->score),
                    'issues_found' => intval($scan_res->issues_found),
                    'duration' => intval($scan_res->duration_seconds),
                    'results' => is_array($results) ? $results : [],
                    'summary' => is_array($summary) ? $summary : [],
                    'created_at' => $scan_res->created_at,
                ]);
            }
            $scan_q = $wpdb->get_row($wpdb->prepare("SELECT * FROM $queue_table WHERE id = %d", $requested_id));
            if ($scan_q) {
                $results = !empty($scan_q->results) ? json_decode($scan_q->results, true) : [];
                if (is_string($results)) {
                    $results = json_decode($results, true);
                }
                wp_send_json_success([
                    'type' => 'completed',
                    'queue_id' => intval($scan_q->id),
                    'status' => $scan_q->status,
                    'progress' => 100,
                    'score' => intval($scan_q->score ?? 100),
                    'issues_found' => intval($scan_q->issues_found ?? 0),
                    'duration' => intval($scan_q->duration_seconds ?? 0),
                    'results' => is_array($results) ? $results : [],
                    'created_at' => $scan_q->created_at,
                    'completed_at' => $scan_q->completed_at,
                ]);
            }
        }

        // Check for currently running scan in queue
        $running = $wpdb->get_row("SELECT * FROM $queue_table WHERE status = 'running' ORDER BY id DESC LIMIT 1");
        if ($running) {
            wp_send_json_success([
                'type' => 'running',
                'queue_id' => intval($running->id),
                'status' => 'running',
                'progress' => intval($running->progress),
                'current_stage' => $running->current_stage,
                'total_files' => intval($running->total_files),
                'scanned_files' => intval($running->scanned_files),
            ]);
        }

        // Check for latest in results table
        $last_res = $wpdb->get_row("SELECT * FROM $results_table ORDER BY id DESC LIMIT 1");
        if ($last_res) {
            $results = json_decode($last_res->vulnerabilities, true);
            $summary = json_decode($last_res->summary, true);
            wp_send_json_success([
                'type' => 'completed',
                'scan_id' => intval($last_res->id),
                'status' => $last_res->status,
                'progress' => 100,
                'score' => intval($last_res->score),
                'issues_found' => intval($last_res->issues_found),
                'duration' => intval($last_res->duration_seconds),
                'results' => $results,
                'summary' => $summary,
                'created_at' => $last_res->created_at,
            ]);
        }

        // Fallback: Check queue table
        $last = $wpdb->get_row("SELECT * FROM $queue_table WHERE status IN ('completed', 'completed_with_issues') ORDER BY id DESC LIMIT 1");
        if ($last) {
            $results = json_decode($last->results, true);
            wp_send_json_success([
                'type' => 'completed',
                'queue_id' => intval($last->id),
                'status' => $last->status,
                'progress' => 100,
                'score' => intval($last->score),
                'issues_found' => intval($last->issues_found),
                'duration' => intval($last->duration_seconds),
                'results' => $results,
                'created_at' => $last->created_at,
                'completed_at' => $last->completed_at,
            ]);
        }
        
        wp_send_json_success([
            'type' => 'none'
        ]);
    }

    public function clear_scan_history() {
        $this->check_access();
        $this->verify_nonce();
        $scanner = WAF_FW_Scanner::instance();
        $scanner->clear_scan_history();
        wp_send_json_success(['message' => 'Scan history cleared']);
    }

    private function check_harden_access() {
        $this->check_access();
        $this->verify_nonce();
    }

    public function harden_apply() {
        $this->check_harden_access();
        $feature = sanitize_text_field($_POST['feature'] ?? '');
        if (!$feature) wp_send_json_error(['message' => 'No feature specified']);
        $settings = $_POST;
        unset($settings['action'], $settings['feature'], $settings['nonce']);
        $settings = array_map(function($v) { return $v === '1' ? true : ($v === '0' ? false : sanitize_text_field($v)); }, $settings);
        $hardening = WAF_FW_Website_Hardening::instance();
        $method = 'apply_' . $feature;
        if (!method_exists($hardening, $method)) wp_send_json_error(['message' => 'Unknown feature']);
        $result = $hardening->$method($settings);
        wp_send_json_success($result);
    }

    public function harden_remove() {
        $this->check_harden_access();
        $feature = sanitize_text_field($_POST['feature'] ?? '');
        if (!$feature) wp_send_json_error(['message' => 'No feature specified']);
        $hardening = WAF_FW_Website_Hardening::instance();
        $method = 'remove_' . $feature;
        if (!method_exists($hardening, $method)) wp_send_json_error(['message' => 'Unknown feature']);
        $hardening->$method();
        wp_send_json_success(['feature' => $feature, 'status' => 'disabled']);
    }

    public function harden_one_click() {
        $this->check_harden_access();
        $hardening = WAF_FW_Website_Hardening::instance();
        $result = $hardening->one_click_harden();
        wp_send_json_success($result);
    }

    public function harden_report() {
        $this->check_harden_access();
        $hardening = WAF_FW_Website_Hardening::instance();
        $report = $hardening->generate_report();
        wp_send_json_success($report);
    }

    public function harden_get_status() {
        $this->check_harden_access();
        $hardening = WAF_FW_Website_Hardening::instance();
        $status = $hardening->get_status();
        wp_send_json_success($status);
    }

    public function harden_admin_ip_save() {
        $this->check_harden_access();
        $settings = [
            'enabled' => !empty($_POST['enabled']),
            'whitelist' => sanitize_textarea_field($_POST['whitelist'] ?? ''),
            'blocked_countries' => sanitize_text_field($_POST['blocked_countries'] ?? ''),
        ];
        $result = WAF_FW_Admin_Panel_IP::instance()->save_settings($settings);
        wp_send_json_success($result);
    }

    public function harden_apply_profile() {
        $this->check_harden_access();
        $profile = sanitize_key($_POST['profile'] ?? 'balanced');
        $hardening = WAF_FW_Website_Hardening::instance();
        $result = $hardening->apply_profile($profile);
        wp_send_json_success($result);
    }

    public function harden_create_baseline() {
        $this->check_harden_access();
        $hardening = WAF_FW_Website_Hardening::instance();
        $result = $hardening->create_security_baseline();
        wp_send_json_success($result);
    }

    public function harden_check_drift() {
        $this->check_harden_access();
        $hardening = WAF_FW_Website_Hardening::instance();
        $result = $hardening->check_configuration_drift();
        wp_send_json_success($result);
    }

    public function harden_remediate_drift() {
        $this->check_harden_access();
        $control = sanitize_key($_POST['control'] ?? '');
        $hardening = WAF_FW_Website_Hardening::instance();
        $result = $hardening->remediate_drift($control);
        wp_send_json_success($result);
    }

    public function harden_rollback() {
        $this->check_harden_access();
        $snapshot_id = sanitize_key($_POST['snapshot_id'] ?? '');
        $hardening = WAF_FW_Website_Hardening::instance();
        $result = $hardening->rollback_safety_backup($snapshot_id);
        if ($result['success']) {
            wp_send_json_success($result);
        } else {
            wp_send_json_error($result);
        }
    }

    public function harden_scan_integrity() {
        $this->check_harden_access();
        $hardening = WAF_FW_Website_Hardening::instance();
        $result = $hardening->scan_file_integrity();
        wp_send_json_success($result);
    }

    public function harden_scan_uploads() {
        $this->check_harden_access();
        $hardening = WAF_FW_Website_Hardening::instance();
        $result = $hardening->scan_uploads_security();
        wp_send_json_success($result);
    }

    public function harden_db_audit() {
        $this->check_harden_access();
        $hardening = WAF_FW_Website_Hardening::instance();
        $result = $hardening->audit_database_security();
        wp_send_json_success($result);
    }

    public function harden_get_activity_log() {
        $this->check_harden_access();
        $hardening = WAF_FW_Website_Hardening::instance();
        $logs = $hardening->get_activity_log();
        wp_send_json_success(['logs' => $logs]);
    }

    public function harden_clear_activity_log() {
        $this->check_harden_access();
        $hardening = WAF_FW_Website_Hardening::instance();
        $result = $hardening->clear_activity_log();
        wp_send_json_success($result);
    }

    public function harden_scan_permissions() {
        $this->check_harden_access();
        $hardening = WAF_FW_Website_Hardening::instance();
        $result = $hardening->scan_live_file_permissions();
        wp_send_json_success($result);
    }

    public function harden_fix_permissions() {
        $this->check_harden_access();
        $hardening = WAF_FW_Website_Hardening::instance();
        $result = $hardening->fix_all_file_permissions();
        wp_send_json_success($result);
    }

    public function harden_fix_single_permission() {
        $this->check_harden_access();
        $key = sanitize_key($_POST['key'] ?? '');
        $hardening = WAF_FW_Website_Hardening::instance();
        $result = $hardening->fix_single_file_permission($key);
        if ($result['success']) {
            wp_send_json_success($result);
        } else {
            wp_send_json_error($result);
        }
    }

    public function harden_apply_recommended_headers() {
        $this->check_harden_access();
        $hardening = WAF_FW_Website_Hardening::instance();
        $result = $hardening->apply_recommended_security_headers();
        wp_send_json_success($result);
    }

    public function start_progressive_scan() {
        $this->check_access();
        $this->verify_nonce();
        $data = $this->get_json_input();
        $scan_type = sanitize_text_field($data['scan_type'] ?? 'full');

        $scanner = WAF_FW_Scanner::instance();
        $queue_id = $scanner->create_scan_queue($scan_type);

        $result = $scanner->process_scan_cell($queue_id, 0);
        if ($result['success']) {
            wp_send_json_success($result);
        } else {
            wp_send_json_error(['message' => 'Failed to start scan']);
        }
    }

    public function continue_scan() {
        $this->check_access();
        $this->verify_nonce();
        $data = $this->get_json_input();
        $queue_id = intval($data['queue_id'] ?? 0);
        $cell_index = intval($data['cell_index'] ?? 0);

        if (!$queue_id) {
            wp_send_json_error(['message' => 'Invalid scan ID']);
        }

        $scanner = WAF_FW_Scanner::instance();
        $result = $scanner->process_scan_cell($queue_id, $cell_index);
        if ($result['success']) {
            wp_send_json_success($result);
        } else {
            wp_send_json_error(['message' => 'Scan failed']);
        }
    }

    public function get_scan_status_ajax() {
        $this->check_access();
        $queue_id = intval($_GET['queue_id'] ?? 0);

        if (!$queue_id) {
            wp_send_json_error(['message' => 'Invalid scan ID']);
        }

        $scanner = WAF_FW_Scanner::instance();
        $status = $scanner->get_scan_status($queue_id);
        if ($status) {
            wp_send_json_success($status);
        } else {
            wp_send_json_error(['message' => 'Scan not found']);
        }
    }

    public function get_file_integrity_status() {
        $this->check_access();
        global $wpdb;
        $table = WAF_FW_DB::instance()->get_file_integrity_table();
        $total_files = $wpdb->get_var("SELECT COUNT(*) FROM $table");
        $modified_files = $wpdb->get_var("SELECT COUNT(*) FROM $table WHERE status = 'modified'");
        $new_files = $wpdb->get_var("SELECT COUNT(*) FROM $table WHERE status = 'new'");

        $changes_table = WAF_FW_DB::instance()->get_file_changes_table();
        $recent_changes = $wpdb->get_results(
            "SELECT * FROM $changes_table ORDER BY detected_at DESC LIMIT 20"
        );

        wp_send_json_success([
            'total_files' => (int) $total_files,
            'modified_files' => (int) $modified_files,
            'new_files' => (int) $new_files,
            'integrity_db_populated' => $total_files > 0,
            'recent_changes' => $recent_changes,
        ]);
    }

    public function get_file_changes_ajax() {
        $this->check_access();
        $scanner = WAF_FW_Scanner::instance();
        $changes = $scanner->check_file_changes();

        wp_send_json_success([
            'changes' => $changes,
            'count' => count($changes),
            'timestamp' => current_time('mysql'),
        ]);
    }

    public function save_scheduled_scan_settings() {
        $this->check_access();
        $this->verify_nonce();
        $data = json_decode(file_get_contents('php://input'), true);
        $enabled = !empty($data['enabled']) ? 'yes' : 'no';
        $frequency = sanitize_text_field($data['frequency'] ?? 'weekly');
        $scan_type = sanitize_text_field($data['scan_type'] ?? 'full');

        update_option('waf_fw_scheduled_scan_enabled', $enabled);
        update_option('waf_fw_scheduled_scan_frequency', $frequency);
        update_option('waf_fw_scheduled_scan_type', $scan_type);

        wp_clear_scheduled_hook('waf_fw_scheduled_scan');
        if ($enabled === 'yes') {
            $schedule = in_array($frequency, ['daily', 'weekly']) ? $frequency : 'weekly';
            wp_schedule_event(time(), $schedule, 'waf_fw_scheduled_scan');
        }

        wp_send_json_success(['message' => 'Scheduled scan settings saved']);
    }

    public function test_ml_connection() {
        $this->check_access();
        $this->verify_nonce();
        $ml_client = WAF_FW_ML_Api_Client::instance();
        $result = $ml_client->test_connection();
        if ($result['success']) {
            if (function_exists('waf_fw_sync_cloud_blacklist_fast')) {
                waf_fw_sync_cloud_blacklist_fast(true);
            }
            wp_send_json_success($result);
        } else {
            wp_send_json_error($result);
        }
    }

    public function get_ml_status() {
        $this->check_access();
        $ml_client = WAF_FW_ML_Api_Client::instance();
        $status = $ml_client->get_status();
        $status['api_url'] = get_option('waf_fw_ml_api_url', '');
        $status['has_api_key'] = !empty(get_option('waf_fw_ml_api_key', ''));
        $status['has_website_id'] = !empty(get_option('waf_fw_website_id', ''));
        $status['main_waf_url'] = get_option('waf_fw_main_waf_api_url', 'http://localhost:8000/api');
        wp_send_json_success($status);
    }

    /** Cloud dashboard stats: recent cloud events + malware findings. */
    public function get_cloud_dashboard() {
        $this->check_access();
        $ml_client = WAF_FW_ML_Api_Client::instance();
        if (!$ml_client->is_available()) {
            wp_send_json_error(['message' => 'Cloud service not connected. Add your Website API key in Settings.']);
        }
        $events = $ml_client->get_events(50);
        $findings = $ml_client->get_findings(50);
        wp_send_json_success([
            'connected' => get_option('waf_fw_connected', 'no'),
            'mode' => get_option('waf_fw_cloud_mode', 'protect'),
            'events' => $events,
            'findings' => $findings,
            'blocked' => count(array_filter($events, function ($e) {
                return in_array($e['action'] ?? '', ['block', 'rate_limit', 'challenge'], true);
            })),
            'malicious_findings' => count(array_filter($findings, function ($f) {
                return ($f['verdict'] ?? '') === 'malicious';
            })),
        ]);
    }

    /** Marks the one-time activation onboarding popup as done. */
    public function complete_onboarding() {
        $this->check_access();
        $this->verify_nonce();
        update_option('waf_fw_onboarding_pending', 'no');
        wp_send_json_success(['message' => 'Onboarding completed.']);
    }

    public function pause_scan() {
        $this->check_access();
        $this->verify_nonce();
        $data = json_decode(file_get_contents('php://input'), true);
        $queue_id = intval($data['queue_id'] ?? 0);
        if (!$queue_id) {
            wp_send_json_error(['message' => 'Invalid scan ID']);
        }
        global $wpdb;
        $table = WAF_FW_DB::instance()->get_scan_queue_table();
        $wpdb->update($table, [
            'status' => 'paused',
            'current_stage' => 'Paused by user',
        ], ['id' => $queue_id]);
        wp_send_json_success(['message' => 'Scan paused', 'queue_id' => $queue_id]);
    }

    public function cancel_scan() {
        $this->check_access();
        $this->verify_nonce();
        $data = json_decode(file_get_contents('php://input'), true);
        $queue_id = intval($data['queue_id'] ?? 0);
        if (!$queue_id) {
            wp_send_json_error(['message' => 'Invalid scan ID']);
        }
        global $wpdb;
        $table = WAF_FW_DB::instance()->get_scan_queue_table();
        $wpdb->update($table, [
            'status' => 'cancelled',
            'current_stage' => 'Cancelled by user',
            'completed_at' => current_time('mysql'),
        ], ['id' => $queue_id]);
        wp_send_json_success(['message' => 'Scan cancelled']);
    }

    public function email_scan_report() {
        $this->check_access();
        $this->verify_nonce();
        $data = json_decode(file_get_contents('php://input'), true);
        $scan_id = intval($data['scan_id'] ?? 0);
        $custom_email = sanitize_email($data['email'] ?? '');

        global $wpdb;
        $table = WAF_FW_DB::instance()->get_scan_results_table();
        $scan = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE id = %d", $scan_id));
        if (!$scan) {
            $scan = $wpdb->get_row("SELECT * FROM $table ORDER BY created_at DESC LIMIT 1");
        }
        if (!$scan) {
            wp_send_json_error(['message' => 'No scan results found']);
        }

        $results = json_decode($scan->vulnerabilities, true);
        $summary = json_decode($scan->summary, true);
        $email = !empty($custom_email) ? $custom_email : get_option('admin_email');
        $site_name = get_bloginfo('name');
        $score = $scan->score;
        $status_label = $summary['security_status']['label'] ?? 'Unknown';

        $subject = sprintf('[%s] Security Scan Report - %s (Score: %d/100)', $site_name, $status_label, $score);

        $body = "═══════════════════════════════════════════\n";
        $body .= "  SECURITY SCAN REPORT - {$site_name}\n";
        $body .= "═══════════════════════════════════════════\n\n";
        $body .= "Scan Type:     {$scan->scan_type}\n";
        $body .= "Security Score: {$score}/100\n";
        $body .= "Issues Found:  {$scan->issues_found}\n";
        $body .= "Status:        {$status_label}\n";
        $body .= "Duration:      {$scan->duration_seconds}s\n";
        $body .= "Scanned:       {$scan->created_at}\n\n";
        $body .= str_repeat('─', 50) . "\n";

        $module_labels = [
            'basic_checks' => 'Basic Security Checks',
            'headers_check' => 'Security Headers',
            'ssl_check' => 'SSL Certificate',
            'ssl_deep_analysis' => 'SSL/TLS Deep Analysis',
            'wordpress_checks' => 'WordPress Security',
            'waf_test' => 'WAF Protection Test',
            'directory_listing' => 'Directory Listing',
            'xmlrpc_check' => 'XML-RPC Security',
            'cors_check' => 'CORS Configuration',
            'cookie_security' => 'Cookie Security',
            'file_upload_check' => 'File Upload Security',
            'php_info_exposure' => 'PHP Info Exposure',
            'vulnerability_scan' => 'Vulnerability Scan',
            'malware_scan' => 'Malware Scan',
            'ml_malware_scan' => 'MDefender ML Malware Scan',
            'db_scan' => 'Database Security',
            'db_integrity' => 'Database Integrity',
            'port_scan' => 'Port Scan',
            'ml_analysis' => 'ML Analysis',
            'password_audit' => 'Password Audit',
            'blocklist_check' => 'Domain Blocklist',
            'fpd_check' => 'Full Path Disclosure',
            'dns_security' => 'DNS Security',
            'rss_spam_check' => 'RSS Spam Check',
            'deprecated_php' => 'Deprecated PHP',
            'file_permissions' => 'File Permissions',
            'server_fingerprint' => 'Server Fingerprint',
            'config_exposure' => 'Config File Exposure',
            'known_files_check' => 'Known File Verification',
        ];

        foreach ($results as $key => $data) {
            if (!isset($module_labels[$key])) continue;
            $label = $module_labels[$key];
            $body .= "\n▸ {$label}\n";

            if (is_array($data)) {
                foreach ($data as $k => $v) {
                    if (is_bool($v)) {
                        $body .= "  " . ($v ? "[!] " : "[OK] ") . $k . "\n";
                    } elseif (is_string($v) || is_int($v)) {
                        $body .= "  • {$k}: {$v}\n";
                    }
                }
            }
        }

        $body .= "\n" . str_repeat('═', 50) . "\n";
        $body .= "Review Details: " . admin_url('admin.php?page=waf-firewall-scan') . "\n";
        $body .= "Generated by: MDefender-Pro Enterprise v" . WAF_FW_VERSION . "\n";

        $sent = wp_mail($email, $subject, $body);
        if ($sent) {
            wp_send_json_success(['message' => 'Scan report sent to ' . $email]);
        } else {
            wp_send_json_error(['message' => 'Failed to send email']);
        }
    }

    public function get_scan_metrics() {
        $this->check_access();
        global $wpdb;
        $metrics = get_option('waf_fw_scan_metrics', []);
        $history_count = $wpdb->get_var("SELECT COUNT(*) FROM " . WAF_FW_DB::instance()->get_scan_results_table());
        $metrics['total_scans'] = (int) $history_count;

        $avg_score = $wpdb->get_var("SELECT AVG(score) FROM " . WAF_FW_DB::instance()->get_scan_results_table() . " WHERE score > 0");
        $metrics['average_score'] = $avg_score ? round($avg_score) : 0;

        wp_send_json_success($metrics);
    }

    public function get_scan_stage_detail() {
        $this->check_access();
        $stage = sanitize_text_field($_GET['stage'] ?? '');
        if (!$stage) {
            wp_send_json_error(['message' => 'No stage specified']);
        }

        $stage_info = [
            'init' => ['label' => 'Initializing Scan', 'description' => 'Preparing scan environment and loading modules', 'icon' => 'download'],
            'basic' => ['label' => 'Basic Security Checks', 'description' => 'Testing common exposure points and admin paths', 'icon' => 'shield'],
            'headers' => ['label' => 'Security Headers', 'description' => 'Checking HTTP security headers (CSP, HSTS, X-Frame-Options)', 'icon' => 'list-view'],
            'ssl' => ['label' => 'SSL Certificate', 'description' => 'Validating SSL certificate and HTTPS configuration', 'icon' => 'lock'],
            'ssl_deep' => ['label' => 'SSL/TLS Deep Analysis', 'description' => 'Testing TLS protocols, cipher suites, and certificate strength', 'icon' => 'lock'],
            'wp_core' => ['label' => 'WordPress Core Security', 'description' => 'Checking WordPress version, settings, and configuration', 'icon' => 'wordpress'],
            'waf_test' => ['label' => 'WAF Protection Test', 'description' => 'Testing WAF against SQLi, XSS, LFI, RCE, SSTI attacks', 'icon' => 'shields'],
            'directories' => ['label' => 'Directory Listing', 'description' => 'Checking for enabled directory browsing', 'icon' => 'folder'],
            'xmlrpc' => ['label' => 'XML-RPC Security', 'description' => 'Testing XML-RPC endpoint for vulnerabilities', 'icon' => 'networking'],
            'cors' => ['label' => 'CORS Configuration', 'description' => 'Checking Cross-Origin Resource Sharing policy', 'icon' => 'admin-links'],
            'cookies' => ['label' => 'Cookie Security', 'description' => 'Auditing cookies for Secure, HttpOnly, and SameSite flags', 'icon' => 'portfolio'],
            'file_upload' => ['label' => 'File Upload Security', 'description' => 'Checking upload directory permissions and PHP execution', 'icon' => 'upload'],
            'php_info' => ['label' => 'PHP Info Exposure', 'description' => 'Scanning for exposed phpinfo() files', 'icon' => 'info'],
            'vulnerabilities' => ['label' => 'Vulnerability Scan', 'description' => 'Checking against known CVEs for WordPress, plugins, and themes', 'icon' => 'warning'],
            'file_changes' => ['label' => 'File Integrity', 'description' => 'Comparing file hashes against known-good baseline', 'icon' => 'edit'],
            'malware' => ['label' => 'Malware Scan', 'description' => 'Deep scan for malware, web shells, backdoors, and suspicious code', 'icon' => 'analytics'],
            'ml_malware' => ['label' => 'MDefender ML Malware Scan', 'description' => 'Files analyzed by the MDefender-Pro malware model for verdicts, risk scores, and malware families', 'icon' => 'rocket'],
            'db_scan' => ['label' => 'Database Security', 'description' => 'Scanning database for injected scripts and suspicious accounts', 'icon' => 'database'],
            'port_scan' => ['label' => 'Port Scan', 'description' => 'Identifying open ports and exposed services', 'icon' => 'networking'],
            'ml_scan' => ['label' => 'ML Analysis', 'description' => 'AI-powered attack detection and pattern analysis', 'icon' => 'rocket'],
            'password_audit' => ['label' => 'Password Audit', 'description' => 'Checking for weak passwords and admin account security', 'icon' => 'admin-users'],
            'blocklist' => ['label' => 'Domain Blocklist', 'description' => 'Checking IP/domain against DNSBL and malware blocklists', 'icon' => 'dismiss'],
            'full_path_disclosure' => ['label' => 'Full Path Disclosure', 'description' => 'Testing for path disclosure vulnerabilities in error messages', 'icon' => 'visibility'],
            'db_integrity' => ['label' => 'Database Integrity', 'description' => 'Checking table integrity, orphaned records, and performance', 'icon' => 'database'],
            'dns_check' => ['label' => 'DNS Security', 'description' => 'Auditing SPF, DMARC, CAA, and DNS configuration', 'icon' => 'admin-network'],
            'rss_spam' => ['label' => 'RSS Spam Check', 'description' => 'Scanning RSS feeds for injected spam content', 'icon' => 'rss'],
            'deprecated_php' => ['label' => 'Deprecated PHP', 'description' => 'Finding deprecated and removed PHP functions in code', 'icon' => 'art'],
            'file_permissions' => ['label' => 'File Permissions', 'description' => 'Auditing critical file and directory permissions', 'icon' => 'admin-generic'],
            'server_fingerprint' => ['label' => 'Server Fingerprint', 'description' => 'Detecting server software, versions, and information disclosure', 'icon' => 'desktop'],
            'config_exposure' => ['label' => 'Config File Exposure', 'description' => 'Scanning for exposed .env, backups, logs, and sensitive files', 'icon' => 'hidden'],
            'known_files' => ['label' => 'Known File Verification', 'description' => 'Verifying core files against WordPress.org checksums', 'icon' => 'yes-alt'],
            'complete' => ['label' => 'Finalizing Scan', 'description' => 'Compiling results and calculating security score', 'icon' => 'yes'],
        ];

        if (isset($stage_info[$stage])) {
            wp_send_json_success($stage_info[$stage]);
        } else {
            wp_send_json_error(['message' => 'Unknown stage']);
        }
    }

    public function whois_lookup() {
        $this->check_access();
        $ip = sanitize_text_field($_GET['ip'] ?? '');
        if (empty($ip)) {
            wp_send_json_error(['message' => 'IP is required']);
        }

        // Fetch basic GeoIP details
        $response = wp_remote_get("http://ip-api.com/json/{$ip}?fields=status,message,country,countryCode,regionName,city,zip,lat,lon,timezone,isp,org,as,query", ['timeout' => 5]);
        $geo = [];
        if (!is_wp_error($response)) {
            $geo = json_decode(wp_remote_retrieve_body($response), true);
        }

        // Fetch raw Whois details from socket connections with fallback
        $raw_whois = $this->query_whois_server($ip);

        wp_send_json_success([
            'geo' => $geo,
            'raw' => $raw_whois
        ]);
    }

    private function query_whois_server($ip) {
        $server = "whois.iana.org";
        $port = 43;
        $timeout = 3;

        $fp = @fsockopen($server, $port, $errno, $errstr, $timeout);
        if (!$fp) {
            // Fallback: request text details from RIPEstat public web registry api
            $url = "https://stat.ripe.net/data/whois/data.json?resource=" . urlencode($ip);
            $resp = wp_remote_get($url, ['timeout' => 4]);
            if (is_wp_error($resp)) {
                return "Whois query failed: Could not connect to Whois registries.";
            }
            $data = json_decode(wp_remote_retrieve_body($resp), true);
            $records = $data['data']['records'] ?? [];
            $output = "";
            foreach ($records as $rec) {
                foreach ($rec as $line) {
                    $output .= $line['key'] . ": " . $line['value'] . "\n";
                }
                $output .= "\n" . str_repeat("-", 40) . "\n\n";
            }
            return $output ?: "No whois record found.";
        }

        fputs($fp, $ip . "\r\n");
        $out = "";
        while (!feof($fp)) {
            $out .= fgets($fp, 128);
        }
        fclose($fp);

        if (preg_match('/refer:\s+([^\s]+)/i', $out, $matches)) {
            $refer_server = trim($matches[1]);
            $fp2 = @fsockopen($refer_server, $port, $errno, $errstr, $timeout);
            if ($fp2) {
                fputs($fp2, $ip . "\r\n");
                $out2 = "";
                while (!feof($fp2)) {
                    $out2 .= fgets($fp2, 128);
                }
                fclose($fp2);
                return $out2;
            }
        }

        return $out;
    }

    public static function is_protected_system_file($file) {
        if (empty($file) || !is_string($file)) {
            return true;
        }
        $rel = ltrim(str_replace('\\', '/', trim($file)), '/');
        $base = basename($rel);

        $root_core = [
            'wp-config.php', 'wp-config-sample.php', 'index.php', '.htaccess',
            'wp-settings.php', 'wp-load.php', 'wp-login.php', 'wp-blog-header.php',
            'wp-activate.php', 'wp-comments-post.php', 'wp-cron.php', 'wp-links-opml.php',
            'wp-mail.php', 'wp-signup.php', 'wp-trackback.php', 'xmlrpc.php',
            'license.txt', 'readme.html'
        ];

        if (strpos($rel, '/') === false && in_array(strtolower($base), array_map('strtolower', $root_core), true)) {
            return true;
        }

        if (strpos($rel, 'wp-admin/') === 0 || strpos($rel, 'wp-includes/') === 0) {
            return true;
        }

        if (in_array($rel, [
            'wp-content/index.php',
            'wp-content/plugins/index.php',
            'wp-content/themes/index.php',
            'wp-content/uploads/index.php'
        ], true)) {
            return true;
        }

        if (strpos($rel, 'wp-content/plugins/mdefender-pro/') === 0 || strpos($rel, 'wp-content/plugins/wp-waf-firewall1/') === 0) {
            return true;
        }

        return false;
    }

    public function delete_scan_file() {
        $this->check_access();
        $this->verify_nonce();
        $data = $this->get_json_input();
        $file = sanitize_text_field($data['file'] ?? '');
        if (empty($file)) wp_send_json_error(['message' => 'File path is required']);

        $rel = ltrim(str_replace('\\', '/', $file), '/');
        if (self::is_protected_system_file($rel)) {
            wp_send_json_error(['message' => 'Protection Alert: ' . esc_html($rel) . ' is a critical WordPress core file and cannot be deleted. Use "Restore Core File" to repair it safely.']);
            return;
        }

        $path = wp_normalize_path(ABSPATH . $rel);
        if (strpos($path, wp_normalize_path(ABSPATH)) === false || strpos($path, '..') !== false) {
            wp_send_json_error(['message' => 'Invalid file path']);
        }

        if (!file_exists($path)) {
            wp_send_json_error(['message' => 'File does not exist']);
        }

        $this->perform_file_backup($rel);

        if (@unlink($path)) {
            wp_send_json_success(['message' => 'File deleted and backed up successfully']);
        } else {
            wp_send_json_error(['message' => 'Failed to delete file. Check permissions.']);
        }
    }

    public function restore_core_file() {
        $this->check_access();
        $this->verify_nonce();
        $data = $this->get_json_input();
        $file = sanitize_text_field($data['file'] ?? '');
        if (empty($file)) wp_send_json_error(['message' => 'File path is required']);

        $rel = ltrim(str_replace('\\', '/', $file), '/');
        if (basename($rel) === 'wp-config.php') {
            wp_send_json_error(['message' => 'wp-config.php contains your local database configuration and cannot be replaced from WordPress.org repository.']);
            return;
        }

        $path = wp_normalize_path(ABSPATH . $rel);
        if (strpos($path, wp_normalize_path(ABSPATH)) === false || strpos($path, '..') !== false) {
            wp_send_json_error(['message' => 'Invalid file path']);
        }

        global $wp_version;
        $url = "https://core.svn.wordpress.org/tags/" . $wp_version . "/" . $rel;
        $response = wp_remote_get($url, ['timeout' => 15]);
        $content = '';
        if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200) {
            $content = wp_remote_retrieve_body($response);
        } else {
            $fallback_url = "https://raw.githubusercontent.com/WordPress/WordPress/" . $wp_version . "/" . $rel;
            $fb_res = wp_remote_get($fallback_url, ['timeout' => 15]);
            if (!is_wp_error($fb_res) && wp_remote_retrieve_response_code($fb_res) === 200) {
                $content = wp_remote_retrieve_body($fb_res);
            }
        }

        if (empty($content)) {
            wp_send_json_error(['message' => 'Could not download official core file from WordPress.org.']);
        }

        // Back up before overwriting for safety
        $this->perform_file_backup($rel);

        if (@file_put_contents($path, $content) !== false) {
            wp_send_json_success(['message' => 'Official core file (' . esc_html($rel) . ') restored successfully from WordPress.org.']);
        } else {
            wp_send_json_error(['message' => 'Failed to overwrite core file. Check permissions.']);
        }
    }

    public function diff_core_file() {
        $this->check_access();
        $file = sanitize_text_field($_GET['file'] ?? ($_POST['file'] ?? ''));
        if (empty($file)) wp_send_json_error(['message' => 'File path is required']);

        $rel = ltrim(str_replace('\\', '/', $file), '/');
        $path = wp_normalize_path(ABSPATH . $rel);
        if (strpos($path, wp_normalize_path(ABSPATH)) === false || strpos($path, '..') !== false) {
            wp_send_json_error(['message' => 'Invalid file path']);
        }

        if (!file_exists($path)) {
            wp_send_json_error(['message' => 'Local file does not exist on disk']);
        }

        $local_content = @file_get_contents($path);
        if ($local_content === false) {
            wp_send_json_error(['message' => 'Unable to read local file contents']);
        }

        global $wp_version;
        $url = "https://core.svn.wordpress.org/tags/" . $wp_version . "/" . $rel;
        $response = wp_remote_get($url, ['timeout' => 15]);
        $original_content = '';
        if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200) {
            $original_content = wp_remote_retrieve_body($response);
        } else {
            $fallback_url = "https://raw.githubusercontent.com/WordPress/WordPress/" . $wp_version . "/" . $rel;
            $fb_res = wp_remote_get($fallback_url, ['timeout' => 15]);
            if (!is_wp_error($fb_res) && wp_remote_retrieve_response_code($fb_res) === 200) {
                $original_content = wp_remote_retrieve_body($fb_res);
            }
        }

        if (empty($original_content)) {
            wp_send_json_error(['message' => 'Could not fetch original WordPress core file from WordPress.org repository.']);
        }

        wp_send_json_success([
            'file' => $rel,
            'wp_version' => $wp_version,
            'original_content' => $original_content,
            'local_content' => $local_content,
            'original_size' => strlen($original_content),
            'local_size' => strlen($local_content),
            'original_hash' => md5($original_content),
            'local_hash' => md5($local_content),
        ]);
    }

    public function bulk_restore_core_files() {
        $this->check_access();
        $this->verify_nonce();
        $input = $this->get_json_input();
        $files = $input['files'] ?? [];

        if (empty($files) || !is_array($files)) {
            global $wpdb;
            $table_queue = $wpdb->prefix . WAF_FW_TABLE_SCAN_QUEUE;
            $last_scan = $wpdb->get_row("SELECT results FROM $table_queue WHERE status IN ('completed', 'completed_with_issues') ORDER BY id DESC LIMIT 1");
            if ($last_scan && !empty($last_scan->results)) {
                $results = json_decode($last_scan->results, true);
                if (!empty($results['malware_scan']['wp_checksums']['modified_files'])) {
                    foreach ($results['malware_scan']['wp_checksums']['modified_files'] as $mf) {
                        $files[] = $mf['file'];
                    }
                }
                if (!empty($results['malware_scan']['suspicious_files'])) {
                    foreach ($results['malware_scan']['suspicious_files'] as $sf) {
                        $rel = ltrim(str_replace('\\', '/', $sf['file']), '/');
                        if (self::is_protected_system_file($rel) && basename($rel) !== 'wp-config.php' && !in_array($sf['file'], $files, true)) {
                            $files[] = $sf['file'];
                        }
                    }
                }
            }
        }

        if (empty($files)) {
            wp_send_json_error(['message' => 'No repairable core files found to restore.']);
        }

        global $wp_version;
        $restored = [];
        $errors = [];

        foreach ($files as $file) {
            $file = sanitize_text_field($file);
            $rel = ltrim(str_replace('\\', '/', $file), '/');
            if (basename($rel) === 'wp-config.php') {
                continue;
            }

            $path = wp_normalize_path(ABSPATH . $rel);
            if (strpos($path, wp_normalize_path(ABSPATH)) === false || strpos($path, '..') !== false) {
                continue;
            }

            $url = "https://core.svn.wordpress.org/tags/" . $wp_version . "/" . $rel;
            $res = wp_remote_get($url, ['timeout' => 10]);
            $body = '';
            if (!is_wp_error($res) && wp_remote_retrieve_response_code($res) === 200) {
                $body = wp_remote_retrieve_body($res);
            }
            if (empty($body)) {
                $fallback_url = "https://raw.githubusercontent.com/WordPress/WordPress/" . $wp_version . "/" . $rel;
                $fb_res = wp_remote_get($fallback_url, ['timeout' => 10]);
                if (!is_wp_error($fb_res) && wp_remote_retrieve_response_code($fb_res) === 200) {
                    $body = wp_remote_retrieve_body($fb_res);
                }
            }

            if (!empty($body)) {
                $this->perform_file_backup($rel);
                if (@file_put_contents($path, $body) !== false) {
                    $restored[] = $rel;
                } else {
                    $errors[] = "Failed to write $rel";
                }
            } else {
                $errors[] = "Could not fetch official $rel";
            }
        }

        if (empty($restored) && !empty($errors)) {
            wp_send_json_error(['message' => 'Failed to restore core files: ' . implode(', ', $errors)]);
            return;
        }

        wp_send_json_success([
            'message' => count($restored) . ' core file(s) restored successfully from official WordPress.org release.',
            'restored' => $restored,
            'errors' => $errors
        ]);
    }

    public function bulk_clean_malware() {
        $this->check_access();
        $this->verify_nonce();
        $input = $this->get_json_input();
        $files = $input['files'] ?? [];

        if (empty($files) || !is_array($files)) {
            global $wpdb;
            $table_queue = $wpdb->prefix . WAF_FW_TABLE_SCAN_QUEUE;
            $last_scan = $wpdb->get_row("SELECT results FROM $table_queue WHERE status IN ('completed', 'completed_with_issues') ORDER BY id DESC LIMIT 1");
            if ($last_scan && !empty($last_scan->results)) {
                $results = json_decode($last_scan->results, true);
                if (!empty($results['malware_scan']['suspicious_files'])) {
                    foreach ($results['malware_scan']['suspicious_files'] as $sf) {
                        $files[] = $sf['file'];
                    }
                }
                if (!empty($results['ml_malware_scan']['malicious_files'])) {
                    foreach ($results['ml_malware_scan']['malicious_files'] as $mf) {
                        $files[] = $mf['file'];
                    }
                }
            }
        }

        if (empty($files)) {
            wp_send_json_error(['message' => 'No deletable malware files found to clean.']);
        }

        $cleaned = [];
        $skipped_core = [];
        $errors = [];

        foreach ($files as $file) {
            $file = sanitize_text_field($file);
            $rel = ltrim(str_replace('\\', '/', $file), '/');
            $path = wp_normalize_path(ABSPATH . $rel);

            if (strpos($path, wp_normalize_path(ABSPATH)) === false || strpos($path, '..') !== false) {
                continue;
            }
            if (!file_exists($path)) {
                continue;
            }

            if (self::is_protected_system_file($rel)) {
                $skipped_core[] = $rel;
                continue;
            }

            if ($this->perform_file_backup($rel)) {
                if (@unlink($path)) {
                    $cleaned[] = $rel;
                } else {
                    $errors[] = "Failed to delete $rel";
                }
            } else {
                $errors[] = "Failed to backup $rel";
            }
        }

        if (empty($cleaned) && !empty($skipped_core)) {
            wp_send_json_success([
                'message' => 'Protected core file(s) (' . implode(', ', array_slice($skipped_core, 0, 3)) . (count($skipped_core) > 3 ? ' and ' . (count($skipped_core) - 3) . ' more' : '') . ') were protected from deletion. Use "Repair All Repairable Files" to restore them safely.',
                'cleaned' => [],
                'skipped_core' => $skipped_core,
                'errors' => $errors
            ]);
            return;
        }

        if (empty($cleaned) && empty($skipped_core)) {
            wp_send_json_error(['message' => 'No deletable malware files found.']);
            return;
        }

        $msg = count($cleaned) . ' standalone malware file(s) safely quarantined and removed.';
        if (!empty($skipped_core)) {
            $msg .= ' (' . count($skipped_core) . ' core file(s) preserved for safety).';
        }

        wp_send_json_success([
            'message' => $msg,
            'cleaned' => $cleaned,
            'skipped_core' => $skipped_core,
            'errors' => $errors
        ]);
    }

    public function view_scan_file() {
        $this->check_access();
        $file = sanitize_text_field($_GET['file'] ?? ($_POST['file'] ?? ''));
        if (empty($file)) wp_send_json_error(['message' => 'File path is required']);

        $rel = ltrim(str_replace('\\', '/', $file), '/');
        $path = wp_normalize_path(ABSPATH . $rel);
        if (strpos($path, wp_normalize_path(ABSPATH)) === false || strpos($rel, '..') !== false) {
            wp_send_json_error(['message' => 'Security: Invalid file path']);
        }

        if (!file_exists($path) || !is_file($path)) {
            wp_send_json_error(['message' => 'File not found']);
        }

        if (filesize($path) > 10000000) {
            wp_send_json_error(['message' => 'File is too large to preview (>10MB)']);
        }

        $content = @file_get_contents($path);
        if ($content === false) {
            wp_send_json_error(['message' => 'Could not read file contents']);
        }

        $lines = substr_count($content, "\n") + 1;
        $size_fmt = size_format(filesize($path), 2);

        wp_send_json_success([
            'file' => $rel,
            'code' => $content,
            'content' => $content,
            'lines' => $lines,
            'size' => $size_fmt
        ]);
    }

    public function ignore_scan_issue() {
        $this->check_access();
        $this->verify_nonce();
        $data = $this->get_json_input();
        $file = sanitize_text_field($data['file'] ?? '');
        if (empty($file)) wp_send_json_error(['message' => 'Issue path is required']);

        $ignored = get_option('waf_fw_ignored_issues', []);
        if (!in_array($file, $ignored)) {
            $ignored[] = $file;
            update_option('waf_fw_ignored_issues', $ignored);
        }
        wp_send_json_success(['message' => 'Issue ignored successfully']);
    }

    public function get_admin_attacks() {
        $this->check_access();
        global $wpdb;
        $table_attacks = $wpdb->prefix . WAF_FW_TABLE_ATTACKS;

        $results = [];
        if ($wpdb->get_var("SHOW TABLES LIKE '$table_attacks'") === $table_attacks) {
            $logs = $wpdb->get_results("SELECT ip, url, method, attack_type, status, rule_matched, user_agent, created_at FROM $table_attacks WHERE url LIKE '%wp-admin%' OR url LIKE '%wp-login.php%' OR attack_type LIKE '%Login%' ORDER BY id DESC LIMIT 50");
            foreach ($logs as $l) {
                $results[] = [
                    'ip' => $l->ip,
                    'url' => $l->url,
                    'method' => $l->method,
                    'attack_type' => $l->attack_type ?: 'Admin Access Attempt',
                    'status' => $l->status,
                    'rule' => $l->rule_matched ?: 'N/A',
                    'user_agent' => $l->user_agent,
                    'time' => $l->created_at
                ];
            }
        }
        wp_send_json_success($results);
    }

    public function get_security_events() {
        $this->check_access();
        global $wpdb;
        $table = WAF_FW_DB::instance()->get_security_events_table();
        $events = $wpdb->get_results("SELECT * FROM $table ORDER BY id DESC LIMIT 50", ARRAY_A);
        wp_send_json_success($events ?: []);
    }

    public function get_real_metrics() {
        $this->check_access();
        $scanner = WAF_FW_Scanner::instance();
        $metrics = $scanner->gather_real_scan_metrics();
        wp_send_json_success($metrics);
    }

    public function get_diagnostics() {
        $this->check_access();
        global $wpdb;

        if (!function_exists('get_plugins')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        // Fetch update transients
        $update_plugins = get_site_transient('update_plugins');
        $update_themes = get_site_transient('update_themes');
        $update_core = get_site_transient('update_core');

        $all_plugins = get_plugins();
        $active_plugins_option = get_option('active_plugins', []);
        $plugin_list = [];
        $outdated_plugins_count = 0;

        foreach ($all_plugins as $plugin_file => $data) {
            $is_active = in_array($plugin_file, $active_plugins_option);
            $has_update = false;
            $new_version = '';
            $package_url = '';

            if ($update_plugins && isset($update_plugins->response[$plugin_file])) {
                $has_update = true;
                $new_version = $update_plugins->response[$plugin_file]->new_version ?? '';
                $package_url = $update_plugins->response[$plugin_file]->package ?? '';
                $outdated_plugins_count++;
            }

            $plugin_list[] = [
                'name' => $data['Name'],
                'version' => $data['Version'],
                'author' => strip_tags($data['Author']),
                'status' => $is_active ? 'Active' : 'Inactive',
                'file' => $plugin_file,
                'update_available' => $has_update,
                'new_version' => $new_version,
                'package' => !empty($package_url),
                'risk_level' => $has_update ? 'Outdated (Vulnerability Risk)' : 'Up to date',
            ];
        }

        // Themes Audit
        $all_themes = wp_get_themes();
        $active_theme = wp_get_theme();
        $theme_list = [];
        $outdated_themes_count = 0;

        foreach ($all_themes as $theme_slug => $tObj) {
            $is_active = ($active_theme->get_stylesheet() === $theme_slug);
            $has_update = false;
            $new_ver = '';

            if ($update_themes && isset($update_themes->response[$theme_slug])) {
                $has_update = true;
                $new_ver = $update_themes->response[$theme_slug]['new_version'] ?? '';
                $outdated_themes_count++;
            }

            $theme_list[] = [
                'slug' => $theme_slug,
                'name' => $tObj->get('Name'),
                'version' => $tObj->get('Version'),
                'author' => strip_tags($tObj->get('Author')),
                'is_active' => $is_active,
                'update_available' => $has_update,
                'new_version' => $new_ver,
            ];
        }

        // Core Update Status
        $core_has_update = false;
        $core_new_version = '';
        if ($update_core && !empty($update_core->updates)) {
            foreach ($update_core->updates as $cu) {
                if (isset($cu->response) && $cu->response === 'upgrade') {
                    $core_has_update = true;
                    $core_new_version = $cu->version ?? '';
                    break;
                }
            }
        }

        $paths_to_check = [
            'ABSPATH' => ABSPATH,
            'wp-content' => WP_CONTENT_DIR,
            'plugins' => WP_PLUGIN_DIR,
            'uploads' => wp_upload_dir()['basedir'],
            'wp-config.php' => ABSPATH . 'wp-config.php',
            '.htaccess' => ABSPATH . '.htaccess',
        ];

        $perms = [];
        foreach ($paths_to_check as $label => $path) {
            if (file_exists($path)) {
                $perms[$label] = [
                    'perms' => substr(sprintf('%o', fileperms($path)), -4),
                    'writable' => is_writable($path),
                    'readable' => is_readable($path)
                ];
            } else {
                $perms[$label] = ['perms' => 'N/A', 'writable' => false, 'readable' => false];
            }
        }

        $diagnostics = [
            'php_version' => PHP_VERSION,
            'sapi' => php_sapi_name(),
            'wp_version' => get_bloginfo('version'),
            'core_update_available' => $core_has_update,
            'core_new_version' => $core_new_version,
            'mysql_version' => $wpdb->db_version(),
            'memory_limit' => ini_get('memory_limit'),
            'max_execution_time' => ini_get('max_execution_time'),
            'upload_max_filesize' => ini_get('upload_max_filesize'),
            'curl_enabled' => function_exists('curl_version'),
            'openssl_enabled' => extension_loaded('openssl'),
            'file_editor_disabled' => defined('DISALLOW_FILE_EDIT') && DISALLOW_FILE_EDIT,
            'waf_protection_enabled' => get_option('waf_fw_protection_enabled', 'yes') === 'yes',
            'plugins' => $plugin_list,
            'outdated_plugins_count' => $outdated_plugins_count,
            'themes' => $theme_list,
            'outdated_themes_count' => $outdated_themes_count,
            'total_outdated_count' => $outdated_plugins_count + $outdated_themes_count + ($core_has_update ? 1 : 0),
            'theme' => [
                'name' => $active_theme->get('Name'),
                'version' => $active_theme->get('Version'),
                'author' => strip_tags($active_theme->get('Author')),
            ],
            'permissions' => $perms,
            'tables_status' => [
                'requests' => $wpdb->get_var("SHOW TABLES LIKE '{$wpdb->prefix}" . WAF_FW_TABLE_REQUESTS . "'") ? 'ok' : 'missing',
                'attacks' => $wpdb->get_var("SHOW TABLES LIKE '{$wpdb->prefix}" . WAF_FW_TABLE_ATTACKS . "'") ? 'ok' : 'missing',
                'blacklist' => $wpdb->get_var("SHOW TABLES LIKE '{$wpdb->prefix}" . WAF_FW_TABLE_BLACKLIST . "'") ? 'ok' : 'missing',
                'scan_queue' => $wpdb->get_var("SHOW TABLES LIKE '{$wpdb->prefix}" . WAF_FW_TABLE_SCAN_QUEUE . "'") ? 'ok' : 'missing',
            ]
        ];

        wp_send_json_success($diagnostics);
    }

    public function diagnostics_check_updates() {
        $this->check_access();
        $this->verify_nonce();

        if (!function_exists('wp_update_plugins')) {
            require_once ABSPATH . 'wp-includes/update.php';
        }
        wp_version_check();
        wp_update_plugins();
        wp_update_themes();

        $this->get_diagnostics();
    }

    public function diagnostics_update_component() {
        $this->check_access();
        $this->verify_nonce();

        $type = sanitize_text_field($_POST['type'] ?? 'plugin');
        $slug = sanitize_text_field($_POST['slug'] ?? '');

        if (empty($slug)) {
            wp_send_json_error(['message' => 'No component file/slug provided.']);
        }

        require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/misc.php';

        if ($type === 'plugin') {
            require_once ABSPATH . 'wp-admin/includes/plugin-install.php';
            $skin = new WP_Ajax_Upgrader_Skin();
            $upgrader = new Plugin_Upgrader($skin);
            $result = $upgrader->upgrade($slug);

            if (is_wp_error($result)) {
                wp_send_json_error(['message' => $result->get_error_message()]);
            } elseif ($result === false) {
                wp_send_json_error(['message' => 'Plugin upgrade failed. Check file permissions or connection.']);
            } else {
                if (class_exists('WAF_FW_Website_Hardening')) {
                    WAF_FW_Website_Hardening::instance()->log_activity('Component Updated', $slug, 'Success', 'Updated outdated plugin to latest version from Diagnostics.');
                }
                wp_send_json_success(['message' => 'Plugin updated successfully!', 'slug' => $slug]);
            }
        } elseif ($type === 'theme') {
            require_once ABSPATH . 'wp-admin/includes/theme-install.php';
            $skin = new WP_Ajax_Upgrader_Skin();
            $upgrader = new Theme_Upgrader($skin);
            $result = $upgrader->upgrade($slug);

            if (is_wp_error($result)) {
                wp_send_json_error(['message' => $result->get_error_message()]);
            } elseif ($result === false) {
                wp_send_json_error(['message' => 'Theme upgrade failed. Check file permissions or connection.']);
            } else {
                if (class_exists('WAF_FW_Website_Hardening')) {
                    WAF_FW_Website_Hardening::instance()->log_activity('Component Updated', $slug, 'Success', 'Updated outdated theme to latest version from Diagnostics.');
                }
                wp_send_json_success(['message' => 'Theme updated successfully!', 'slug' => $slug]);
            }
        } else {
            wp_send_json_error(['message' => 'Invalid component type.']);
        }
    }

    public function get_backups() {
        $this->check_access();
        $backups = get_option('waf_fw_backups', []);
        $formatted = [];
        foreach ($backups as $orig => $info) {
            $formatted[] = [
                'original_path' => $orig,
                'backup_id' => $info['backup_id'],
                'time' => $info['time'],
                'size' => size_format($info['size']),
            ];
        }
        wp_send_json_success($formatted);
    }

    public function clean_file() {
        $this->check_access();
        $this->verify_nonce();
        $data = $this->get_json_input();
        $file = sanitize_text_field($data['file'] ?? '');
        $scan_id = intval($data['scan_id'] ?? 0);
        if (empty($file)) wp_send_json_error(['message' => 'File path is required']);

        $rel = ltrim(str_replace('\\', '/', $file), '/');
        if (self::is_protected_system_file($rel)) {
            wp_send_json_error(['message' => 'Protection Alert: ' . esc_html($rel) . ' is a critical WordPress core file and cannot be deleted. Deleting it will break your website. Please use "Restore Core File" to safely repair it.']);
            return;
        }

        $path = wp_normalize_path(ABSPATH . $rel);
        if (strpos($path, wp_normalize_path(ABSPATH)) === false || strpos($path, '..') !== false) {
            wp_send_json_error(['message' => 'Invalid file path']);
        }

        if (!file_exists($path)) {
            wp_send_json_error(['message' => 'File does not exist']);
        }

        $backup_success = $this->perform_file_backup($rel, $scan_id);
        if (!$backup_success) {
            wp_send_json_error(['message' => 'Failed to create backup. Clean aborted for safety.']);
        }

        if (@unlink($path)) {
            wp_send_json_success(['message' => 'File backed up and cleaned successfully.']);
        } else {
            wp_send_json_error(['message' => 'File backed up, but failed to delete original file. Check permissions.']);
        }
    }

    public function restore_file() {
        $this->check_access();
        $this->verify_nonce();
        $data = $this->get_json_input();
        $file = sanitize_text_field($data['file'] ?? '');
        if (empty($file)) wp_send_json_error(['message' => 'File path is required']);

        $backups = get_option('waf_fw_backups', []);
        if (!isset($backups[$file])) {
            wp_send_json_error(['message' => 'No backup found for this file.']);
        }

        $info = $backups[$file];
        $backup_path = wp_normalize_path(WP_CONTENT_DIR . '/mdefender-backups/' . $info['backup_id']);
        if (!file_exists($backup_path)) {
            wp_send_json_error(['message' => 'Backup file not found on server.']);
        }

        $abs_path = wp_normalize_path(ABSPATH . $file);
        $parent = dirname($abs_path);
        if (!is_dir($parent)) {
            wp_mkdir_p($parent);
        }

        if (@copy($backup_path, $abs_path)) {
            @unlink($backup_path);
            unset($backups[$file]);
            update_option('waf_fw_backups', $backups);
            
            // Delete from database backups table
            global $wpdb;
            $table = WAF_FW_DB::instance()->get_cleaned_backups_table();
            $wpdb->delete($table, ['original_path' => $file]);
            
            wp_send_json_success(['message' => 'File restored successfully.']);
        } else {
            wp_send_json_error(['message' => 'Failed to restore file. Check write permissions.']);
        }
    }

    public function delete_backup() {
        $this->check_access();
        $this->verify_nonce();
        $data = $this->get_json_input();
        $file = sanitize_text_field($data['file'] ?? '');
        if (empty($file)) wp_send_json_error(['message' => 'File path is required']);

        $backups = get_option('waf_fw_backups', []);
        if (isset($backups[$file])) {
            $info = $backups[$file];
            $backup_path = wp_normalize_path(WP_CONTENT_DIR . '/mdefender-backups/' . $info['backup_id']);
            if (file_exists($backup_path)) {
                @unlink($backup_path);
            }
            unset($backups[$file]);
            update_option('waf_fw_backups', $backups);
        }
        
        // Delete from database backups table
        global $wpdb;
        $table = WAF_FW_DB::instance()->get_cleaned_backups_table();
        $wpdb->delete($table, ['original_path' => $file]);
        
        wp_send_json_success(['message' => 'Backup deleted permanently.']);
    }

    private function perform_file_backup($file, $scan_id = 0) {
        $abs_path = wp_normalize_path(ABSPATH . $file);
        if (!file_exists($abs_path)) return false;

        $backup_dir = wp_normalize_path(WP_CONTENT_DIR . '/mdefender-backups');
        if (!is_dir($backup_dir)) {
            wp_mkdir_p($backup_dir);
            @file_put_contents($backup_dir . '/index.php', '<?php // Silence');
            @file_put_contents($backup_dir . '/.htaccess', "Order Deny,Allow\nDeny from all");
        }

        $backup_id = uniqid('mdf_') . '_' . basename($file) . '.bak';
        $backup_path = $backup_dir . '/' . $backup_id;
        $file_hash = hash_file('sha256', $abs_path);

        if (@copy($abs_path, $backup_path)) {
            $backups = get_option('waf_fw_backups', []);
            $backups[$file] = [
                'backup_id' => $backup_id,
                'time' => current_time('mysql'),
                'original_path' => $file,
                'size' => filesize($abs_path),
            ];
            update_option('waf_fw_backups', $backups);

            // Log details into database backups table
            global $wpdb;
            $table = WAF_FW_DB::instance()->get_cleaned_backups_table();
            $wpdb->insert($table, [
                'scan_id' => $scan_id,
                'original_path' => $file,
                'backup_path' => $backup_path,
                'file_hash' => $file_hash,
                'cleaned_at' => current_time('mysql')
            ]);

            return true;
        }
        return false;
    }

    public function create_backup_ajax() {
        $this->check_access();
        $this->verify_nonce();
        
        $type = sanitize_text_field($_POST['type'] ?? 'full');
        $note = sanitize_text_field($_POST['note'] ?? '');
        $components = [];

        if (isset($_POST['components']) && is_array($_POST['components'])) {
            $components = array_map('sanitize_text_field', $_POST['components']);
        }

        $engine = WAF_FW_Backup_Engine::instance();
        $result = $engine->create_backup($type, $components, $note);

        if ($result['success']) {
            wp_send_json_success($result);
        } else {
            wp_send_json_error($result);
        }
    }

    public function restore_backup_ajax() {
        $this->check_access();
        $this->verify_nonce();

        $filename = sanitize_file_name($_POST['filename'] ?? '');
        if (empty($filename)) {
            wp_send_json_error(['message' => 'Invalid backup archive filename.']);
        }

        $engine = WAF_FW_Backup_Engine::instance();
        $result = $engine->restore_backup($filename);

        if ($result['success']) {
            wp_send_json_success($result);
        } else {
            wp_send_json_error($result);
        }
    }

    public function delete_site_backup_ajax() {
        $this->check_access();
        $this->verify_nonce();

        $filename = sanitize_file_name($_POST['filename'] ?? '');
        if (empty($filename)) {
            wp_send_json_error(['message' => 'Filename is required.']);
        }

        $engine = WAF_FW_Backup_Engine::instance();
        $result = $engine->delete_backup($filename);
        wp_send_json_success($result);
    }

    public function get_backups_ajax() {
        $this->check_access();
        $engine = WAF_FW_Backup_Engine::instance();
        $backups = $engine->get_backups();
        wp_send_json_success(['backups' => $backups]);
    }

    public function save_backup_schedule_ajax() {
        $this->check_access();
        $this->verify_nonce();

        $engine = WAF_FW_Backup_Engine::instance();
        $result = $engine->save_schedule_settings($_POST);
        wp_send_json_success($result);
    }

    public function upload_backup_ajax() {
        $this->check_access();
        $this->verify_nonce();

        if (empty($_FILES['backup_file']) || empty($_FILES['backup_file']['name'])) {
            wp_send_json_error(['message' => 'No backup file was uploaded.']);
        }

        $file = $_FILES['backup_file'];
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

        if (!in_array($ext, ['zip', 'sql', 'gz'])) {
            wp_send_json_error(['message' => 'Only .zip or .sql backup files are supported.']);
        }

        $engine = WAF_FW_Backup_Engine::instance();
        $dest_name = sanitize_file_name($file['name']);
        $dest_path = $engine->get_backup_dir() . $dest_name;

        if (move_uploaded_file($file['tmp_name'], $dest_path)) {
            $engine->get_backups(); // Refresh catalog
            wp_send_json_success(['message' => 'Backup archive uploaded successfully: ' . $dest_name]);
        } else {
            wp_send_json_error(['message' => 'Failed to save uploaded backup file. Check permissions.']);
        }
    }

    /* ===== CORE INTEGRITY AJAX HANDLERS ===== */
    public function tools_core_integrity_scan() {
        $this->check_access();
        $this->verify_nonce();

        $engine = WAF_FW_Core_Integrity::instance();
        $result = $engine->scan_core_integrity();

        if (empty($result['success'])) {
            wp_send_json_error($result);
        }
        wp_send_json_success($result);
    }

    public function tools_core_integrity_restore() {
        $this->check_access();
        $this->verify_nonce();

        $file_path = sanitize_text_field($_POST['file_path'] ?? '');
        if (empty($file_path)) {
            wp_send_json_error(['message' => 'No file path provided.']);
        }

        $engine = WAF_FW_Core_Integrity::instance();
        $result = $engine->restore_core_file($file_path);

        if (empty($result['success'])) {
            wp_send_json_error($result);
        }
        wp_send_json_success($result);
    }

    public function tools_core_integrity_delete_unknown() {
        $this->check_access();
        $this->verify_nonce();

        $file_path = sanitize_text_field($_POST['file_path'] ?? '');
        if (empty($file_path)) {
            wp_send_json_error(['message' => 'No file path provided.']);
        }

        $engine = WAF_FW_Core_Integrity::instance();
        $result = $engine->delete_rogue_file($file_path);

        if (empty($result['success'])) {
            wp_send_json_error($result);
        }
        wp_send_json_success($result);
    }

    /* ===== POST-HACK EMERGENCY RECOVERY AJAX HANDLERS ===== */
    public function tools_posthack_terminate_sessions() {
        $this->check_access();
        $this->verify_nonce();

        $keep_current = isset($_POST['keep_current']) ? (bool)$_POST['keep_current'] : true;
        $recovery = WAF_FW_PostHack_Recovery::instance();
        $result = $recovery->terminate_all_sessions($keep_current);
        wp_send_json_success($result);
    }

    public function tools_posthack_regenerate_salts() {
        $this->check_access();
        $this->verify_nonce();

        $recovery = WAF_FW_PostHack_Recovery::instance();
        $result = $recovery->regenerate_security_salts();

        if (empty($result['success'])) {
            wp_send_json_error($result);
        }
        wp_send_json_success($result);
    }

    public function tools_posthack_force_password_reset() {
        $this->check_access();
        $this->verify_nonce();

        $scope = sanitize_text_field($_POST['scope'] ?? 'admins');
        $recovery = WAF_FW_PostHack_Recovery::instance();
        $result = $recovery->force_global_password_reset($scope);
        wp_send_json_success($result);
    }

    public function tools_posthack_audit_admins() {
        $this->check_access();

        $recovery = WAF_FW_PostHack_Recovery::instance();
        $result = $recovery->audit_administrator_security();
        wp_send_json_success($result);
    }

    public function tools_posthack_check_pwned() {
        $this->check_access();
        $this->verify_nonce();

        $pwd = sanitize_text_field($_POST['password'] ?? '');
        if (empty($pwd)) {
            wp_send_json_error(['message' => 'Please provide a test password string.']);
        }

        $recovery = WAF_FW_PostHack_Recovery::instance();
        $result = $recovery->check_pwned_password($pwd);
        wp_send_json_success($result);
    }

    public function tools_posthack_toggle_lockdown() {
        $this->check_access();
        $this->verify_nonce();

        $enable = !empty($_POST['enable']) && $_POST['enable'] === 'yes';
        $recovery = WAF_FW_PostHack_Recovery::instance();
        $result = $recovery->toggle_emergency_lockdown($enable);
        wp_send_json_success($result);
    }
}

