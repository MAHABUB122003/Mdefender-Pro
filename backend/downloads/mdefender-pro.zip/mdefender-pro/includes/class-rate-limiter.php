<?php
defined('ABSPATH') || exit;

class WAF_FW_Rate_Limiter {
    private static $_instance = null;
    private $window_seconds = 60;

    public static function instance() {
        if (null === self::$_instance) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    public function get_max_requests() {
        return max(5, (int) get_option('waf_fw_rate_limit', 120));
    }

    public function is_rate_limited($ip) {
        if (empty($ip)) return false;
        $max_requests = $this->get_max_requests();
        $key = 'waf_fw_rate_' . md5($ip);

        // 1. Fast-path in-memory APCu cache (< 0.001ms)
        if (function_exists('apcu_fetch')) {
            $data = apcu_fetch($key);
            if (!$data) {
                return false;
            }
            $now = time();
            $window_start = $now - $this->window_seconds;
            $data = array_values(array_filter($data, function($t) use ($window_start) {
                return $t > $window_start;
            }));
            if (count($data) >= $max_requests) {
                apcu_store($key, $data, $this->window_seconds);
                return true;
            }
            $data[] = $now;
            apcu_store($key, $data, $this->window_seconds);
            return false;
        }

        // 2. Standard WordPress Transient fallback
        $data = get_transient($key);
        if (!$data) {
            return false;
        }
        $data = json_decode($data, true);
        if (!is_array($data)) {
            return false;
        }
        $now = time();
        $window_start = $now - $this->window_seconds;
        $data = array_values(array_filter($data, function($t) use ($window_start) {
            return $t > $window_start;
        }));
        if (count($data) >= $max_requests) {
            set_transient($key, json_encode($data), $this->window_seconds);
            return true;
        }
        $data[] = $now;
        set_transient($key, json_encode($data), $this->window_seconds);
        return false;
    }

    public function increment($ip) {
        if (empty($ip)) return;
        $key = 'waf_fw_rate_' . md5($ip);
        $data = get_transient($key);
        if (!$data) {
            $data = [];
        } else {
            $data = json_decode($data, true);
            if (!is_array($data)) $data = [];
        }
        $now = time();
        $window_start = $now - $this->window_seconds;
        $data = array_values(array_filter($data, function($t) use ($window_start) {
            return $t > $window_start;
        }));
        $data[] = $now;
        set_transient($key, json_encode($data), $this->window_seconds);
    }
}

