<?php
defined('ABSPATH') || exit;
$attack_type  = !empty($result['attack_type']) ? $result['attack_type'] : 'Security Threat';
$client_ip    = !empty($result['ip']) ? $result['ip'] : ($_SERVER['REMOTE_ADDR'] ?? 'Unknown');
$reason       = !empty($result['message']) ? $result['message'] : 'This request has been blocked by Web Application Firewall';
$reference_id = !empty($result['reference_id']) ? $result['reference_id'] : ('MDF-' . strtoupper(substr(md5(uniqid(mt_rand(), true)), 0, 8)));
$timestamp    = !empty($result['timestamp']) ? $result['timestamp'] : current_time('mysql');
$colors       = get_option('waf_fw_block_colors', '#4f46e5,#6366f1');
$message      = get_option('waf_fw_block_message', 'This request has been blocked by Web Application Firewall');
$site_name    = get_bloginfo('name') ?: 'Website Security';

$colors_arr = explode(',', $colors);
$color1 = trim($colors_arr[0] ?? '#4f46e5');
$color2 = trim($colors_arr[1] ?? '#6366f1');
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Access Restricted &mdash; <?php echo esc_html($site_name); ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
    <style>
        :root {
            --brand-1: <?php echo esc_attr($color1); ?>;
            --brand-2: <?php echo esc_attr($color2); ?>;
            --bg-color: #f7f9fc;
            --card-bg: #ffffff;
            --text-primary: #0f172a;
            --text-secondary: #475569;
            --text-muted: #64748b;
            --border-light: #f1f5f9;
            --border-medium: #e2e8f0;
            --font-main: 'Outfit', sans-serif;
            --font-mono: 'JetBrains Mono', monospace;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: var(--font-main);
            background-color: var(--bg-color);
            background-image: 
                radial-gradient(circle at 10% 20%, rgba(99, 102, 241, 0.03) 0%, transparent 40%),
                radial-gradient(circle at 90% 80%, rgba(59, 130, 246, 0.03) 0%, transparent 40%);
            color: var(--text-primary);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 24px 16px;
            position: relative;
        }
        .block-wrapper {
            position: relative;
            z-index: 1;
            width: 100%;
            max-width: 580px;
            animation: cardFadeIn 0.6s cubic-bezier(0.16, 1, 0.3, 1) forwards;
        }
        @keyframes cardFadeIn {
            0% { opacity: 0; transform: translateY(12px); }
            100% { opacity: 1; transform: translateY(0); }
        }
        .block-card {
            background: var(--card-bg);
            border: 1px solid var(--border-medium);
            border-radius: 24px;
            padding: 44px;
            box-shadow: 
                0 1px 3px rgba(0, 0, 0, 0.02),
                0 20px 40px -12px rgba(15, 23, 42, 0.08);
            position: relative;
        }
        .block-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 3px;
            background: linear-gradient(90deg, var(--brand-1), var(--brand-2));
        }
        .logo-wrap {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 60px;
            height: 60px;
            margin: 0 auto 28px;
            background: #fafafa;
            border: 1.5px solid var(--border-medium);
            border-radius: 18px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.02);
        }
        .logo-icon {
            width: 28px;
            height: 28px;
            fill: none;
            stroke: var(--brand-1);
            stroke-width: 2;
        }
        .brand-header {
            text-align: center;
            margin-bottom: 32px;
        }
        .brand-subtitle {
            font-size: 13px;
            font-weight: 700;
            color: var(--brand-1);
            text-transform: uppercase;
            letter-spacing: 1.5px;
            margin-bottom: 8px;
        }
        .block-title {
            font-size: 26px;
            font-weight: 800;
            letter-spacing: -0.5px;
            color: var(--text-primary);
            margin-bottom: 12px;
        }
        .block-subtitle-desc {
            font-size: 14.5px;
            color: var(--text-secondary);
            line-height: 1.6;
            font-weight: 400;
        }
        .details-list {
            background: #fafbfc;
            border: 1.5px solid var(--border-light);
            border-radius: 16px;
            overflow: hidden;
            margin-bottom: 28px;
        }
        .detail-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 24px;
            border-bottom: 1.5px solid var(--border-light);
        }
        .detail-row:last-child {
            border-bottom: none;
        }
        .detail-label {
            font-size: 12px;
            font-weight: 600;
            color: var(--text-muted);
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .detail-val {
            font-size: 13.5px;
            font-weight: 500;
            color: var(--text-primary);
            text-align: right;
            word-break: break-all;
            max-width: 60%;
        }
        .detail-val.threat {
            font-weight: 600;
            color: #b91c1c;
            background: #fef2f2;
            border: 1px solid #fee2e2;
            padding: 2px 8px;
            border-radius: 6px;
            font-size: 12px;
        }
        .detail-val.mono {
            font-family: var(--font-mono);
            font-size: 12.5px;
            color: #334155;
            background: #f8fafc;
            border: 1px solid var(--border-medium);
            padding: 2px 8px;
            border-radius: 6px;
        }
        .friendly-note {
            background: #f8fafc;
            border-left: 3px solid var(--brand-1);
            border-radius: 0 12px 12px 0;
            padding: 16px 20px;
            margin-bottom: 32px;
            font-size: 13.5px;
            color: var(--text-secondary);
            line-height: 1.6;
        }
        .friendly-note strong {
            color: var(--text-primary);
        }
        .actions-wrap {
            display: flex;
            gap: 12px;
            justify-content: center;
            flex-wrap: wrap;
            margin-bottom: 36px;
        }
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 13px 26px;
            border-radius: 10px;
            font-size: 13.5px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s cubic-bezier(0.16, 1, 0.3, 1);
            text-decoration: none;
            border: none;
            gap: 8px;
        }
        .btn-primary {
            background: linear-gradient(135deg, var(--brand-1), var(--brand-2));
            color: #ffffff;
            box-shadow: 0 4px 14px rgba(99, 102, 241, 0.15);
        }
        .btn-primary:hover {
            transform: translateY(-1px);
            box-shadow: 0 6px 20px rgba(99, 102, 241, 0.25);
        }
        .btn-secondary {
            background: #ffffff;
            border: 1px solid var(--border-medium);
            color: #334155;
        }
        .btn-secondary:hover {
            background: #fafbfc;
            color: var(--text-primary);
            border-color: #cbd5e1;
        }
        .block-footer {
            text-align: center;
            padding-top: 20px;
            border-top: 1.5px solid var(--border-light);
            font-size: 12.5px;
            color: var(--text-muted);
        }
        @media (max-width: 640px) {
            .block-card { padding: 32px 20px; }
            .block-title { font-size: 23px; }
            .detail-row { flex-direction: column; align-items: flex-start; gap: 4px; padding: 12px 16px; }
            .detail-val { text-align: left; max-width: 100%; }
            .actions-wrap { flex-direction: column; }
            .btn { width: 100%; }
        }
    </style>
</head>
<body>
    <div class="block-wrapper">
        <div class="block-card">
            <div class="logo-wrap">
                <svg class="logo-icon" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
            </div>
            
            <div class="brand-header">
                <div class="brand-subtitle"><?php echo esc_html($site_name); ?></div>
                <h1 class="block-title">403 — Access Denied</h1>
                <p class="block-subtitle-desc"><?php echo esc_html($message); ?></p>
            </div>

            <div class="details-list">
                <div class="detail-row">
                    <span class="detail-label">Attack Type</span>
                    <span class="detail-val threat"><?php echo esc_html($attack_type); ?></span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Client IP</span>
                    <span class="detail-val"><?php echo esc_html($client_ip); ?></span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Reason</span>
                    <span class="detail-val"><?php echo esc_html($reason); ?></span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Reference ID</span>
                    <span class="detail-val mono" id="refId"><?php echo esc_html($reference_id); ?></span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Timestamp</span>
                    <span class="detail-val"><?php echo esc_html($timestamp); ?></span>
                </div>
            </div>

            <div class="friendly-note">
                <strong>Why did this happen?</strong><br>
                To protect this website from unauthorized activity, some actions are automatically filtered. If you are a normal visitor, don't worry &mdash; simply contact the site administrator and provide the <strong>Reference ID</strong> above to resolve this quickly.
            </div>

            <div class="actions-wrap">
                <a href="<?php echo esc_url(home_url('/')); ?>" class="btn btn-primary">Return to Homepage</a>
                <button class="btn btn-secondary" onclick="copyRef()" id="copy-btn">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-top: 1px;">
                        <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
                        <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
                    </svg>
                    Copy Reference ID
                </button>
            </div>

            <div class="block-footer">
                Secured by <strong>MDefender-Pro AI Firewall</strong> • All unauthorized access attempts are logged.
            </div>
        </div>
    </div>

    <script>
        function copyRef() {
            const refText = "<?php echo esc_js($reference_id); ?>";
            navigator.clipboard.writeText(refText).then(() => {
                const btn = document.getElementById('copy-btn');
                const originalText = btn.innerHTML;
                btn.innerHTML = 'Copied! ✅';
                btn.style.color = '#10b981';
                setTimeout(() => {
                    btn.innerHTML = originalText;
                    btn.style.color = '';
                }, 1500);
            }).catch(err => {
                console.error('Could not copy text: ', err);
            });
        }
    </script>
</body>
</html>
