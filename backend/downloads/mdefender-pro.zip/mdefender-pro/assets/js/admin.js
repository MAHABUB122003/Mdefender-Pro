jQuery(document).ready(function($) {
    $(document).on('click', '.waf-fw-modal-close, .waf-fw-modal', function(e) {
        if ($(e.target).hasClass('waf-fw-modal') || $(e.target).hasClass('waf-fw-modal-close')) {
            $(this).closest('.waf-fw-modal').hide();
        }
    });

    var userDropdown = document.getElementById('warUserDropdown');
    if (userDropdown) {
        userDropdown.addEventListener('click', function() {
            window.location.href = ajaxurl.replace('admin-ajax.php', 'profile.php');
        });
    }
});
