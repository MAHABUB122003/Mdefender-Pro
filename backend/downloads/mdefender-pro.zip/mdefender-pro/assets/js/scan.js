(function($) {
    var scanQueueId = 0;
    var scanCellIndex = 0;
    var scanRunning = false;
    var scanPaused = false;
    var scanRetryTimer = null;
    var scanElapsedTimer = null;
    var scanStartTime = 0;
    var lastScanId = 0;

    $('#wafStartScan').on('click', function() {
        if (scanRunning) return;
        var type = $('#wafScanType').val();
        startProgressiveScan(type);
    });

    $('#wafPauseScan').on('click', function() {
        if (!scanRunning || !scanQueueId) return;
        if (scanPaused) {
            resumeScan();
        } else {
            pauseScan();
        }
    });

    $('#wafCancelScan').on('click', function() {
        if (!scanRunning || !scanQueueId) return;
        if (!confirm('Are you sure you want to cancel this scan?')) return;
        cancelScan();
    });

    $('#wafEmailReport').on('click', function() {
        $('#wafEmailModal').css('display', 'flex');
        $('#wafReportEmail').val('').focus();
    });

    $('#wafEmailCancel').on('click', function() {
        $('#wafEmailModal').hide();
    });

    $('#wafEmailSend').on('click', function() {
        var email = $('#wafReportEmail').val();
        sendEmailReport(lastScanId, email);
    });

    $('#wafRescanBtn').on('click', function() {
        var type = $('#wafScanType').val();
        startProgressiveScan(type);
    });

    $('.waf-scan-tab').on('click', function() {
        $('.waf-scan-tab').removeClass('active');
        $(this).addClass('active');
        filterScanResults($(this).data('tab'));
    });

    function startProgressiveScan(type) {
        scanRunning = true;
        scanPaused = false;
        scanStartTime = Date.now();
        $('#wafStartScan').prop('disabled', true).text('Scanning...');
        $('#wafPauseScan').show().text('Pause').css({background:'#f59e0b',color:'#fff',borderColor:'#f59e0b'});
        $('#wafCancelScan').show();
        $('#wafScanProgress').show();
        $('#wafScanResults').hide();
        $('#wafScanProgressFill').css('width', '2%');
        $('#wafScanStage').text('Starting scan...');
        $('#wafScanProgressPct').text('2%');
        $('#wafScanStageDetail').hide();
        $('#wafScanTimer').show();
        startElapsedTimer();

        $.ajax({
            url: ajaxurl + '?action=waf_fw_start_progressive_scan',
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({ scan_type: type }),
            success: function(r) {
                if (r.success && r.data) {
                    scanQueueId = r.data.queue_id;
                    scanCellIndex = r.data.cell_index || 0;
                    if (r.data.completed) {
                        handleCellDone(r.data);
                    } else {
                        updateProgress(r.data);
                        scheduleContinue();
                    }
                } else {
                    scanError('Failed to start scan');
                }
            },
            error: function() {
                scanError('Scan request failed');
            }
        });
    }

    function pauseScan() {
        $.ajax({
            url: ajaxurl + '?action=waf_fw_pause_scan',
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({ queue_id: scanQueueId }),
            success: function(r) {
                if (r.success) {
                    scanPaused = true;
                    scanRunning = false;
                    if (scanRetryTimer) { clearTimeout(scanRetryTimer); scanRetryTimer = null; }
                    stopElapsedTimer();
                    $('#wafPauseScan').text('Resume').css({background:'#10b981',color:'#fff',borderColor:'#10b981'});
                    $('#wafScanStage').text('Scan paused');
                }
            }
        });
    }

    function resumeScan() {
        scanRunning = true;
        scanPaused = false;
        $('#wafPauseScan').text('Pause').css({background:'#f59e0b',color:'#fff',borderColor:'#f59e0b'});
        $('#wafScanStage').text('Resuming scan...');
        startElapsedTimer();
        scheduleContinue();
    }

    function cancelScan() {
        $.ajax({
            url: ajaxurl + '?action=waf_fw_cancel_scan',
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({ queue_id: scanQueueId }),
            success: function(r) {
                scanRunning = false;
                scanPaused = false;
                if (scanRetryTimer) { clearTimeout(scanRetryTimer); scanRetryTimer = null; }
                stopElapsedTimer();
                $('#wafScanProgress').hide();
                $('#wafStartScan').prop('disabled', false).text('Start Scan');
                $('#wafPauseScan').hide();
                $('#wafCancelScan').hide();
            }
        });
    }

    function scheduleContinue() {
        if (scanRetryTimer) clearTimeout(scanRetryTimer);
        scanRetryTimer = setTimeout(continueScanning, 600);
    }

    function continueScanning() {
        if (!scanQueueId || !scanRunning) return;
        $.ajax({
            url: ajaxurl + '?action=waf_fw_continue_scan',
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({ queue_id: scanQueueId, cell_index: scanCellIndex }),
            success: function(r) {
                if (r.success && r.data) {
                    scanCellIndex = r.data.cell_index || 0;
                    handleCellDone(r.data);
                } else {
                    scanError('Scan continuation failed');
                }
            },
            error: function() {
                if (scanRunning) setTimeout(continueScanning, 2000);
            }
        });
    }

    function handleCellDone(data) {
        if (data.completed) {
            scanComplete(data);
        } else {
            updateProgress(data);
            scheduleContinue();
        }
    }

    function updateProgress(data) {
        var pct = data.progress || 0;
        $('#wafScanProgressFill').css('width', pct + '%');
        $('#wafScanProgressPct').text(pct + '%');
        if (data.current_stage) {
            var stage = data.current_stage.replace(/_/g, ' ');
            stage = stage.charAt(0).toUpperCase() + stage.slice(1);
            $('#wafScanStage').text(stage);
            loadStageDetail(data.current_stage);
        }
        if (data.total_files > 0) {
            $('#wafTotalFileCount').text(data.total_files);
            $('#wafScannedFileCount').text(data.scanned_files || 0);
        }

        // Animate Wordfence Stage Steps
        updateStagePipeline(pct, data.current_stage);
    }

    function updateStagePipeline(pct, stage) {
        var steps = ['prep', 'waf', 'core', 'malware', 'vuln', 'sensitive', 'blacklist'];
        var activeIndex = 0;
        if (pct >= 95) activeIndex = 6;
        else if (pct >= 80) activeIndex = 5;
        else if (pct >= 65) activeIndex = 4;
        else if (pct >= 45) activeIndex = 3;
        else if (pct >= 30) activeIndex = 2;
        else if (pct >= 15) activeIndex = 1;
        else activeIndex = 0;

        for (var i = 0; i < steps.length; i++) {
            var el = $('#step-' + steps[i]);
            if (i < activeIndex) {
                el.removeClass('active').addClass('done');
            } else if (i === activeIndex) {
                el.removeClass('done').addClass('active');
            } else {
                el.removeClass('active done');
            }
        }
    }

    function loadStageDetail(stage) {
        $.get(ajaxurl + '?action=waf_fw_get_scan_stage_detail&stage=' + encodeURIComponent(stage), function(r) {
            if (r.success && r.data) {
                $('#wafStageDetailDesc').text(r.data.label + ': ' + r.data.description);
            }
        });
    }

    function scanComplete(data) {
        scanRunning = false;
        stopElapsedTimer();
        if (scanRetryTimer) { clearTimeout(scanRetryTimer); scanRetryTimer = null; }
        $('#wafScanProgressFill').css('width', '100%');
        $('#wafScanProgressPct').text('100%');
        $('#wafScanStage').text('Scan complete!');
        $('.waf-stage-step').removeClass('active').addClass('done');
        $('#wafStageDetailDesc').text('Compiling results and calculating security score...');

        setTimeout(function() {
            $('#wafScanProgress').hide();
            $('#wafStartScan').prop('disabled', false).text('Start Scan');
            $('#wafPauseScan').hide();
            $('#wafCancelScan').hide();
            if (data.results) {
                displayScanResults(data);
            } else {
                alert('Scan results not available');
            }
        }, 500);
    }

    function scanError(msg) {
        scanRunning = false;
        stopElapsedTimer();
        if (scanRetryTimer) { clearTimeout(scanRetryTimer); scanRetryTimer = null; }
        $('#wafScanProgress').hide();
        $('#wafStartScan').prop('disabled', false).text('Start Scan');
        $('#wafPauseScan').hide();
        $('#wafCancelScan').hide();
        alert(msg);
    }

    function displayScanResults(data) {
        $('#wafScanResults').show();
        var score = data.score || 0;
        var issues = data.issues_found || 0;
        var duration = data.duration || 0;
        var scanData = data.results || data;

        lastScanId = data.queue_id || 0;

        updateScoreCard(score);
        $('#wafScanIssues').text(issues);
        $('#wafScanDuration').text(formatDuration(duration));
        $('#wafScanDate').text(new Date().toLocaleString());

        var checks = countChecks(scanData);
        var filesScanned = (scanData.malware_scan && scanData.malware_scan.total_scanned) || 0;
        if (scanData.ml_malware_scan && scanData.ml_malware_scan.total_scanned) {
            filesScanned += scanData.ml_malware_scan.total_scanned;
        }
        $('#wafScanChecks').text(checks);
        $('#wafScannedFiles').text(filesScanned);

        var modulesRun = Object.keys(scanData).filter(function(k) {
            return typeof scanData[k] === 'object' && scanData[k] !== null && k !== 'security_status';
        }).length;
        $('#wafScanModules').text(modulesRun);

        updateScoreGrade(score);

        if (data.summary && data.summary.security_status) {
            updateStatusBanner(data.summary.security_status);
        } else {
            updateStatusBannerFromScore(score, issues);
        }

        renderScanModules(scanData);
        loadScanHistory();
        window.wafScanData = scanData;
    }

    function updateScoreCard(score) {
        var el = $('#wafScanScore');
        var circle = $('#wafScoreCircle');
        el.text(score);
        circle.removeClass('waf-score-good waf-score-warning waf-score-danger');
        if (score >= 80) { circle.addClass('waf-score-good'); }
        else if (score >= 50) { circle.addClass('waf-score-warning'); }
        else { circle.addClass('waf-score-danger'); }
    }

    function updateScoreGrade(score) {
        var grade, color;
        if (score >= 90) { grade = 'Grade A - Excellent'; color = '#059669'; }
        else if (score >= 80) { grade = 'Grade B - Good'; color = '#10b981'; }
        else if (score >= 70) { grade = 'Grade C - Fair'; color = '#f59e0b'; }
        else if (score >= 50) { grade = 'Grade D - Poor'; color = '#f97316'; }
        else { grade = 'Grade F - Critical'; color = '#ef4444'; }
        $('#wafScanGrade').text(grade).css('color', color);
    }

    function updateStatusBanner(status) {
        var banner = $('#wafScanStatusBanner');
        banner.css({ background: status.bg, 'border-color': status.border, display: 'flex' });
        $('#wafStatusIcon').attr('class', 'dashicons ' + status.icon).css('color', status.color);
        $('#wafStatusLabel').css('color', status.color).text(status.label);
        $('#wafStatusMessage').text(status.message);
    }

    function updateStatusBannerFromScore(score, issues) {
        var banner = $('#wafScanStatusBanner');
        var icon, label, message, color, bg, border;
        if (score >= 80) {
            icon = 'dashicons-shield'; label = 'Secure'; color = '#059669'; bg = '#f0fdf4'; border = '#bbf7d0';
            message = 'Your site passed all security checks with ' + issues + ' minor issue(s).';
        } else if (score >= 50) {
            icon = 'dashicons-warning'; label = 'Attention Required'; color = '#d97706'; bg = '#fef9c3'; border = '#fde68a';
            message = issues + ' security issue(s) detected that should be reviewed.';
        } else {
            icon = 'dashicons-dismiss'; label = 'Critical'; color = '#dc2626'; bg = '#fef2f2'; border = '#fecaca';
            message = issues + ' critical security issue(s) found that require immediate action.';
        }
        banner.css({ background: bg, 'border-color': border, display: 'flex' });
        $('#wafStatusIcon').attr('class', 'dashicons ' + icon).css('color', color);
        $('#wafStatusLabel').css('color', color).text(label);
        $('#wafStatusMessage').text(message);
    }

    function countChecks(data) {
        var count = 0;
        for (var key in data) {
            if (typeof data[key] === 'object' && data[key] !== null) count++;
        }
        return count;
    }

    function formatDuration(seconds) {
        if (seconds < 60) return seconds + 's';
        var m = Math.floor(seconds / 60);
        var s = seconds % 60;
        return m + 'm ' + s + 's';
    }

    function startElapsedTimer() {
        stopElapsedTimer();
        scanElapsedTimer = setInterval(function() {
            var elapsed = Math.floor((Date.now() - scanStartTime) / 1000);
            $('#wafScanElapsed').text(formatDuration(elapsed));
        }, 1000);
    }

    function stopElapsedTimer() {
        if (scanElapsedTimer) { clearInterval(scanElapsedTimer); scanElapsedTimer = null; }
    }

    var moduleLabels = {
        basic_checks: 'Basic Security Checks',
        headers_check: 'Security Headers',
        ssl_check: 'SSL Certificate',
        ssl_deep_analysis: 'SSL/TLS Deep Analysis',
        wordpress_checks: 'WordPress Core Security',
        waf_test: 'WAF Protection Test',
        directory_listing: 'Directory Listing',
        xmlrpc_check: 'XML-RPC Security',
        cors_check: 'CORS Configuration',
        cookie_security: 'Cookie Security',
        file_upload_check: 'File Upload Security',
        php_info_exposure: 'PHP Info Exposure',
        vulnerability_scan: 'Vulnerability Scan',
        malware_scan: 'Malware & Backdoor Scan',
        ml_malware_scan: 'MDefender ML Malware Scan',
        db_scan: 'Database Security',
        db_integrity: 'Database Integrity',
        port_scan: 'Port Scan',
        ml_analysis: 'ML Analysis',
        password_audit: 'Password Strength Audit',
        blocklist_check: 'Domain Blocklist Check',
        fpd_check: 'Full Path Disclosure',
        dns_security: 'DNS Security',
        rss_spam_check: 'RSS Feed Spam',
        deprecated_php: 'Deprecated PHP Detection',
        file_permissions: 'File Permission Audit',
        server_fingerprint: 'Server Fingerprint',
        config_exposure: 'Config File Exposure',
        known_files_check: 'Known File Verification',
        file_changes: 'File Changes',
    };

    var moduleIcons = {
        basic_checks: 'shield', headers_check: 'list-view', ssl_check: 'lock',
        ssl_deep_analysis: 'lock', wordpress_checks: 'wordpress', waf_test: 'shields',
        directory_listing: 'folder', xmlrpc_check: 'networking', cors_check: 'admin-links',
        cookie_security: 'portfolio', file_upload_check: 'upload', php_info_exposure: 'info',
        vulnerability_scan: 'warning', malware_scan: 'analytics', ml_malware_scan: 'rocket', db_scan: 'database',
        db_integrity: 'database', port_scan: 'networking', ml_analysis: 'rocket',
        password_audit: 'admin-users', blocklist_check: 'dismiss', fpd_check: 'visibility',
        dns_security: 'admin-network', rss_spam_check: 'rss', deprecated_php: 'art',
        file_permissions: 'admin-generic', server_fingerprint: 'desktop',
        config_exposure: 'hidden', known_files_check: 'yes-alt', file_changes: 'edit',
    };

    function renderScanModules(data) {
        var html = '';
        var order = [
            'basic_checks', 'headers_check', 'ssl_check', 'ssl_deep_analysis',
            'wordpress_checks', 'waf_test', 'known_files_check', 'file_changes',
            'malware_scan', 'ml_malware_scan', 'db_scan', 'db_integrity', 'vulnerability_scan',
            'password_audit', 'blocklist_check', 'fpd_check', 'dns_security',
            'rss_spam_check', 'deprecated_php', 'file_permissions',
            'server_fingerprint', 'config_exposure', 'directory_listing',
            'xmlrpc_check', 'cors_check', 'cookie_security', 'file_upload_check',
            'php_info_exposure', 'port_scan', 'ml_analysis'
        ];

        var rendered = {};
        for (var i = 0; i < order.length; i++) {
            if (data[order[i]] !== undefined) {
                rendered[order[i]] = data[order[i]];
            }
        }
        for (var key in data) {
            if (!rendered[key] && key !== 'file_changes' && key !== 'security_status' && key.indexOf('cell_') !== 0) {
                rendered[key] = data[key];
            }
        }

        for (var category in rendered) {
            if (category === 'file_changes' || category === 'integrity' || category === 'security_status') continue;
            if (category.indexOf('cell_') === 0) continue;
            var catData = rendered[category];
            if (typeof catData !== 'object' || catData === null) continue;

            if (category === 'malware_scan' && catData.wp_checksums) {
                html += renderChecksumCard(catData.wp_checksums);
            }
            if (category === 'malware_scan' && catData.secrets_found && catData.secrets_found.length > 0) {
                html += renderSecretsCard(catData.secrets_found);
            }
            if (category === 'malware_scan' && catData.heuristic_scores && catData.heuristic_scores.length > 0) {
                var avg = catData.heuristic_scores.reduce(function(a, b) { return a + b; }, 0) / catData.heuristic_scores.length;
                catData.avg_heuristic_score = Math.round(avg);
                catData.high_risk_files = (catData.suspicious_files || []).length;
            }

            var severity = getCategorySeverity(catData, category);
            var statusBadge = getSeverityBadge(severity);
            var label = moduleLabels[category] || formatCategoryName(category);
            var icon = moduleIcons[category] || 'shield';

            html += '<div class="waf-scan-module" data-severity="' + severity.level + '">';
            html += '<div class="waf-scan-module-header">';
            html += '<span class="dashicons dashicons-' + icon + '" style="color:' + severity.color + '"></span>';
            html += '<h4>' + label + '</h4>';
            html += '<span class="waf-badge ' + statusBadge.class + '">' + statusBadge.label + '</span>';
            html += '</div>';
            html += '<div class="waf-scan-module-body">';
            html += renderCheckItems(catData, category);
            html += '</div></div>';
        }
        $('#wafScanDetails').html(html);
    }

    function renderChecksumCard(checksums) {
        if (!checksums || checksums.checksums_api === 'unreachable') return '';
        var icon = checksums.core_files_modified > 0 ? 'dashicons-dismiss' : 'dashicons-yes-alt';
        var color = checksums.core_files_modified > 0 ? '#ef4444' : '#10b981';
        var badgeClass = checksums.core_files_modified > 0 ? 'waf-badge-fail' : 'waf-badge-pass';
        var badgeLabel = checksums.core_files_modified > 0 ? checksums.core_files_modified + ' Modified' : 'Verified';
        var html = '<div class="waf-scan-module" data-severity="' + (checksums.core_files_modified > 0 ? 'critical' : 'passed') + '">';
        html += '<div class="waf-scan-module-header">';
        html += '<span class="dashicons ' + icon + '" style="color:' + color + '"></span>';
        html += '<h4>WordPress Core Checksum Verification</h4>';
        html += '<span class="waf-badge ' + badgeClass + '">' + badgeLabel + '</span></div>';
        html += '<div class="waf-scan-module-body">';
        html += '<div class="waf-scan-check-row"><span class="waf-scan-check-label">Files Checked</span><span class="waf-scan-check-value">' + checksums.core_files_checked + '</span></div>';
        html += '<div class="waf-scan-check-row"><span class="waf-scan-check-label">Files Modified</span><span class="waf-scan-check-value">' + checksums.core_files_modified + '</span></div>';
        if (checksums.modified_files && checksums.modified_files.length > 0) {
            html += '<div style="margin-top:8px;font-size:12px;color:#991b1b;background:#fef2f2;padding:8px;border-radius:6px;">';
            for (var i = 0; i < Math.min(checksums.modified_files.length, 5); i++) {
                html += '<div>' + checksums.modified_files[i].file + '</div>';
            }
            if (checksums.modified_files.length > 5) html += '<div>...and ' + (checksums.modified_files.length - 5) + ' more</div>';
            html += '</div>';
        }
        html += '</div></div>';
        return html;
    }

    function renderSecretsCard(secrets) {
        var html = '<div class="waf-scan-module" data-severity="critical">';
        html += '<div class="waf-scan-module-header">';
        html += '<span class="dashicons dashicons-lock" style="color:#ef4444"></span>';
        html += '<h4>Exposed Secrets & Credentials</h4>';
        html += '<span class="waf-badge waf-badge-fail">' + secrets.length + ' Leaked</span></div>';
        html += '<div class="waf-scan-module-body">';
        for (var i = 0; i < secrets.length; i++) {
            var s = secrets[i];
            html += '<div class="waf-scan-check-row">';
            html += '<span class="waf-scan-check-label" style="font-size:12px;">' + s.file + '</span>';
            html += '<span class="waf-scan-check-value"><span class="waf-badge waf-badge-fail">Score: ' + s.score + '</span></span>';
            html += '</div>';
            if (s.findings) {
                for (var f = 0; f < Math.min(s.findings.length, 2); f++) {
                    html += '<div style="font-size:11px;color:#991b1b;padding:2px 0 2px 16px;">' + s.findings[f] + '</div>';
                }
            }
        }
        html += '</div></div>';
        return html;
    }

    function formatCategoryName(name) {
        return name.replace(/_/g, ' ').replace(/\b\w/g, function(l) { return l.toUpperCase(); });
    }

    function getCategorySeverity(catData, category) {
        var result = { level: 'passed', label: 'Pass', color: '#10b981', icon: 'yes-alt' };
        for (var key in catData) {
            var val = catData[key];
            if (typeof val === 'boolean' && val === true) { result = { level: 'warnings', label: 'Warning', color: '#f59e0b', icon: 'warning' }; }
            if (typeof val === 'string' && (val === 'Missing' || val === 'Vulnerable')) { result = { level: 'warnings', label: 'Warning', color: '#f59e0b', icon: 'warning' }; }
            if (key.indexOf('vulnerab') !== -1 || key.indexOf('infect') !== -1 || key.indexOf('malware') !== -1) {
                if (val > 0) result = { level: 'critical', label: 'Critical', color: '#ef4444', icon: 'dismiss' };
            }
            if (typeof val === 'object' && val !== null) {
                if (val.total_suspicious > 0 || val.infected_core > 0) result = { level: 'critical', label: 'Critical', color: '#ef4444', icon: 'dismiss' };
                if (val.total_vulnerabilities > 0) result = { level: 'critical', label: 'Critical', color: '#ef4444', icon: 'dismiss' };
                if (val.risk_level === 'critical') result = { level: 'critical', label: 'Critical', color: '#ef4444', icon: 'dismiss' };
                if (val.risk_level === 'warning') result = { level: 'warnings', label: 'Warning', color: '#f59e0b', icon: 'warning' };
                if (val.fpd_detected) result = { level: 'critical', label: 'Critical', color: '#ef4444', icon: 'dismiss' };
                if (val.listed) result = { level: 'critical', label: 'Critical', color: '#ef4444', icon: 'dismiss' };
                if (val.spam_detected) result = { level: 'critical', label: 'Critical', color: '#ef4444', icon: 'dismiss' };
                if (val.grade && val.grade >= 'D') result = { level: 'critical', label: 'Critical', color: '#ef4444', icon: 'dismiss' };
            }
        }
        if (catData.suspicious_found > 0 || catData.infected_core > 0) result = { level: 'critical', label: 'Critical', color: '#ef4444', icon: 'dismiss' };
        if (catData.malicious_count > 0) result = { level: 'critical', label: 'Critical', color: '#ef4444', icon: 'dismiss' };
        if (catData.suspicious_count > 0) result = { level: 'warnings', label: 'Warning', color: '#f59e0b', icon: 'warning' };
        if (catData.total_vulnerabilities > 0) result = { level: 'critical', label: 'Critical', color: '#ef4444', icon: 'dismiss' };
        if (catData.avg_heuristic_score >= 50) result = { level: 'critical', label: 'Critical', color: '#ef4444', icon: 'dismiss' };
        if (catData.avg_heuristic_score >= 25 && catData.avg_heuristic_score < 50) result = { level: 'warnings', label: 'Warning', color: '#f59e0b', icon: 'warning' };
        if (catData.high_risk_files > 0) result = { level: 'critical', label: 'Critical', color: '#ef4444', icon: 'dismiss' };
        if (catData.secrets_found && catData.secrets_found.length > 0) result = { level: 'critical', label: 'Critical', color: '#ef4444', icon: 'dismiss' };
        if (catData.wp_checksums && catData.wp_checksums.core_files_modified > 0) result = { level: 'critical', label: 'Critical', color: '#ef4444', icon: 'dismiss' };
        if (catData.suspicious_users && catData.suspicious_users.length > 0) result = { level: 'critical', label: 'Critical', color: '#ef4444', icon: 'dismiss' };
        if (catData.admin_with_weak && catData.admin_with_weak.length > 0) result = { level: 'critical', label: 'Critical', color: '#ef4444', icon: 'dismiss' };
        if (catData.total_exposed > 0) result = { level: 'critical', label: 'Critical', color: '#ef4444', icon: 'dismiss' };
        if (catData.total_modified > 0) result = { level: 'critical', label: 'Critical', color: '#ef4444', icon: 'dismiss' };
        if (catData.total_unknown > 0 && category === 'known_files_check') result = { level: 'warnings', label: 'Warning', color: '#f59e0b', icon: 'warning' };
        return result;
    }

    function getSeverityBadge(severity) {
        if (severity.level === 'critical') return { class: 'waf-badge-fail', label: 'Issues Found' };
        if (severity.level === 'warnings') return { class: 'waf-badge-warn', label: 'Warnings' };
        return { class: 'waf-badge-pass', label: 'Passed' };
    }

    function renderCheckItems(catData, category) {
        var html = '';
        var skipKeys = { heuristic_scores: 1, infected_files: 1, secrets_found: 1, wp_checksums: 1, modified_files: 1, scanned_categories: 1, deprecated_usages: 1, categories: 1 };

        if (category === 'malware_scan' && catData.suspicious_files && catData.suspicious_files.length > 0) {
            html += renderSuspiciousFilesCard(catData.suspicious_files);
        }
        if (category === 'ml_malware_scan' && ((catData.malicious_files && catData.malicious_files.length > 0) || (catData.suspicious_files && catData.suspicious_files.length > 0))) {
            html += renderMLMalwareFilesCard(catData.malicious_files || [], catData.suspicious_files || []);
        }
        if (category === 'deprecated_php' && catData.deprecated_usages && catData.deprecated_usages.length > 0) {
            html += renderDeprecatedUsagesCard(catData.deprecated_usages, catData.categories || {});
        }

        for (var key in catData) {
            if (skipKeys[key]) continue;
            if (category === 'malware_scan' && key === 'suspicious_files') continue;
            if (category === 'ml_malware_scan' && (key === 'malicious_files' || key === 'suspicious_files' || key === 'clean_files')) continue;
            var val = catData[key];
            if (Array.isArray(val)) {
                if (val.length > 0) {
                    html += '<div class="waf-scan-check-row" style="flex-wrap:wrap;">';
                    html += '<span class="waf-scan-check-label" style="font-weight:600;width:100%;margin-bottom:4px;">' + key.replace(/_/g, ' ') + '</span>';
                    html += '<div style="width:100%;padding-left:8px;">';
                    for (var i = 0; i < Math.min(val.length, 10); i++) {
                        var item = val[i];
                        var display = typeof item === 'object' ? (item.file || item.path || item.user_login || item.description || JSON.stringify(item).substring(0, 80)) : item;
                        html += '<div style="font-size:11px;color:#991b1b;background:#fef2f2;padding:4px 8px;margin:2px 0;border-radius:4px;">' + display + '</div>';
                    }
                    if (val.length > 10) html += '<div style="font-size:11px;color:#64748b;">...and ' + (val.length - 10) + ' more</div>';
                    html += '</div></div>';
                }
                continue;
            }
            if (typeof val === 'object' && val !== null) {
                html += renderObjectCheck(key, val);
                continue;
            }
            html += renderPrimitiveCheck(key, val);
        }
        return html;
    }

    function renderSuspiciousFilesCard(files) {
        var html = '<div style="margin-bottom:12px;border:1px solid #fecaca;border-radius:8px;overflow:hidden;" class="waf-scan-issue-card">';
        html += '<div style="background:#fef2f2;padding:10px 14px;border-bottom:1px solid #fecaca;display:flex;align-items:center;gap:8px;">';
        html += '<span class="dashicons dashicons-warning" style="color:#dc2626;"></span>';
        html += '<strong style="color:#991b1b;font-size:13px;">Suspicious Files (' + files.length + ')</strong>';
        html += '</div><div style="padding:8px 14px;">';
        for (var i = 0; i < files.length; i++) {
            var f = files[i];
            var filePath = f.file || 'Unknown file';
            var severityColor = f.score >= 50 ? '#dc2626' : '#d97706';
            var severityBg = f.score >= 50 ? '#fef2f2' : '#fffbeb';
            html += '<div style="padding:10px;margin:6px 0;background:' + severityBg + ';border-left:3px solid ' + severityColor + ';border-radius:6px;" class="waf-scan-issue-item">';
            html += '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:4px;flex-wrap:wrap;gap:6px;">';
            html += '<span style="font-weight:600;font-size:12px;color:#1e293b;word-break:break-all;">' + filePath + '</span>';
            html += '<span class="waf-badge" style="background:' + severityColor + ';color:#fff;">Score: ' + (f.score || 0) + '</span>';
            html += '</div>';
            if (f.size) html += '<div style="font-size:11px;color:#64748b;margin-bottom:6px;">Size: ' + f.size + ' bytes</div>';
            if (f.findings && f.findings.length > 0) {
                for (var j = 0; j < f.findings.length; j++) {
                    var finding = f.findings[j];
                    html += '<div style="font-size:11px;color:#991b1b;padding:2px 0 2px 8px;">- ' + finding + '</div>';
                }
            }
            html += '<div style="margin-top:8px;padding-top:6px;border-top:1px solid rgba(0,0,0,0.05);display:flex;gap:8px;flex-wrap:wrap;">';
            html += '<button type="button" class="button button-small waf-btn-view-file" data-file="' + filePath + '">View Code</button>';
            if (filePath.indexOf('wp-admin/') === 0 || filePath.indexOf('wp-includes/') === 0 || filePath.indexOf('wp-') === 0 || filePath === 'index.php') {
                html += '<button type="button" class="button button-small button-primary waf-btn-restore-file" data-file="' + filePath + '">Restore Core</button>';
            }
            html += '<button type="button" class="button button-small waf-btn-clean-file" data-file="' + filePath + '" style="color:#dc2626;border-color:#fca5a5;">Clean File</button>';
            html += '<button type="button" class="button button-small waf-btn-ignore-file" data-file="' + filePath + '">Ignore</button>';
            html += '</div>';
            html += '</div>';
        }
        html += '</div></div>';
        return html;
    }
        }
        html += '</div></div>';
        return html;
    }

    function renderMLMalwareFilesCard(malicious, suspicious) {
        var html = '';
        var all = malicious.concat(suspicious);
        for (var i = 0; i < all.length; i++) {
            var f = all[i];
            var isMalicious = f.verdict === 'malicious';
            var color = isMalicious ? '#dc2626' : '#d97706';
            var bg = isMalicious ? '#fef2f2' : '#fffbeb';
            html += '<div style="padding:8px;margin:4px 0;background:' + bg + ';border-left:3px solid ' + color + ';border-radius:4px;">';
            html += '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:4px;gap:8px;flex-wrap:wrap;">';
            html += '<span style="font-weight:600;font-size:12px;color:#1e293b;">' + (f.file || 'Unknown file') + '</span>';
            html += '<span class="waf-badge" style="background:' + color + ';color:#fff;">' + f.verdict.toUpperCase() + ' - Risk: ' + f.risk_score + '</span>';
            html += '</div>';
            html += '<div style="font-size:11px;color:#64748b;display:flex;gap:12px;flex-wrap:wrap;">';
            html += '<span>Confidence: ' + f.confidence + '</span>';
            if (f.family) html += '<span>Family: ' + f.family + '</span>';
            if (f.size) html += '<span>Size: ' + f.size + ' bytes</span>';
            html += '</div>';
            if (f.reasons && f.reasons.length > 0) {
                html += '<div style="font-size:11px;color:' + color + ';padding:2px 0 0 12px;">';
                for (var j = 0; j < f.reasons.length; j++) {
                    html += '<div>- ' + f.reasons[j] + '</div>';
                }
                html += '</div>';
            }
            html += '</div>';
        }
        return html;
    }

    function renderDeprecatedUsagesCard(usages, categories) {
        var html = '<div style="margin-bottom:12px;border:1px solid #fed7aa;border-radius:8px;overflow:hidden;">';
        html += '<div style="background:#fffbeb;padding:10px 14px;border-bottom:1px solid #fed7aa;display:flex;align-items:center;gap:8px;">';
        html += '<span class="dashicons dashicons-warning" style="color:#d97706;"></span>';
        html += '<strong style="color:#92400e;font-size:13px;">Deprecated Functions Found (' + usages.length + ' occurrences)</strong>';
        html += '</div><div style="padding:8px 14px;">';

        var groupedByFile = {};
        for (var i = 0; i < usages.length; i++) {
            var u = usages[i];
            if (!groupedByFile[u.file]) groupedByFile[u.file] = [];
            groupedByFile[u.file].push(u);
        }

        var fileCount = 0;
        for (var file in groupedByFile) {
            if (fileCount >= 15) { html += '<div style="font-size:11px;color:#64748b;padding:4px 0;">...and ' + (Object.keys(groupedByFile).length - 15) + ' more files</div>'; break; }
            var items = groupedByFile[file];
            var catColors = { removed_functions: '#dc2626', deprecated_functions: '#d97706', security_risks: '#7c3aed' };
            var itemCat = items[0].category;
            var catColor = catColors[itemCat] || '#d97706';

            html += '<div style="padding:6px;margin:4px 0;background:#fffbeb;border-left:3px solid ' + catColor + ';border-radius:4px;">';
            html += '<div style="font-weight:600;font-size:12px;color:#1e293b;margin-bottom:2px;">' + file + ' <span class="waf-badge" style="background:' + catColor + ';color:#fff;font-size:10px;">' + items.length + '</span></div>';
            for (var j = 0; j < Math.min(items.length, 3); j++) {
                html += '<div style="font-size:11px;color:#64748b;padding:1px 0 1px 12px;">- ' + items[j].description + '</div>';
            }
            if (items.length > 3) html += '<div style="font-size:10px;color:#94a3b8;padding-left:12px;">...+' + (items.length - 3) + ' more</div>';
            html += '</div>';
            fileCount++;
        }
        html += '</div></div>';
        return html;
    }

    function renderPrimitiveCheck(key, val) {
        var label = key.replace(/_/g, ' ');
        var status, badgeClass;
        if (typeof val === 'boolean') {
            if (val === true) { status = 'Yes'; badgeClass = 'waf-badge-fail'; }
            else { status = 'No'; badgeClass = 'waf-badge-pass'; }
        } else if (val === 'Missing') { status = 'Missing'; badgeClass = 'waf-badge-fail'; }
        else if (val === 'Vulnerable') { status = 'Vulnerable'; badgeClass = 'waf-badge-fail'; }
        else { status = val; badgeClass = 'waf-badge-info'; }
        return '<div class="waf-scan-check-row"><span class="waf-scan-check-label">' + label + '</span><span class="waf-scan-check-value"><span class="waf-badge ' + badgeClass + '">' + status + '</span></span></div>';
    }

    function renderObjectCheck(key, val) {
        if (key === 'security_status') return '';
        var html = '<div class="waf-scan-check-row" style="flex-wrap:wrap;">';
        html += '<span class="waf-scan-check-label" style="font-weight:600;width:100%;margin-bottom:4px;">' + key.replace(/_/g, ' ') + '</span>';
        html += '<div style="display:flex;gap:12px;flex-wrap:wrap;width:100%;padding-left:8px;">';
        for (var sub in val) {
            var subVal = val[sub];
            var subClass = 'waf-badge-info';
            if (typeof subVal === 'boolean') subClass = subVal ? 'waf-badge-fail' : 'waf-badge-pass';
            else if (subVal === 'Missing') subClass = 'waf-badge-fail';
            else if (typeof subVal === 'number' && subVal > 0) subClass = 'waf-badge-fail';
            html += '<span style="font-size:12px;color:#475569;">' + sub.replace(/_/g, ' ') + ': <span class="waf-badge ' + subClass + '">' + subVal + '</span></span>';
        }
        html += '</div></div>';
        return html;
    }

    function filterScanResults(filter) {
        if (filter === 'all') { $('.waf-scan-module').show(); return; }
        $('.waf-scan-module').each(function() {
            var severity = $(this).data('severity');
            if (filter === 'critical' && severity === 'critical') { $(this).show(); }
            else if (filter === 'warnings' && (severity === 'warnings' || severity === 'critical')) { $(this).show(); }
            else if (filter === 'passed' && severity === 'passed') { $(this).show(); }
            else { $(this).hide(); }
        });
    }

    function loadScanHistory() {
        $.get(ajaxurl + '?action=waf_fw_get_scan_history', function(r) {
            if (r.success && r.data && r.data.length > 0) {
                var html = '';
                $.each(r.data, function(i, scan) {
                    var scoreClass = 'good';
                    if (scan.score < 50) scoreClass = 'danger';
                    else if (scan.score < 80) scoreClass = 'warning';
                    var statusLabel = scan.score >= 80 ? 'Passed' : scan.score >= 50 ? 'Warning' : 'Failed';
                    var statusBadge = scan.score >= 80 ? 'waf-badge-pass' : scan.score >= 50 ? 'waf-badge-warn' : 'waf-badge-fail';
                    html += '<tr>';
                    html += '<td style="font-size:13px;color:#64748b;" data-label="Created">' + scan.created_at + '</td>';
                    html += '<td data-label="Type"><span class="waf-badge waf-badge-info">' + scan.scan_type + '</span></td>';
                    html += '<td data-label="Score"><span class="waf-scan-history-score ' + scoreClass + '">' + scan.score + '</span>/100</td>';
                    html += '<td data-label="Issues">' + scan.issues_found + '</td>';
                    html += '<td data-label="Duration">' + scan.duration_seconds + 's</td>';
                    html += '<td data-label="Status"><span class="waf-badge ' + statusBadge + '">' + statusLabel + '</span></td>';
                    html += '<td data-label="Actions"><button class="button button-small waf-email-history-report" data-scan-id="' + scan.id + '" title="Email report">Email</button></td>';
                    html += '</tr>';
                });
                $('#wafScanHistoryBody').html(html);
                $('.waf-email-history-report').on('click', function() {
                    lastScanId = $(this).data('scan-id');
                    $('#wafEmailModal').css('display', 'flex');
                    $('#wafReportEmail').val('').focus();
                });
            }
        });
    }

    function clearScanHistory() {
        if (!confirm('Permanently delete all scan history?')) return;
        $.post(ajaxurl + '?action=waf_fw_clear_scan_history', function(r) {
            if (r.success) {
                $('#wafScanHistoryBody').html('<tr class="war-table-empty"><td colspan="7"><p>No scans yet. Run your first scan above.</p></td></tr>');
            }
        });
    }

    function sendEmailReport(scanId, email) {
        $('#wafEmailSend').prop('disabled', true).text('Sending...');
        $.ajax({
            url: ajaxurl + '?action=waf_fw_email_scan_report',
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({ scan_id: scanId, email: email }),
            success: function(r) {
                $('#wafEmailSend').prop('disabled', false).text('Send Report');
                if (r.success) {
                    alert(r.data.message || 'Report sent successfully');
                    $('#wafEmailModal').hide();
                } else {
                    alert(r.data.message || 'Failed to send report');
                }
            },
            error: function() {
                $('#wafEmailSend').prop('disabled', false).text('Send Report');
                alert('Failed to send email');
            }
        });
    }

    $(document).on('click', '.waf-btn-view-file', function(e) {
        e.preventDefault();
        var file = $(this).data('file');
        showCodePreviewModal(file);
    });

    $(document).on('click', '.waf-btn-clean-file, .waf-btn-delete-file', function(e) {
        e.preventDefault();
        var file = $(this).data('file');
        var row = $(this).closest('.waf-scan-issue-item');
        if (!confirm('Are you sure you want to clean this file? It will be backed up for recovery and then deleted from the website.\n' + file)) return;
        $.ajax({
            url: waf_fw_ajax.ajax_url + '?action=waf_fw_clean_file',
            type: 'POST',
            data: JSON.stringify({ file: file }),
            contentType: 'application/json',
            success: function(r) {
                if (r.success) {
                    alert('File cleaned and backed up successfully!');
                    row.fadeOut(200, function() { $(this).remove(); });
                    loadBackups();
                } else {
                    alert('Error: ' + (r.data ? r.data.message : 'Cleaning failed'));
                }
            }
        });
    });

    $(document).on('click', '.waf-btn-restore-file', function(e) {
        e.preventDefault();
        var file = $(this).data('file');
        var row = $(this).closest('.waf-scan-issue-item');
        if (!confirm('Are you sure you want to replace this modified file with the official copy from WordPress.org?\n' + file)) return;
        $.ajax({
            url: waf_fw_ajax.ajax_url + '?action=waf_fw_restore_core_file',
            type: 'POST',
            data: JSON.stringify({ file: file }),
            contentType: 'application/json',
            success: function(r) {
                if (r.success) {
                    alert('Core file restored successfully from WordPress.org! Original file was backed up for safety.');
                    row.fadeOut(200, function() { $(this).remove(); });
                    loadBackups();
                } else {
                    alert('Error: ' + (r.data ? r.data.message : 'Restoration failed'));
                }
            }
        });
    });

    $(document).on('click', '.waf-btn-ignore-file', function(e) {
        e.preventDefault();
        var file = $(this).data('file');
        var row = $(this).closest('.waf-scan-issue-item');
        $.ajax({
            url: waf_fw_ajax.ajax_url + '?action=waf_fw_ignore_scan_issue',
            type: 'POST',
            data: JSON.stringify({ file: file }),
            contentType: 'application/json',
            success: function(r) {
                if (r.success) {
                    row.fadeOut(200, function() { $(this).remove(); });
                } else {
                    alert('Error ignoring issue.');
                }
            }
        });
    });

    function loadBackups() {
        $.get(ajaxurl + '?action=waf_fw_get_backups', function(r) {
            if (r.success && r.data) {
                $('#wafBackupCount').text(r.data.length + (r.data.length === 1 ? ' Backup' : ' Backups'));
                if (r.data.length > 0) {
                    var html = '';
                    $.each(r.data, function(i, b) {
                        html += '<tr>';
                        html += '<td style="padding:12px 16px;font-size:13px;font-weight:600;color:#1e293b;word-break:break-all;" data-label="Path">' + b.original_path + '</td>';
                        html += '<td style="padding:12px 16px;font-size:13px;color:#64748b;" data-label="Date">' + b.time + '</td>';
                        html += '<td style="padding:12px 16px;font-size:13px;color:#64748b;" data-label="Size">' + b.size + '</td>';
                        html += '<td style="padding:12px 16px;text-align:right;" data-label="Actions">';
                        html += '<button class="button button-small button-primary waf-btn-restore-backup" data-file="' + b.original_path + '" style="margin-right:6px;background:#10b981;border-color:#10b981;">Restore</button>';
                        html += '<button class="button button-small waf-btn-delete-backup" data-file="' + b.original_path + '" style="color:#dc2626;border-color:#fca5a5;">Delete Permanently</button>';
                        html += '</td></tr>';
                    });
                    $('#wafBackupsBody').html(html);
                } else {
                    $('#wafBackupsBody').html('<tr class="war-table-empty"><td colspan="4" style="text-align:center;padding:30px;color:#64748b;">No file backups created yet. Files are backed up automatically before cleaning.</td></tr>');
                }
            }
        });
    }

    $(document).on('click', '.waf-btn-restore-backup', function(e) {
        e.preventDefault();
        var file = $(this).data('file');
        if (!confirm('Are you sure you want to restore this file to its original location?\n' + file)) return;
        $.ajax({
            url: waf_fw_ajax.ajax_url + '?action=waf_fw_restore_file',
            type: 'POST',
            data: JSON.stringify({ file: file }),
            contentType: 'application/json',
            success: function(r) {
                if (r.success) {
                    alert('File restored successfully!');
                    loadBackups();
                } else {
                    alert('Error: ' + (r.data ? r.data.message : 'Restoration failed'));
                }
            }
        });
    });

    $(document).on('click', '.waf-btn-delete-backup', function(e) {
        e.preventDefault();
        var file = $(this).data('file');
        if (!confirm('Are you sure you want to permanently delete this backup file? This action CANNOT be undone.\n' + file)) return;
        $.ajax({
            url: waf_fw_ajax.ajax_url + '?action=waf_fw_delete_backup',
            type: 'POST',
            data: JSON.stringify({ file: file }),
            contentType: 'application/json',
            success: function(r) {
                if (r.success) {
                    alert('Backup deleted permanently.');
                    loadBackups();
                } else {
                    alert('Error: ' + (r.data ? r.data.message : 'Deletion failed'));
                }
            }
        });
    });

    function showCodePreviewModal(file) {
        var modal = $('#wafCodeModal');
        if (!modal.length) {
            $('body').append('<div id="wafCodeModal" style="display:none;position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(15,23,42,0.7);z-index:999999;align-items:center;justify-content:center;"><div style="background:#fff;border-radius:12px;width:90%;max-width:800px;max-height:85vh;display:flex;flex-direction:column;overflow:hidden;box-shadow:0 20px 40px rgba(0,0,0,0.3);"><div style="background:#f8fafc;padding:16px 20px;border-bottom:1px solid #e2e8f0;display:flex;justify-content:space-between;align-items:center;"><strong id="wafModalTitle" style="font-size:14px;color:#0f172a;word-break:break-all;">File Preview</strong><button type="button" class="button button-small" id="wafCloseModalBtn">&times; Close</button></div><pre id="wafModalCode" style="background:#0f172a;color:#cbd5e1;padding:20px;margin:0;overflow:auto;flex:1;font-family:monospace;font-size:12px;line-height:1.5;"></pre></div></div>');
            modal = $('#wafCodeModal');
            $('#wafCloseModalBtn').on('click', function() { modal.hide(); });
        }
        $('#wafModalTitle').text('Loading: ' + file);
        $('#wafModalCode').text('Loading file contents...');
        modal.css('display', 'flex');

        $.get(waf_fw_ajax.ajax_url + '?action=waf_fw_view_scan_file&file=' + encodeURIComponent(file), function(r) {
            if (r.success && r.data) {
                $('#wafModalTitle').text('Viewing: ' + r.data.file + ' (' + r.data.size + ' bytes)');
                $('#wafModalCode').text(r.data.content);
            } else {
                $('#wafModalCode').text('Failed to load file contents: ' + (r.data ? r.data.message : 'Unknown error'));
            }
        });
    }

    $(document).ready(function() {
        loadScanHistory();
        loadBackups();
        $('#wafClearHistory').on('click', clearScanHistory);
    });
})(jQuery);
