<div class="waf-scan-wrapper">
    <!-- Top Scanner Hero Card -->
    <div class="war-card" style="margin-bottom:20px;background:#ffffff;border:1px solid #e2e8f0;border-radius:14px;overflow:hidden;box-shadow:0 4px 20px rgba(0,0,0,0.03);">
        <div class="war-card-header" style="background:#f8fafc;padding:18px 24px;border-bottom:1px solid #e2e8f0;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;">
            <div style="display:flex;align-items:center;gap:14px;">
                <div style="width:42px;height:42px;border-radius:10px;background:linear-gradient(135deg,#2563eb,#7c3aed);display:flex;align-items:center;justify-content:center;color:#fff;">
                    <span class="dashicons dashicons-shield" style="font-size:24px;width:24px;height:24px;"></span>
                </div>
                <div>
                    <h3 style="margin:0;font-size:18px;font-weight:700;color:#0f172a;">MDefender-Pro Security Scanner</h3>
                    <p style="margin:2px 0 0;font-size:12px;color:#64748b;">Wordfence-style multi-vector malware, file integrity, and vulnerability scanner</p>
                </div>
            </div>
            <div style="display:flex;gap:10px;align-items:center;">
                <span class="war-card-badge war-card-badge-green" id="wafCloudScanBadge" style="display:inline-flex;align-items:center;gap:6px;padding:5px 12px;font-size:12px;border-radius:20px;">
                    <span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:#10b981;"></span> Cloud ML Engine Active
                </span>
                <button type="button" class="button" id="wafOpenScheduleBtn" style="height:34px;line-height:32px;display:inline-flex;align-items:center;gap:6px;">
                    <span class="dashicons dashicons-calendar-alt" style="font-size:16px;width:16px;height:16px;"></span> Schedule Scans
                </button>
            </div>
        </div>

        <div class="war-card-body" style="padding:24px;">
            <!-- Scan Launcher Profile Selector -->
            <div style="display:grid;grid-template-columns:repeat(auto-fit, minmax(220px, 1fr));gap:14px;margin-bottom:20px;">
                <label class="waf-scan-profile-card active" data-type="full">
                    <input type="radio" name="waf_scan_profile" value="full" checked style="display:none;">
                    <div style="font-weight:700;font-size:14px;color:#0f172a;margin-bottom:4px;display:flex;align-items:center;gap:6px;">
                        <span class="dashicons dashicons-yes-alt" style="color:#2563eb;"></span> Standard Scan
                    </div>
                    <div style="font-size:12px;color:#64748b;line-height:1.4;">Complete 30+ module sweep of core, plugins, themes, and cloud ML malware scan. (Recommended)</div>
                </label>

                <label class="waf-scan-profile-card" data-type="quick">
                    <input type="radio" name="waf_scan_profile" value="quick" style="display:none;">
                    <div style="font-weight:700;font-size:14px;color:#0f172a;margin-bottom:4px;display:flex;align-items:center;gap:6px;">
                        <span class="dashicons dashicons-performance" style="color:#3b82f6;"></span> Quick Scan
                    </div>
                    <div style="font-size:12px;color:#64748b;line-height:1.4;">Fast audit of core file checksums, exposed secrets, and high-risk directories.</div>
                </label>

                <label class="waf-scan-profile-card" data-type="malware">
                    <input type="radio" name="waf_scan_profile" value="malware" style="display:none;">
                    <div style="font-weight:700;font-size:14px;color:#0f172a;margin-bottom:4px;display:flex;align-items:center;gap:6px;">
                        <span class="dashicons dashicons-hidden" style="color:#ef4444;"></span> High Sensitivity
                    </div>
                    <div style="font-size:12px;color:#64748b;line-height:1.4;">Deep heuristic file scan: base64 decoders, webshells, backdoors, and image PHP tags.</div>
                </label>

                <label class="waf-scan-profile-card" data-type="custom">
                    <input type="radio" name="waf_scan_profile" value="custom" style="display:none;">
                    <div style="font-weight:700;font-size:14px;color:#0f172a;margin-bottom:4px;display:flex;align-items:center;gap:6px;">
                        <span class="dashicons dashicons-admin-generic" style="color:#8b5cf6;"></span> Custom Scan
                    </div>
                    <div style="font-size:12px;color:#64748b;line-height:1.4;">Select individual modules: database, sensitive files, API exposure, permissions.</div>
                </label>
            </div>

            <!-- Custom Type Dropdown (Shown when custom is selected) -->
            <div id="wafCustomSelectWrap" style="display:none;margin-bottom:18px;background:#f8fafc;padding:12px 16px;border-radius:8px;border:1px solid #e2e8f0;">
                <label style="font-size:12px;font-weight:600;color:#475569;display:block;margin-bottom:6px;">Specific Scan Target:</label>
                <select id="wafScanType" style="width:100%;max-width:400px;height:36px;border-radius:6px;border:1px solid #cbd5e1;font-size:13px;">
                    <option value="full">Standard Full Scan</option>
                    <option value="quick">Quick Health Scan</option>
                    <option value="malware">Malware & Web Shells</option>
                    <option value="integrity">Core File Integrity Check</option>
                    <option value="sensitive">Exposed Files (.env, .git, backups)</option>
                    <option value="database">Database Injection & Suspicious Admin Audit</option>
                    <option value="plugins">Plugin & Theme Vulnerabilities</option>
                    <option value="file_permissions">File & Directory Permissions</option>
                    <option value="api">REST API & XML-RPC Security</option>
                    <option value="blocklist">IP & Domain DNSBL Blocklists</option>
                    <option value="ssl">SSL/TLS & Security Headers</option>
                </select>
            </div>

            <!-- Controls bar -->
            <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;">
                <div style="display:flex;gap:10px;align-items:center;">
                    <button class="button button-primary button-hero" id="wafStartScan" style="font-weight:700;font-size:14px;height:44px;line-height:42px;padding:0 28px;border-radius:8px;background:linear-gradient(135deg,#2563eb,#1d4ed8);border:none;box-shadow:0 4px 14px rgba(37,99,235,0.35);">
                        <span class="dashicons dashicons-search" style="font-size:18px;width:18px;height:18px;margin-top:2px;"></span> Start New Scan
                    </button>
                    <button class="button" id="wafPauseScan" style="display:none;height:44px;line-height:42px;padding:0 18px;border-radius:8px;background:#f59e0b;color:#fff;border-color:#f59e0b;font-weight:600;">Pause</button>
                    <button class="button" id="wafCancelScan" style="display:none;height:44px;line-height:42px;padding:0 18px;border-radius:8px;color:#ef4444;border-color:#ef4444;font-weight:600;">Cancel</button>
                </div>
                <div id="wafScanHeaderStatus" style="font-size:13px;color:#64748b;">
                    Ready to scan. Click <strong>Start New Scan</strong> to initiate security analysis.
                </div>
            </div>

            <!-- Wordfence-Style Live Progress & Stage Pipeline -->
            <div id="wafScanProgress" style="display:none;margin-top:24px;border-top:1px solid #f1f5f9;padding-top:20px;">
                <!-- Main Progress Bar -->
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;">
                    <div style="display:flex;align-items:center;gap:8px;">
                        <span class="waf-spinner-radar"></span>
                        <strong id="wafScanStage" style="font-size:14px;color:#0f172a;">Initializing scan...</strong>
                    </div>
                    <span id="wafScanProgressPct" style="font-size:14px;font-weight:800;color:#2563eb;">0%</span>
                </div>
                <div class="waf-scan-progress-bar" style="height:8px;background:#e2e8f0;border-radius:999px;overflow:hidden;margin-bottom:14px;">
                    <div class="waf-scan-progress-fill" id="wafScanProgressFill" style="width:2%;height:100%;background:linear-gradient(90deg,#2563eb,#8b5cf6);border-radius:999px;transition:width 0.4s ease;"></div>
                </div>

                <!-- Wordfence Stage Checklist Pipeline -->
                <div class="waf-stage-pipeline" style="display:grid;grid-template-columns:repeat(auto-fit, minmax(130px, 1fr));gap:8px;margin-bottom:16px;">
                    <div class="waf-stage-step" id="step-prep" data-stage="prep">
                        <div class="waf-stage-step-dot"></div>
                        <span>1. Server State</span>
                    </div>
                    <div class="waf-stage-step" id="step-waf" data-stage="waf">
                        <div class="waf-stage-step-dot"></div>
                        <span>2. WAF & Rules</span>
                    </div>
                    <div class="waf-stage-step" id="step-core" data-stage="core">
                        <div class="waf-stage-step-dot"></div>
                        <span>3. File Integrity</span>
                    </div>
                    <div class="waf-stage-step" id="step-malware" data-stage="malware">
                        <div class="waf-stage-step-dot"></div>
                        <span>4. Cloud AI Malware</span>
                    </div>
                    <div class="waf-stage-step" id="step-vuln" data-stage="vuln">
                        <div class="waf-stage-step-dot"></div>
                        <span>5. Vulnerabilities</span>
                    </div>
                    <div class="waf-stage-step" id="step-sensitive" data-stage="sensitive">
                        <div class="waf-stage-step-dot"></div>
                        <span>6. Sensitive Files</span>
                    </div>
                    <div class="waf-stage-step" id="step-blacklist" data-stage="blacklist">
                        <div class="waf-stage-step-dot"></div>
                        <span>7. Reputation</span>
                    </div>
                </div>

                <!-- Live Stream Console -->
                <div style="background:#0f172a;border-radius:8px;padding:12px 16px;color:#94a3b8;font-family:monospace;font-size:12px;display:flex;justify-content:space-between;align-items:center;gap:12px;">
                    <div style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:#38bdf8;">
                        <span id="wafStreamPrefix">&gt;&gt;</span> <span id="wafStageDetailDesc">Preparing security scanner environment...</span>
                    </div>
                    <div style="white-space:nowrap;color:#64748b;font-size:11px;">
                        <span id="wafScannedFileCount">0</span> / <span id="wafTotalFileCount">0</span> files &bull; Elapsed: <span id="wafScanElapsed">0s</span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Scan Results Card (Shown after scan completes) -->
    <div id="wafScanResults" style="display:none;">
        <!-- Banner Status -->
        <div class="waf-scan-result-header" id="wafScanStatusBanner" style="background:#ffffff;border:1px solid #e2e8f0;border-radius:14px;padding:20px 24px;margin-bottom:20px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:14px;">
            <div style="display:flex;align-items:center;gap:16px;">
                <div class="waf-scan-status-icon" id="wafStatusIconBox" style="width:48px;height:48px;border-radius:12px;display:flex;align-items:center;justify-content:center;background:#dcfce7;color:#166534;">
                    <span class="dashicons dashicons-yes-alt" id="wafStatusIcon" style="font-size:28px;width:28px;height:28px;"></span>
                </div>
                <div>
                    <h3 id="wafStatusLabel" style="margin:0 0 4px;font-size:18px;font-weight:700;color:#0f172a;">Scan Complete</h3>
                    <p id="wafStatusMessage" style="margin:0;font-size:13px;color:#64748b;">Your site was analyzed across 30+ security modules.</p>
                </div>
            </div>
            <div style="display:flex;gap:8px;align-items:center;">
                <button class="button" id="wafEmailReport" style="height:36px;line-height:34px;">
                    <span class="dashicons dashicons-email-alt" style="font-size:16px;width:16px;height:16px;"></span> Email Report
                </button>
                <button class="button button-primary" id="wafRescanBtn" style="height:36px;line-height:34px;">
                    <span class="dashicons dashicons-update" style="font-size:16px;width:16px;height:16px;"></span> Rescan Now
                </button>
            </div>
        </div>

        <!-- Metrics & Score Grid -->
        <div class="waf-score-grid" style="display:grid;grid-template-columns:repeat(auto-fit, minmax(160px, 1fr));gap:14px;margin-bottom:20px;">
            <div class="waf-score-card waf-score-primary" style="background:#fff;border-radius:12px;padding:18px;text-align:center;border:1px solid #e2e8f0;">
                <div class="waf-score-circle" id="wafScoreCircle" style="width:70px;height:70px;border-radius:50%;display:flex;flex-direction:column;align-items:center;justify-content:center;margin:0 auto 8px;border:4px solid #10b981;">
                    <span class="waf-score-number" id="wafScanScore" style="font-size:24px;font-weight:800;color:#0f172a;line-height:1;">100</span>
                    <span class="waf-score-unit" style="font-size:10px;color:#94a3b8;font-weight:600;">/ 100</span>
                </div>
                <div class="waf-score-label" style="font-size:12px;font-weight:600;color:#64748b;">Security Score</div>
                <div class="waf-score-grade" id="wafScanGrade" style="font-size:11px;font-weight:700;margin-top:2px;">EXCELLENT</div>
            </div>

            <div class="waf-score-card" style="background:#fff;border-radius:12px;padding:18px;text-align:center;border:1px solid #e2e8f0;">
                <span class="dashicons dashicons-warning" style="font-size:24px;width:24px;height:24px;color:#ef4444;margin-bottom:4px;"></span>
                <span class="waf-stat-value" id="wafScanIssues" style="display:block;font-size:26px;font-weight:800;color:#0f172a;line-height:1.2;">0</span>
                <span class="waf-stat-label" style="font-size:12px;color:#64748b;font-weight:500;">Issues Found</span>
            </div>

            <div class="waf-score-card" style="background:#fff;border-radius:12px;padding:18px;text-align:center;border:1px solid #e2e8f0;">
                <span class="dashicons dashicons-media-code" style="font-size:24px;width:24px;height:24px;color:#3b82f6;margin-bottom:4px;"></span>
                <span class="waf-stat-value" id="wafScannedFiles" style="display:block;font-size:26px;font-weight:800;color:#0f172a;line-height:1.2;">0</span>
                <span class="waf-stat-label" style="font-size:12px;color:#64748b;font-weight:500;">Files Scanned</span>
            </div>

            <div class="waf-score-card" style="background:#fff;border-radius:12px;padding:18px;text-align:center;border:1px solid #e2e8f0;">
                <span class="dashicons dashicons-clock" style="font-size:24px;width:24px;height:24px;color:#8b5cf6;margin-bottom:4px;"></span>
                <span class="waf-stat-value" id="wafScanDuration" style="display:block;font-size:26px;font-weight:800;color:#0f172a;line-height:1.2;">0s</span>
                <span class="waf-stat-label" style="font-size:12px;color:#64748b;font-weight:500;">Duration</span>
            </div>

            <div class="waf-score-card" style="background:#fff;border-radius:12px;padding:18px;text-align:center;border:1px solid #e2e8f0;">
                <span class="dashicons dashicons-shield-alt" style="font-size:24px;width:24px;height:24px;color:#10b981;margin-bottom:4px;"></span>
                <span class="waf-stat-value" id="wafScanChecks" style="display:block;font-size:26px;font-weight:800;color:#0f172a;line-height:1.2;">0</span>
                <span class="waf-stat-label" style="font-size:12px;color:#64748b;font-weight:500;">Checks Passed</span>
            </div>
        </div>

        <!-- Wordfence-Style Finding Accordion Box -->
        <div class="war-card" style="background:#fff;border:1px solid #e2e8f0;border-radius:14px;overflow:hidden;margin-bottom:20px;">
            <div class="war-card-header" style="background:#f8fafc;padding:16px 20px;border-bottom:1px solid #e2e8f0;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px;">
                <h3 style="margin:0;font-size:16px;font-weight:700;color:#0f172a;">Detailed Scan Findings</h3>
                <div class="waf-scan-detail-tabs" style="display:flex;gap:6px;">
                    <button class="waf-scan-tab active" data-tab="all">All Findings</button>
                    <button class="waf-scan-tab" data-tab="critical">Critical Threats</button>
                    <button class="waf-scan-tab" data-tab="warnings">Warnings</button>
                    <button class="waf-scan-tab" data-tab="passed">Passed Checks</button>
                </div>
            </div>
            <div class="war-card-body" style="padding:20px;">
                <div id="wafScanDetails"></div>
            </div>
        </div>
    </div>

    <!-- Backups & Restore Card -->
    <div class="war-card" style="background:#fff;border:1px solid #e2e8f0;border-radius:14px;overflow:hidden;margin-bottom:20px;">
        <div class="war-card-header" style="background:#f8fafc;padding:16px 20px;border-bottom:1px solid #e2e8f0;display:flex;align-items:center;justify-content:space-between;">
            <div style="display:flex;align-items:center;gap:10px;">
                <span class="dashicons dashicons-backup" style="color:#2563eb;font-size:20px;width:20px;height:20px;margin-top:2px;"></span>
                <h3 style="margin:0;font-size:16px;font-weight:700;color:#0f172a;">Malware Backups (Restore)</h3>
                <span class="war-card-badge war-card-badge-blue" id="wafBackupCount">0 Backups</span>
            </div>
        </div>
        <div class="war-card-body war-card-body-no-pad" style="padding:0;">
            <table class="war-table war-r-table" style="width:100%;border-collapse:collapse;">
                <thead>
                    <tr style="background:#f1f5f9;border-bottom:1px solid #e2e8f0;text-align:left;">
                        <th style="padding:12px 16px;font-size:12px;font-weight:600;color:#475569;">Original File Path</th>
                        <th style="padding:12px 16px;font-size:12px;font-weight:600;color:#475569;">Backup Date</th>
                        <th style="padding:12px 16px;font-size:12px;font-weight:600;color:#475569;">Size</th>
                        <th style="padding:12px 16px;font-size:12px;font-weight:600;color:#475569;text-align:right;">Actions</th>
                    </tr>
                </thead>
                <tbody id="wafBackupsBody">
                    <tr class="war-table-empty">
                        <td colspan="4" style="text-align:center;padding:30px;color:#64748b;">
                            No file backups created yet. Files are backed up automatically before cleaning.
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Scan History Card -->
    <div class="war-card" style="background:#fff;border:1px solid #e2e8f0;border-radius:14px;overflow:hidden;">
        <div class="war-card-header" style="background:#f8fafc;padding:16px 20px;border-bottom:1px solid #e2e8f0;display:flex;align-items:center;justify-content:space-between;">
            <div style="display:flex;align-items:center;gap:10px;">
                <h3 style="margin:0;font-size:16px;font-weight:700;color:#0f172a;">Scan History</h3>
                <span class="war-card-badge" style="font-size:11px;padding:3px 8px;">Recent 10 Scans</span>
            </div>
            <button class="button button-small" id="wafClearHistory" style="color:#ef4444;border-color:#fca5a5;">Clear History</button>
        </div>
        <div class="war-card-body war-card-body-no-pad" style="padding:0;">
            <table class="war-table war-r-table" style="width:100%;border-collapse:collapse;">
                <thead>
                    <tr style="background:#f1f5f9;border-bottom:1px solid #e2e8f0;text-align:left;">
                        <th style="padding:12px 16px;font-size:12px;font-weight:600;color:#475569;">Date & Time</th>
                        <th style="padding:12px 16px;font-size:12px;font-weight:600;color:#475569;">Scan Type</th>
                        <th style="padding:12px 16px;font-size:12px;font-weight:600;color:#475569;">Score</th>
                        <th style="padding:12px 16px;font-size:12px;font-weight:600;color:#475569;">Issues</th>
                        <th style="padding:12px 16px;font-size:12px;font-weight:600;color:#475569;">Duration</th>
                        <th style="padding:12px 16px;font-size:12px;font-weight:600;color:#475569;">Status</th>
                        <th style="padding:12px 16px;font-size:12px;font-weight:600;color:#475569;text-align:right;">Actions</th>
                    </tr>
                </thead>
                <tbody id="wafScanHistoryBody">
                    <tr class="war-table-empty">
                        <td colspan="7" style="text-align:center;padding:30px;color:#64748b;">
                            No scans yet. Run your first scan above.
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Schedule Modal -->
<div id="wafScheduleModal" style="display:none;position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(15,23,42,0.65);backdrop-filter:blur(4px);z-index:99999;align-items:center;justify-content:center;">
    <div style="background:#fff;border-radius:14px;padding:24px;width:440px;max-width:92%;box-shadow:0 25px 60px rgba(0,0,0,0.3);border:1px solid #e2e8f0;">
        <h3 style="margin:0 0 6px;font-size:18px;font-weight:700;color:#0f172a;">Automated Scan Scheduling</h3>
        <p style="font-size:13px;color:#64748b;margin:0 0 16px;">Configure periodic background security scans powered by WP-Cron.</p>
        
        <div style="margin-bottom:14px;">
            <label style="display:flex;align-items:center;gap:8px;font-weight:600;font-size:13px;color:#0f172a;cursor:pointer;">
                <input type="checkbox" id="wafScheduledScanEnabled" value="yes" <?php checked(get_option('waf_fw_scheduled_scan_enabled', 'yes'), 'yes'); ?>>
                Enable Automated Background Scanning
            </label>
        </div>

        <div style="margin-bottom:14px;">
            <label style="font-size:12px;font-weight:600;color:#475569;display:block;margin-bottom:4px;">Frequency:</label>
            <select id="wafScheduledScanInterval" style="width:100%;height:36px;border-radius:6px;border:1px solid #cbd5e1;font-size:13px;">
                <option value="daily" <?php selected(get_option('waf_fw_scheduled_scan_interval', 'weekly'), 'daily'); ?>>Daily Scan</option>
                <option value="weekly" <?php selected(get_option('waf_fw_scheduled_scan_interval', 'weekly'), 'weekly'); ?>>Weekly Scan (Recommended)</option>
                <option value="monthly" <?php selected(get_option('waf_fw_scheduled_scan_interval', 'weekly'), 'monthly'); ?>>Monthly Scan</option>
            </select>
        </div>

        <div style="margin-bottom:18px;">
            <label style="font-size:12px;font-weight:600;color:#475569;display:block;margin-bottom:4px;">Email Security Report to:</label>
            <input type="email" id="wafScheduledScanEmail" value="<?php echo esc_attr(get_option('waf_fw_scheduled_scan_email', get_option('admin_email'))); ?>" placeholder="admin@example.com" style="width:100%;height:36px;border-radius:6px;border:1px solid #cbd5e1;padding:0 12px;font-size:13px;">
        </div>

        <div style="display:flex;gap:8px;justify-content:flex-end;">
            <button type="button" class="button" id="wafScheduleCancel">Cancel</button>
            <button type="button" class="button button-primary" id="wafScheduleSave">Save Schedule</button>
        </div>
    </div>
</div>

<!-- Email Report Modal -->
<div id="wafEmailModal" style="display:none;position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(15,23,42,0.65);backdrop-filter:blur(4px);z-index:99999;align-items:center;justify-content:center;">
    <div style="background:#fff;border-radius:14px;padding:24px;width:400px;max-width:92%;box-shadow:0 25px 60px rgba(0,0,0,0.3);border:1px solid #e2e8f0;">
        <h3 style="margin:0 0 6px;font-size:18px;font-weight:700;color:#0f172a;">Email Scan Report</h3>
        <p style="font-size:13px;color:#64748b;margin:0 0 16px;">Send the full scan assessment to your email.</p>
        <input type="email" id="wafReportEmail" value="<?php echo esc_attr(get_option('admin_email')); ?>" style="width:100%;height:36px;border-radius:6px;border:1px solid #cbd5e1;padding:0 12px;font-size:13px;box-sizing:border-box;margin-bottom:16px;">
        <div style="display:flex;gap:8px;justify-content:flex-end;">
            <button type="button" class="button" id="wafEmailCancel">Cancel</button>
            <button type="button" class="button button-primary" id="wafEmailSend">Send Report</button>
        </div>
    </div>
</div>

<style>
.waf-scan-profile-card {
    border: 2px solid #e2e8f0;
    border-radius: 10px;
    padding: 14px;
    cursor: pointer;
    transition: all 0.2s ease;
    background: #fff;
}
.waf-scan-profile-card:hover {
    border-color: #93c5fd;
    background: #f8fafc;
}
.waf-scan-profile-card.active {
    border-color: #2563eb;
    background: #eff6ff;
}
.waf-stage-step {
    display: flex;
    align-items: center;
    gap: 6px;
    padding: 6px 10px;
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 6px;
    font-size: 11px;
    font-weight: 600;
    color: #64748b;
    transition: all 0.2s;
}
.waf-stage-step-dot {
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: #cbd5e1;
    transition: all 0.2s;
}
.waf-stage-step.active {
    background: #eff6ff;
    border-color: #93c5fd;
    color: #1d4ed8;
}
.waf-stage-step.active .waf-stage-step-dot {
    background: #2563eb;
    box-shadow: 0 0 0 3px rgba(37,99,235,0.2);
}
.waf-stage-step.done {
    background: #f0fdf4;
    border-color: #bbf7d0;
    color: #166534;
}
.waf-stage-step.done .waf-stage-step-dot {
    background: #10b981;
}
.waf-spinner-radar {
    width: 14px;
    height: 14px;
    border: 2px solid rgba(37,99,235,0.2);
    border-top-color: #2563eb;
    border-radius: 50%;
    animation: wafSpin 0.7s infinite linear;
    display: inline-block;
}
@keyframes wafSpin {
    to { transform: rotate(360deg); }
}
.waf-scan-tab {
    padding: 6px 14px;
    border: 1px solid #cbd5e1;
    background: #fff;
    border-radius: 6px;
    cursor: pointer;
    font-size: 12px;
    font-weight: 600;
    color: #475569;
    transition: all .15s;
}
.waf-scan-tab:hover {
    border-color: #2563eb;
    color: #2563eb;
}
.waf-scan-tab.active {
    background: #2563eb;
    color: #fff;
    border-color: #2563eb;
}
.waf-finding-card {
    border: 1px solid #e2e8f0;
    border-radius: 10px;
    margin-bottom: 12px;
    background: #fff;
    overflow: hidden;
    transition: box-shadow 0.2s;
}
.waf-finding-card:hover {
    box-shadow: 0 4px 12px rgba(0,0,0,0.04);
}
.waf-finding-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 14px 18px;
    cursor: pointer;
    background: #f8fafc;
    border-bottom: 1px solid #f1f5f9;
}
.waf-finding-body {
    padding: 16px 18px;
    display: none;
    background: #fff;
}
.waf-finding-body.open {
    display: block;
}
</style>

<script>
jQuery(document).ready(function($) {
    // Profile card selector
    $('.waf-scan-profile-card').on('click', function() {
        $('.waf-scan-profile-card').removeClass('active');
        $(this).addClass('active');
        var type = $(this).data('type');
        if (type === 'custom') {
            $('#wafCustomSelectWrap').slideDown(150);
        } else {
            $('#wafCustomSelectWrap').slideUp(150);
            $('#wafScanType').val(type);
        }
    });

    // Schedule modal controls
    $('#wafOpenScheduleBtn').on('click', function() {
        $('#wafScheduleModal').css('display', 'flex');
    });

    $('#wafScheduleCancel').on('click', function() {
        $('#wafScheduleModal').hide();
    });

    $('#wafScheduleSave').on('click', function() {
        var enabled = $('#wafScheduledScanEnabled').is(':checked') ? 'yes' : 'no';
        var interval = $('#wafScheduledScanInterval').val();
        var email = $('#wafScheduledScanEmail').val();

        $.post(ajaxurl + '?action=waf_fw_save_scheduled_scan_settings', {
            enabled: enabled,
            interval: interval,
            email: email
        }, function(r) {
            if (r.success) {
                alert('Scan schedule saved successfully!');
                $('#wafScheduleModal').hide();
            } else {
                alert('Failed to save schedule: ' + (r.data ? r.data.message : 'Unknown error'));
            }
        });
    });
});
</script>