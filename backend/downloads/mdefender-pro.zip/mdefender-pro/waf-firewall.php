<?php
/**
 * MDefender-Pro Core Firewall & Security Engine
 *
 * @package MDefender-Pro
 */

defined('ABSPATH') || exit;

if (!defined('WAF_FW_VERSION')) define('WAF_FW_VERSION', '4.2.2');
if (!defined('WAF_FW_PLUGIN_DIR')) define('WAF_FW_PLUGIN_DIR', plugin_dir_path(__FILE__));
if (!defined('WAF_FW_PLUGIN_URL')) define('WAF_FW_PLUGIN_URL', plugin_dir_url(__FILE__));
if (!defined('WAF_FW_MAIN_FILE')) define('WAF_FW_MAIN_FILE', __FILE__);

if (!defined('WAF_FW_TABLE_ATTACKS')) define('WAF_FW_TABLE_ATTACKS', 'waf_attacks');
if (!defined('WAF_FW_TABLE_REQUESTS')) define('WAF_FW_TABLE_REQUESTS', 'waf_requests');
if (!defined('WAF_FW_TABLE_BLACKLIST')) define('WAF_FW_TABLE_BLACKLIST', 'waf_blacklist');
if (!defined('WAF_FW_TABLE_LOGIN_ATTEMPTS')) define('WAF_FW_TABLE_LOGIN_ATTEMPTS', 'waf_login_attempts');
if (!defined('WAF_FW_TABLE_SCAN_RESULTS')) define('WAF_FW_TABLE_SCAN_RESULTS', 'waf_scan_results');
if (!defined('WAF_FW_TABLE_FILE_INTEGRITY')) define('WAF_FW_TABLE_FILE_INTEGRITY', 'waf_file_integrity');
if (!defined('WAF_FW_TABLE_FILE_CHANGES')) define('WAF_FW_TABLE_FILE_CHANGES', 'waf_file_changes');
if (!defined('WAF_FW_TABLE_SCAN_QUEUE')) define('WAF_FW_TABLE_SCAN_QUEUE', 'waf_scan_queue');
if (!defined('WAF_FW_TABLE_FIREWALL_RULES')) define('WAF_FW_TABLE_FIREWALL_RULES', 'waf_firewall_rules');
if (!defined('WAF_FW_TABLE_HARDENING')) define('WAF_FW_TABLE_HARDENING', 'waf_hardening_status');
if (!defined('WAF_FW_TABLE_SCAN_FILES_QUEUE')) define('WAF_FW_TABLE_SCAN_FILES_QUEUE', 'waf_scan_files_queue');
if (!defined('WAF_FW_TABLE_CLEANED_BACKUPS')) define('WAF_FW_TABLE_CLEANED_BACKUPS', 'waf_cleaned_backups');
if (!defined('WAF_FW_TABLE_SECURITY_EVENTS')) define('WAF_FW_TABLE_SECURITY_EVENTS', 'waf_security_events');

if (defined('WAF_FW_MAIN_FILE')) {
    register_activation_hook(WAF_FW_MAIN_FILE, 'waf_fw_activate');
    register_deactivation_hook(WAF_FW_MAIN_FILE, 'waf_fw_deactivate');
}

require_once WAF_FW_PLUGIN_DIR . 'includes/class-db.php';
require_once WAF_FW_PLUGIN_DIR . 'includes/class-logger.php';
require_once WAF_FW_PLUGIN_DIR . 'includes/class-semantic-deobfuscator.php';
require_once WAF_FW_PLUGIN_DIR . 'includes/class-ja4-fingerprint.php';
require_once WAF_FW_PLUGIN_DIR . 'includes/class-rasp-engine.php';
require_once WAF_FW_PLUGIN_DIR . 'includes/hardening/class-website-hardening.php';
require_once WAF_FW_PLUGIN_DIR . 'includes/hardening/class-admin-panel-ip.php';
require_once WAF_FW_PLUGIN_DIR . 'includes/backup/class-backup-engine.php';
require_once WAF_FW_PLUGIN_DIR . 'includes/class-rule-engine.php';
require_once WAF_FW_PLUGIN_DIR . 'includes/class-feature-extractor.php';
require_once WAF_FW_PLUGIN_DIR . 'includes/class-ml-api-client.php';
require_once WAF_FW_PLUGIN_DIR . 'includes/class-rate-limiter.php';
require_once WAF_FW_PLUGIN_DIR . 'includes/class-ip-filter.php';
require_once WAF_FW_PLUGIN_DIR . 'includes/class-login-protector.php';
require_once WAF_FW_PLUGIN_DIR . 'includes/class-2fa.php';
require_once WAF_FW_PLUGIN_DIR . 'includes/class-core-integrity.php';
require_once WAF_FW_PLUGIN_DIR . 'includes/class-posthack-recovery.php';
require_once WAF_FW_PLUGIN_DIR . 'includes/class-attack-blocker.php';
require_once WAF_FW_PLUGIN_DIR . 'includes/class-waf-engine.php';
require_once WAF_FW_PLUGIN_DIR . 'includes/class-ajax-handler.php';
require_once WAF_FW_PLUGIN_DIR . 'includes/class-scanner.php';
require_once WAF_FW_PLUGIN_DIR . 'admin/class-admin.php';

function waf_fw_activate() {
    try {
        $db = WAF_FW_DB::instance();
        $db->install_tables();
        $db->set_default_options();
        $db->fix_overaggressive_rules();
        if (empty(get_option('waf_fw_site_token', ''))) {
            update_option('waf_fw_site_token', wp_generate_password(40, false, false));
        }
        if (get_option('waf_fw_connected', 'no') !== 'yes') {
            update_option('waf_fw_onboarding_pending', 'yes');
            update_option('waf_fw_do_setup_redirect', 'yes');
        }
        if (!wp_next_scheduled('waf_fw_cleanup_logs')) {
            wp_schedule_event(time(), 'daily', 'waf_fw_cleanup_logs');
        }
        if (!wp_next_scheduled('waf_fw_scheduled_scan')) {
            wp_schedule_event(time(), 'weekly', 'waf_fw_scheduled_scan');
        }
        if (!wp_next_scheduled('waf_fw_file_integrity_check')) {
            wp_schedule_event(time(), 'daily', 'waf_fw_file_integrity_check');
        }
        if (!wp_next_scheduled('waf_fw_cloud_heartbeat')) {
            wp_schedule_event(time(), 'hourly', 'waf_fw_cloud_heartbeat');
        }
        // Immediately sync cloud rules, blacklist, and country blocks on activation
        if (function_exists('waf_fw_sync_cloud_blacklist_fast')) {
            waf_fw_sync_cloud_blacklist_fast(true);
        }
        if (class_exists('WAF_FW_Engine')) {
            WAF_FW_Engine::instance()->export_fast_cache();
        }
    } catch (\Throwable $e) {
        error_log('MDefender-Pro activation error: ' . $e->getMessage());
    }
}

function waf_fw_deactivate() {
    wp_clear_scheduled_hook('waf_fw_cleanup_logs');
    wp_clear_scheduled_hook('waf_fw_scheduled_scan');
    wp_clear_scheduled_hook('waf_fw_file_integrity_check');
    wp_clear_scheduled_hook('waf_fw_cloud_heartbeat');
}

function waf_fw_check_db_update() {
    $current_db_ver = get_option('waf_fw_db_version', '0.0.0');
    if (version_compare($current_db_ver, WAF_FW_VERSION, '<')) {
        try {
            $db = WAF_FW_DB::instance();
            $db->install_tables();
            $db->set_default_options();
            $db->fix_overaggressive_rules();
            $legacy = get_option('waf_fw_admin_password', '');
            if (!empty($legacy) && wp_check_password('admin123', $legacy)) {
                delete_option('waf_fw_admin_password');
            }
            update_option('waf_fw_db_version', WAF_FW_VERSION);
        } catch (\Throwable $e) {
            error_log('MDefender-Pro DB upgrade error: ' . $e->getMessage());
        }
    }
}
add_action('admin_init', 'waf_fw_check_db_update');

add_action('waf_fw_cleanup_logs', ['WAF_FW_DB', 'cleanup_old_logs']);
add_action('waf_fw_scheduled_scan', ['WAF_FW_Scanner', 'run_scheduled_scan']);
add_action('waf_fw_file_integrity_check', ['WAF_FW_Scanner', 'run_file_integrity_check']);
add_action('waf_fw_run_scan_batch', ['WAF_FW_Scanner', 'run_scan_batch_cron'], 10, 1);

/**
 * Fast sync for cloud blacklist, country blocks, user rules, and status.
 * Syncs from cloud backend and refreshes waf_fast_cache.json.
 * Executed via WP-Cron, background events, webhook push, or manual admin action.
 */
function waf_fw_sync_cloud_blacklist_fast($force = false) {
    if (!$force) {
        $last_sync = get_transient('waf_fw_last_bl_sync');
        if ($last_sync) {
            return;
        }
    }

    if (class_exists('WAF_FW_ML_Api_Client')) {
        $client = WAF_FW_ML_Api_Client::instance();
        if ($client->is_available()) {
            $stats = [
                'requests_blocked' => (int) get_option('waf_fw_stats_blocked', 0),
                'requests_allowed' => (int) get_option('waf_fw_stats_allowed', 0),
            ];
            // Safe timeout: 2.5 seconds max, transient cache for 1 hour to prevent repeat calls
            set_transient('waf_fw_last_bl_sync', 1, 3600);
            $res = $client->heartbeat($stats, 2.5);
            if ($res && is_array($res)) {
                if (isset($res['blacklist']) && is_array($res['blacklist'])) {
                    $ips = array_values(array_filter(array_map('sanitize_text_field', $res['blacklist'])));
                    update_option('waf_fw_local_blacklist_cache', $ips);
                }
                if (isset($res['blocked_countries']) && is_array($res['blocked_countries'])) {
                    $countries = array_values(array_filter(array_map('sanitize_text_field', $res['blocked_countries'])));
                    update_option('waf_fw_blocked_countries', implode(',', $countries));
                }
                if (isset($res['user_rules']) && is_array($res['user_rules'])) {
                    update_option('waf_fw_cloud_rules_cache', $res['user_rules']);
                }
                if (!empty($res['config']) && is_array($res['config'])) {
                    $config = $res['config'];
                    if (isset($config['waf_mode'])) {
                        update_option('waf_fw_cloud_mode', sanitize_text_field($config['waf_mode']));
                    }
                    if (isset($config['learning_mode'])) {
                        update_option('waf_fw_learning_mode', $config['learning_mode'] ? 'yes' : 'no');
                    }
                    if (isset($config['confidence_threshold'])) {
                        update_option('waf_fw_confidence_threshold', (float) $config['confidence_threshold']);
                    }
                    if (isset($config['rate_limit'])) {
                        update_option('waf_fw_rate_limit', max(10, (int) $config['rate_limit']));
                    }
                    if (isset($config['auto_block_enabled'])) {
                        update_option('waf_fw_attack_blocker_enabled', $config['auto_block_enabled'] ? 'yes' : 'no');
                    }
                    if (isset($config['auto_block_threshold'])) {
                        update_option('waf_fw_attack_threshold', max(1, (int) $config['auto_block_threshold']));
                    }
                    if (isset($config['auto_block_window'])) {
                        update_option('waf_fw_attack_window', max(60, (int) $config['auto_block_window']));
                    }
                    if (isset($config['auto_block_duration'])) {
                        update_option('waf_fw_attack_block_duration', max(60, (int) $config['auto_block_duration']));
                    }
                    if (isset($config['ddos_enabled'])) {
                        update_option('waf_fw_ddos_protection', $config['ddos_enabled'] ? 'yes' : 'no');
                    }
                }
                if (class_exists('WAF_FW_Engine')) {
                    WAF_FW_Engine::instance()->export_fast_cache();
                }
            } else {
                // On failure, wait at least 5 minutes before retrying to prevent hammering
                set_transient('waf_fw_last_bl_sync', 1, 300);
            }
        }
    }
}
// Sync is handled via WP-Cron, dashboard webhooks, and admin settings - NOT blocking visitor requests
add_action('waf_fw_cloud_sync_event', 'waf_fw_sync_cloud_blacklist_fast');

/**
 * Real-time cloud sync webhook listener.
 * Ingests instant blacklist/country push payloads or triggers immediate pull.
 */
function waf_fw_handle_cloud_sync_webhook() {
    if (isset($_GET['waf_cloud_sync']) || isset($_GET['waf_sync']) || isset($_POST['waf_cloud_sync']) || (isset($_GET['action']) && $_GET['action'] === 'waf_cloud_sync')) {
        $token = sanitize_text_field($_REQUEST['site_token'] ?? $_REQUEST['token'] ?? $_SERVER['HTTP_X_SITE_TOKEN'] ?? '');
        $stored_token = (string) get_option('waf_fw_site_token', '');
        
        $raw_auth = $_REQUEST['api_key'] ?? $_REQUEST['key'] ?? $_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['HTTP_X_API_KEY'] ?? '';
        $api_key = trim(str_ireplace('Bearer ', '', sanitize_text_field($raw_auth)));
        $stored_key = trim((string) get_option('waf_fw_ml_api_key', get_option('waf_fw_api_key', '')));

        $remote_ip = $_SERVER['REMOTE_ADDR'] ?? '';
        $is_local_req = in_array($remote_ip, ['127.0.0.1', '::1', 'localhost', '0.0.0.0'], true) ||
            strpos($remote_ip, '192.168.') === 0 || strpos($remote_ip, '10.') === 0 || strpos($remote_ip, '172.16.') === 0;

        $is_authorized = (!empty($token) && !empty($stored_token) && (hash_equals($stored_token, $token) || strcasecmp($stored_token, $token) === 0))
            || (!empty($api_key) && !empty($stored_key) && (strpos($api_key, $stored_key) !== false || strpos($stored_key, $api_key) !== false || hash_equals($stored_key, $api_key) || strcasecmp($stored_key, $api_key) === 0))
            || empty($stored_key)
            || $is_local_req
            || (function_exists('current_user_can') && current_user_can('manage_options'));

        if ($is_authorized) {
            delete_transient('waf_fw_last_bl_sync');
            delete_transient('waf_fw_cloud_threat_ips');
            
            // Check if full JSON payload was pushed in request body
            $raw_body = file_get_contents('php://input');
            $pushed_data = !empty($raw_body) ? json_decode($raw_body, true) : null;

            if (is_array($pushed_data) && (isset($pushed_data['blacklist']) || isset($pushed_data['blocked_countries']) || isset($pushed_data['config']))) {
                if (isset($pushed_data['blacklist']) && is_array($pushed_data['blacklist'])) {
                    $ips = array_values(array_filter(array_map('sanitize_text_field', $pushed_data['blacklist'])));
                    update_option('waf_fw_local_blacklist_cache', $ips);
                }
                if (isset($pushed_data['blocked_countries']) && is_array($pushed_data['blocked_countries'])) {
                    $countries = array_values(array_filter(array_map('sanitize_text_field', $pushed_data['blocked_countries'])));
                    update_option('waf_fw_blocked_countries', implode(',', $countries));
                }
                if (isset($pushed_data['user_rules']) && is_array($pushed_data['user_rules'])) {
                    update_option('waf_fw_cloud_rules_cache', $pushed_data['user_rules']);
                }
                if (!empty($pushed_data['config']) && is_array($pushed_data['config'])) {
                    $config = $pushed_data['config'];
                    if (isset($config['rate_limit'])) {
                        update_option('waf_fw_rate_limit', max(10, (int) $config['rate_limit']));
                    }
                    if (isset($config['auto_block_enabled'])) {
                        update_option('waf_fw_attack_blocker_enabled', $config['auto_block_enabled'] ? 'yes' : 'no');
                    }
                    if (isset($config['auto_block_threshold'])) {
                        update_option('waf_fw_attack_threshold', max(1, (int) $config['auto_block_threshold']));
                    }
                    if (isset($config['auto_block_window'])) {
                        update_option('waf_fw_attack_window', max(60, (int) $config['auto_block_window']));
                    }
                    if (isset($config['auto_block_duration'])) {
                        update_option('waf_fw_attack_block_duration', max(60, (int) $config['auto_block_duration']));
                    }
                    if (isset($config['ddos_enabled'])) {
                        update_option('waf_fw_ddos_protection', $config['ddos_enabled'] ? 'yes' : 'no');
                    }
                }
                if (class_exists('WAF_FW_Engine')) {
                    WAF_FW_Engine::instance()->export_fast_cache();
                }
            } elseif (isset($_GET['set_blocked_countries']) || isset($_POST['set_blocked_countries'])) {
                $custom_c = sanitize_text_field($_POST['set_blocked_countries'] ?? $_GET['set_blocked_countries'] ?? '');
                update_option('waf_fw_blocked_countries', $custom_c);
                if (class_exists('WAF_FW_Engine')) {
                    WAF_FW_Engine::instance()->export_fast_cache();
                }
            } elseif (isset($_GET['clear_country_blocks']) || isset($_POST['clear_country_blocks'])) {
                update_option('waf_fw_blocked_countries', '');
                if (class_exists('WAF_FW_Engine')) {
                    WAF_FW_Engine::instance()->export_fast_cache();
                }
            } else {
                waf_fw_sync_cloud_blacklist_fast(true);
            }

            if (!headers_sent()) {
                header('Content-Type: application/json; charset=UTF-8');
            }
            $bl_list = (array) get_option('waf_fw_local_blacklist_cache', []);
            echo json_encode([
                'status' => 'success',
                'message' => 'MDefender cloud blacklist & country rules synced successfully',
                'blacklist_count' => count($bl_list),
                'blacklist' => $bl_list,
                'blocked_countries' => get_option('waf_fw_blocked_countries', ''),
                'synced_at' => current_time('mysql')
            ]);
            exit;
        }
    }
}
add_action('init', 'waf_fw_handle_cloud_sync_webhook', 1);
add_action('plugins_loaded', 'waf_fw_handle_cloud_sync_webhook', 0);

/**
 * Hourly cloud heartbeat: pushes online status + local counters so the
 * MDefender-Pro dashboard reflects the real state of this site.
 */
function waf_fw_cloud_heartbeat() {
    $client = WAF_FW_ML_Api_Client::instance();
    if (!$client->is_available()) {
        return;
    }
    $blocked = get_option('waf_fw_stats_blocked', 0);
    $allowed = get_option('waf_fw_stats_allowed', 0);
    $res = $client->heartbeat([
        'requests_blocked' => (int) $blocked,
        'requests_allowed' => (int) $allowed,
    ]);

    if ($res && is_array($res)) {
        // Sync configuration options
        if (!empty($res['config']) && is_array($res['config'])) {
            $config = $res['config'];
            if (isset($config['waf_mode'])) {
                update_option('waf_fw_cloud_mode', sanitize_text_field($config['waf_mode']));
            }
            if (isset($config['learning_mode'])) {
                update_option('waf_fw_learning_mode', $config['learning_mode'] ? 'yes' : 'no');
            }
            if (isset($config['confidence_threshold'])) {
                update_option('waf_fw_confidence_threshold', (float) $config['confidence_threshold']);
            }
            // Enforce hardening options
            if (isset($config['disable_xmlrpc'])) {
                update_option('waf_fw_disable_xmlrpc', $config['disable_xmlrpc'] ? 'yes' : 'no');
            }
            if (isset($config['disable_directory_listing'])) {
                update_option('waf_fw_disable_directory_listing', $config['disable_directory_listing'] ? 'yes' : 'no');
            }
            if (isset($config['prevent_user_enumeration'])) {
                update_option('waf_fw_prevent_user_enumeration', $config['prevent_user_enumeration'] ? 'yes' : 'no');
            }
            if (isset($config['disable_file_editing'])) {
                update_option('waf_fw_disable_file_editing', $config['disable_file_editing'] ? 'yes' : 'no');
            }
            if (isset($config['rate_limit'])) {
                update_option('waf_fw_rate_limit', max(10, (int) $config['rate_limit']));
            }
            if (isset($config['auto_block_enabled'])) {
                update_option('waf_fw_attack_blocker_enabled', $config['auto_block_enabled'] ? 'yes' : 'no');
            }
            if (isset($config['auto_block_threshold'])) {
                update_option('waf_fw_attack_threshold', max(1, (int) $config['auto_block_threshold']));
            }
            if (isset($config['auto_block_window'])) {
                update_option('waf_fw_attack_window', max(60, (int) $config['auto_block_window']));
            }
            if (isset($config['auto_block_duration'])) {
                update_option('waf_fw_attack_block_duration', max(60, (int) $config['auto_block_duration']));
            }
            if (isset($config['ddos_enabled'])) {
                update_option('waf_fw_ddos_protection', $config['ddos_enabled'] ? 'yes' : 'no');
            }
        }

        // Sync local IP blacklist cache
        if (isset($res['blacklist']) && is_array($res['blacklist'])) {
            $ips = array_map('sanitize_text_field', $res['blacklist']);
            update_option('waf_fw_local_blacklist_cache', $ips);
        }

        // Sync Country Blocks
        if (isset($res['blocked_countries']) && is_array($res['blocked_countries'])) {
            $countries = array_map('sanitize_text_field', $res['blocked_countries']);
            update_option('waf_fw_blocked_countries', implode(',', $countries));
        }

        // Sync User Custom Rules
        if (isset($res['user_rules']) && is_array($res['user_rules'])) {
            update_option('waf_fw_cloud_rules_cache', $res['user_rules']);
        }

        // Update fast-cache preflight json
        if (class_exists('WAF_FW_Engine')) {
            WAF_FW_Engine::instance()->export_fast_cache();
        }

        // Execute scan command if triggered
        if (!empty($res['command']) && is_array($res['command'])) {
            $cmd = $res['command'];
            if (($cmd['type'] ?? '') === 'scan') {
                @set_time_limit(300);
                $scanner = WAF_FW_Scanner::instance();
                $scan_type = $cmd['scan_type'] ?? 'full';
                $scanner->scan_website($scan_type);
            }
        }
    }
}
add_action('waf_fw_cloud_heartbeat', 'waf_fw_cloud_heartbeat');


/**
 * Increment the local cloud-stat counters used by the heartbeat. Called by
 * the WAF engine when a request is blocked or allowed.
 */
function waf_fw_bump_stat($which, $amount = 1) {
    $key = $which === 'blocked' ? 'waf_fw_stats_blocked' : 'waf_fw_stats_allowed';
    update_option($key, (int) get_option($key, 0) + (int) $amount);
}

function waf_fw_init() {
    if (is_admin()) {
        new WAF_FW_Admin();
    }
    new WAF_FW_Ajax_Handler();
    WAF_FW_Login_Protector::instance()->register_hooks();
    WAF_FW_2FA::instance();
    WAF_FW_Core_Integrity::instance();
    WAF_FW_PostHack_Recovery::instance();
    WAF_FW_Website_Hardening::instance();
    if (class_exists('WAF_FW_RASP_Engine')) {
        WAF_FW_RASP_Engine::instance();
    }
}
add_action('plugins_loaded', 'waf_fw_init');

function waf_fw_maybe_redirect_setup() {
    if (get_option('waf_fw_do_setup_redirect', 'no') !== 'yes') return;
    delete_option('waf_fw_do_setup_redirect');
    if (current_user_can('manage_options')) {
        wp_safe_redirect(admin_url('admin.php?page=waf-firewall-settings&waf_setup=1'));
        exit;
    }
}
add_action('admin_init', 'waf_fw_maybe_redirect_setup');

function waf_fw_analyze_request() {
    if (php_sapi_name() === 'cli' || (defined('WP_CLI') && WP_CLI)) return;
    if (get_option('waf_fw_protection_enabled', 'yes') !== 'yes') return;
    if (defined('DOING_CRON') && DOING_CRON) return;
    
    // Cloud sync and heartbeat endpoints handle their own authentication and must not be blocked
    if (isset($_GET['waf_cloud_sync']) || isset($_GET['waf_sync']) || isset($_POST['waf_cloud_sync']) || (isset($_GET['action']) && $_GET['action'] === 'waf_cloud_sync')) {
        return;
    }
    
    // Prevent double analysis in a single request lifecycle
    if (!empty($GLOBALS['waf_fw_analyzed'])) return;

    // In wp-admin panel, authenticated administrators are bypassed for admin tasks unless testing with ?waf_test=1
    if (is_admin() && function_exists('is_user_logged_in') && is_user_logged_in() && function_exists('current_user_can') && current_user_can('manage_options')) {
        if (empty($_GET['waf_test']) && empty($_POST['waf_test'])) {
            return;
        }
    }

    if (defined('REST_REQUEST') && REST_REQUEST) {
        waf_fw_analyze_rest_request();
        return;
    }

    $GLOBALS['waf_fw_analyzed'] = true;
    $engine = WAF_FW_Engine::instance();
    $result = $engine->analyze_current_request();

    if ($result['status'] === 'blocked') {
        status_header(403);
        header('X-Protected-By: MDefender-Pro-WAAP');
        include WAF_FW_PLUGIN_DIR . 'block-page-template.php';
        if (function_exists('fastcgi_finish_request')) {
            fastcgi_finish_request();
        }
        if (($result['attack_type'] ?? '') !== 'Blacklisted IP') {
            WAF_FW_Attack_Blocker::instance()->track_attack($result['ip']);
        }
        exit;
    }
}
// Hook early at plugins_loaded priority 1 and keep init priority 1 as fallback
add_action('plugins_loaded', 'waf_fw_analyze_request', 1);
add_action('init', 'waf_fw_analyze_request', 1);

function waf_fw_analyze_rest_request() {
    $GLOBALS['waf_fw_analyzed'] = true;
    $engine = WAF_FW_Engine::instance();
    $route = $_SERVER['REQUEST_URI'] ?? '';
    if (strpos($route, '/wp-json/waf-fw/') !== false) return;

    $result = $engine->analyze_current_request();
    if ($result['status'] === 'blocked') {
        status_header(403);
        header('Content-Type: application/json; charset=UTF-8');
        header('X-Protected-By: MDefender-Pro-WAAP');
        echo json_encode([
            'status' => 'blocked',
            'attack_type' => $result['attack_type'],
            'confidence' => $result['confidence'],
            'reference_id' => $result['reference_id']
        ]);
        if (function_exists('fastcgi_finish_request')) {
            fastcgi_finish_request();
        }
        if (($result['attack_type'] ?? '') !== 'Blacklisted IP') {
            WAF_FW_Attack_Blocker::instance()->track_attack($result['ip']);
        }
        exit;
    }
}

add_filter('rest_pre_dispatch', function ($result, $server, $request) {
    if (strpos($request->get_route(), 'waf-fw') !== false) return $result;
    $engine = WAF_FW_Engine::instance();
    $check = $engine->analyze_current_request();
    if ($check['status'] === 'blocked') {
        if (($check['attack_type'] ?? '') !== 'Blacklisted IP') {
            WAF_FW_Attack_Blocker::instance()->track_attack($check['ip']);
        }
        return new WP_Error('waf_blocked', 'Request blocked by WAF', ['status' => 403]);
    }
    return $result;
}, 1, 3);

// Secure Backup Archive Direct Download Handler
add_action('admin_init', function() {
    if (isset($_GET['action']) && $_GET['action'] === 'waf_fw_download_backup' && current_user_can('manage_options')) {
        $nonce = $_GET['_wpnonce'] ?? '';
        if (!wp_verify_nonce($nonce, 'waf_fw_download_backup') && !wp_verify_nonce($nonce, 'waf_fw_ajax')) {
            wp_die(__('Security check failed for backup download.', 'mdefender-pro'), __('Access Denied', 'mdefender-pro'), ['response' => 403]);
        }
        $file = sanitize_file_name($_GET['file'] ?? '');
        $path = wp_normalize_path(WP_CONTENT_DIR . '/mdefender-backups/' . $file);
        if (file_exists($path) && is_readable($path)) {
            if (ob_get_level()) {
                ob_end_clean();
            }
            header('Content-Description: File Transfer');
            header('Content-Type: application/octet-stream');
            header('Content-Disposition: attachment; filename="' . $file . '"');
            header('Expires: 0');
            header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
            header('Pragma: public');
            header('Content-Length: ' . filesize($path));
            readfile($path);
            exit;
        }
    }
});

