<?php
defined('ABSPATH') || exit;

class WAF_FW_Login_Protector {
    private static $_instance = null;
    private $custom_login_slug = '';

    public static function instance() {
        if (null === self::$_instance) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    public function register_hooks() {
        if (!function_exists('waf_fw_is_cloud_active') || !waf_fw_is_cloud_active()) {
            return; // Login protector remains dormant without valid MDefender Pro Cloud API key
        }
        $slug = trim(get_option('waf_harden_login_rename', get_option('waf_custom_login_slug', '')));
        $hide_login_enabled = in_array(get_option('waf_harden_hide_login_url'), ['yes', '1', 1, true], true) 
                           || in_array(get_option('waf_hide_login_url'), ['yes', '1', 1, true], true)
                           || !empty($slug);

        if (!$hide_login_enabled || empty($slug) || in_array(strtolower($slug), ['wp-admin', 'wp-login.php', 'wp-login'])) {
            $slug = '';
        }
        $this->custom_login_slug = $slug;

        add_filter('authenticate', [$this, 'check_login_locked'], 30, 2);
        add_action('wp_login_failed', [$this, 'on_login_failed'], 10, 1);
        add_action('wp_login', [$this, 'on_login_success'], 10, 2);

        // Enforce Administrative & Login Portal IP Whitelist Restriction
        add_action('plugins_loaded', [$this, 'check_admin_ip_restriction'], 2);
        add_action('wp_loaded', [$this, 'check_admin_ip_restriction'], 2);

        if ($this->custom_login_slug) {
            // Stage 1: Detect secret slug early, normalize trailing slash, set $pagenow = 'wp-login.php'
            add_action('plugins_loaded', [$this, 'plugins_loaded_early_detect'], 1);

            // Stage 2: Serve login screen or block default routes once WordPress & all plugins are 100% loaded
            add_action('wp_loaded', [$this, 'wp_loaded_serve_custom_login'], 1);

            // Prevent WordPress core from doing canonical redirects from /admin or /dashboard to /wp-login.php
            remove_action('template_redirect', 'wp_redirect_admin_locations', 1000);

            add_filter('site_url', [$this, 'filter_site_url'], 10, 3);
            add_filter('network_site_url', [$this, 'filter_site_url'], 10, 3);
            add_filter('login_url', [$this, 'filter_login_url'], 10, 3);
            add_filter('logout_url', [$this, 'filter_logout_url'], 10, 2);
            add_filter('lostpassword_url', [$this, 'filter_lostpassword_url'], 10, 2);
            add_filter('register_url', [$this, 'filter_register_url'], 10, 2);
            add_filter('wp_redirect', [$this, 'filter_login_redirect'], 10, 2);
            add_action('wp_logout', [$this, 'on_logout_redirect']);
        }

        // Biometric 'Press & Hold' Defense for WordPress Admin Login
        $hold_press_active = (get_option('waf_hold_press_enabled', 'no') === 'yes');
        if ($hold_press_active) {
            add_action('login_form', [$this, 'render_hold_press_challenge'], 20);
            add_filter('authenticate', [$this, 'validate_login_challenge'], 10, 3);
        }
    }

    /**
     * Stage 1: Early detection on plugins_loaded.
     * Sets $pagenow = 'wp-login.php' and performs trailing slash redirection.
     */
    public function plugins_loaded_early_detect() {
        $slug = $this->custom_login_slug;
        if (!$slug) return;

        // Emergency admin bypass
        if (isset($_GET['mdefender_bypass']) || isset($_GET['mdefender_restore']) || isset($_GET['mdefender_reset']) || isset($_GET['waf_login_restore'])) {
            return;
        }

        $request_uri = $_SERVER['REQUEST_URI'] ?? '';
        $raw_path = parse_url($request_uri, PHP_URL_PATH) ?? '';
        
        $home_path = parse_url(home_url(), PHP_URL_PATH) ?: '';
        $path = $raw_path;
        if (!empty($home_path) && strpos($path, $home_path) === 0) {
            $path = substr($path, strlen($home_path));
        }
        $trimmed_path = trim($path, '/');

        // Check if incoming request matches the custom secret slug
        $is_matching_slug = ($trimmed_path === $slug || strpos($trimmed_path, $slug . '/') === 0 || $trimmed_path === 'index.php/' . $slug);
        if (!$is_matching_slug && (isset($_GET[$slug]) || (isset($_GET['login']) && $_GET['login'] === $slug))) {
            $is_matching_slug = true;
        }

        if ($is_matching_slug) {
            // Trailing slash redirect check:
            // If visitor accessed /mahabub without trailing slash, redirect cleanly to /mahabub/ with query params
            if ($trimmed_path === $slug && !str_ends_with($raw_path, '/') && !isset($_GET[$slug])) {
                $query = !empty($_SERVER['QUERY_STRING']) ? ('?' . $_SERVER['QUERY_STRING']) : '';
                wp_safe_redirect(home_url($slug . '/' . $query), 301);
                exit;
            }

            // Set global $pagenow early so all plugins and core functions know we are on wp-login.php
            global $pagenow;
            $pagenow = 'wp-login.php';
            $_SERVER['SCRIPT_NAME'] = '/wp-login.php';
            $_SERVER['PHP_SELF'] = '/wp-login.php';
        }
    }

    /**
     * Stage 2: Serve custom login page or intercept direct /wp-login.php & /wp-admin on wp_loaded.
     * Guaranteed to run after all plugins, themes, translations, and scripts are 100% initialized.
     */
    public function wp_loaded_serve_custom_login() {
        $slug = $this->custom_login_slug;
        if (!$slug) return;

        // Emergency admin bypass
        if (isset($_GET['mdefender_bypass']) || isset($_GET['mdefender_restore']) || isset($_GET['mdefender_reset']) || isset($_GET['waf_login_restore'])) {
            return;
        }

        global $pagenow;

        $request_uri = $_SERVER['REQUEST_URI'] ?? '';
        $raw_path = parse_url($request_uri, PHP_URL_PATH) ?? '';
        
        $home_path = parse_url(home_url(), PHP_URL_PATH) ?: '';
        $path = $raw_path;
        if (!empty($home_path) && strpos($path, $home_path) === 0) {
            $path = substr($path, strlen($home_path));
        }
        $trimmed_path = trim($path, '/');

        $is_matching_slug = ($pagenow === 'wp-login.php' && $trimmed_path !== 'wp-login.php')
                         || ($trimmed_path === $slug || strpos($trimmed_path, $slug . '/') === 0 || $trimmed_path === 'index.php/' . $slug)
                         || (isset($_GET[$slug]) || (isset($_GET['login']) && $_GET['login'] === $slug));

        // 1. Serving custom secret login URL
        if ($is_matching_slug) {
            // Check gateway lockout for custom login slug
            $client_ip = $this->get_client_ip();
            if ($this->is_gateway_locked($client_ip)) {
                $remaining_seconds = max(5, $this->get_gateway_remaining_seconds($client_ip));
                $cooldown_reason = "Too many failed login attempts detected. Access to the login portal is temporarily restricted for your account security. Public pages remain accessible.";
                $result = [
                    'ip' => $client_ip,
                    'attack_type' => 'Login Brute-Force Rate Limited',
                    'reference_id' => 'GW-' . strtoupper(substr(md5($client_ip . time()), 0, 8))
                ];
                $tpl = defined('WAF_FW_PLUGIN_DIR') ? (WAF_FW_PLUGIN_DIR . 'rate-limit-template.php') : (dirname(__DIR__) . '/rate-limit-template.php');
                if (file_exists($tpl)) {
                    include $tpl;
                    exit;
                }
            }

            // Set all required WordPress login globals
            global $error, $interim_login, $action, $user_login, $user_ID, $current_site, $wp_hasher;
            $pagenow = 'wp-login.php';
            $_SERVER['SCRIPT_NAME'] = '/wp-login.php';
            $_SERVER['PHP_SELF'] = '/wp-login.php';

            if (!defined('AUTOSAVE_INTERVAL')) {
                define('AUTOSAVE_INTERVAL', 60);
            }
            if (function_exists('wp_functionality_constants')) {
                wp_functionality_constants();
            }
            if (!defined('MDEFENDER_ALLOWED_LOGIN')) {
                define('MDEFENDER_ALLOWED_LOGIN', true);
            }

            $login_path = ABSPATH . 'wp-login.php';
            if (file_exists($login_path)) {
                status_header(200);
                try {
                    require_once $login_path;
                } catch (\Throwable $e) {
                    error_log('MDefender Login Gateway Notice: ' . $e->getMessage());
                }
                exit;
            }
        }

        // 2. Intercept direct access to default wp-login.php or unauthorized wp-admin
        $is_login_path = (strpos($raw_path, 'wp-login.php') !== false);
        $is_admin_path = ($trimmed_path === 'wp-admin' || strpos($trimmed_path, 'wp-admin/') === 0);

        $user_logged_in = false;
        if (function_exists('is_user_logged_in')) {
            $user_logged_in = is_user_logged_in();
        }

        if ($is_login_path || ($is_admin_path && !$user_logged_in)) {
            $is_ajax = (defined('DOING_AJAX') && DOING_AJAX) || (strpos($request_uri, 'admin-ajax.php') !== false);
            $is_cron = (defined('DOING_CRON') && DOING_CRON);
            $is_admin_post = (strpos($request_uri, 'admin-post.php') !== false);
            $is_allowed = (defined('MDEFENDER_ALLOWED_LOGIN') && MDEFENDER_ALLOWED_LOGIN);

            if (!$is_ajax && !$is_cron && !$is_admin_post && !$is_allowed) {
                $redirect_type = get_option('waf_harden_login_redirect_type', '404');
                if ($redirect_type === '404') {
                    status_header(404);
                    nocache_headers();
                    $this->render_fallback_404();
                    exit;
                } else {
                    wp_redirect(home_url(), 301);
                    exit;
                }
            }
        }
    }

    /**
     * Backward-compatible forwarder for any external hook or caller
     */
    public function handle_custom_login_url() {
        if (did_action('wp_loaded')) {
            $this->wp_loaded_serve_custom_login();
        } else {
            $this->plugins_loaded_early_detect();
        }
    }

    public function render_fallback_404() {
        $site_name = get_bloginfo('name') ?: 'Website';
        $home_url = home_url('/');
        ?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Page not found &#8211; <?php echo esc_html($site_name); ?></title>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
            background-color: #ffffff;
            color: #1a1a1a;
            line-height: 1.6;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        .wp-site-header {
            padding: 24px 40px;
            border-bottom: 1px solid #f1f5f9;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        .wp-site-title {
            font-size: 1.25rem;
            font-weight: 700;
            color: #0f172a;
            text-decoration: none;
            letter-spacing: -0.01em;
        }
        .wp-site-title:hover {
            color: #2563eb;
        }
        .wp-main-content {
            flex: 1;
            max-width: 720px;
            width: 100%;
            margin: 70px auto;
            padding: 0 24px;
            text-align: left;
        }
        .wp-error-title {
            font-size: 2.5rem;
            font-weight: 800;
            letter-spacing: -0.02em;
            color: #0f172a;
            margin-bottom: 16px;
            line-height: 1.2;
        }
        .wp-error-desc {
            font-size: 1.125rem;
            color: #475569;
            margin-bottom: 28px;
            line-height: 1.7;
        }
        .wp-search-form {
            display: flex;
            gap: 10px;
            margin-bottom: 36px;
            max-width: 520px;
        }
        .wp-search-input {
            flex: 1;
            padding: 12px 16px;
            border: 1px solid #cbd5e1;
            border-radius: 6px;
            font-size: 1rem;
            outline: none;
            transition: border-color 0.2s, box-shadow 0.2s;
        }
        .wp-search-input:focus {
            border-color: #0f172a;
            box-shadow: 0 0 0 3px rgba(15, 23, 42, 0.1);
        }
        .wp-search-btn {
            padding: 12px 24px;
            background: #0f172a;
            color: #ffffff;
            border: none;
            border-radius: 6px;
            font-size: 0.95rem;
            font-weight: 600;
            cursor: pointer;
            transition: background-color 0.2s;
        }
        .wp-search-btn:hover {
            background: #334155;
        }
        .wp-back-home {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            color: #2563eb;
            text-decoration: none;
            font-weight: 600;
            font-size: 1rem;
        }
        .wp-back-home:hover {
            text-decoration: underline;
        }
        .wp-site-footer {
            padding: 24px 40px;
            border-top: 1px solid #f1f5f9;
            font-size: 0.875rem;
            color: #94a3b8;
            text-align: center;
        }
        .wp-site-footer a {
            color: #64748b;
            text-decoration: none;
        }
        .wp-site-footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body class="error404 wp-theme-default">
    <header class="wp-site-header">
        <a href="<?php echo esc_url($home_url); ?>" class="wp-site-title"><?php echo esc_html($site_name); ?></a>
    </header>

    <main class="wp-main-content">
        <h1 class="wp-error-title">Page not found</h1>
        <p class="wp-error-desc">Oops! That page can&rsquo;t be found. It looks like nothing was found at this location. Maybe try a search?</p>

        <form role="search" method="get" class="wp-search-form" action="<?php echo esc_url($home_url); ?>">
            <input type="search" class="wp-search-input" placeholder="Search..." name="s" value="" required>
            <button type="submit" class="wp-search-btn">Search</button>
        </form>

        <p>
            <a href="<?php echo esc_url($home_url); ?>" class="wp-back-home">&larr; Return to Homepage</a>
        </p>
    </main>

    <footer class="wp-site-footer">
        <p>&copy; <?php echo date('Y'); ?> <a href="<?php echo esc_url($home_url); ?>"><?php echo esc_html($site_name); ?></a>. All rights reserved.</p>
    </footer>
</body>
</html>
        <?php
    }

    /**
     * Enforce strict IP whitelist restriction for administrative and login endpoints.
     */
    public function check_admin_ip_restriction() {
        $ip_protection_enabled = get_option('waf_harden_admin_ip_enabled', 'disabled') === 'enabled';
        if (!$ip_protection_enabled) {
            return;
        }

        $whitelist_raw = (string) get_option('waf_harden_admin_whitelist', '');
        $allowed_ips = array_values(array_filter(array_map('trim', explode("\n", $whitelist_raw))));
        if (empty($allowed_ips)) {
            return;
        }

        // Emergency admin bypass token check
        if (isset($_GET['mdefender_bypass']) || isset($_GET['mdefender_reset']) || isset($_GET['waf_login_restore'])) {
            return;
        }

        $request_uri = $_SERVER['REQUEST_URI'] ?? '';
        $raw_path = parse_url($request_uri, PHP_URL_PATH) ?? '';
        
        $home_path = parse_url(home_url(), PHP_URL_PATH) ?: '';
        $path = $raw_path;
        if (!empty($home_path) && strpos($path, $home_path) === 0) {
            $path = substr($path, strlen($home_path));
        }
        $trimmed_path = trim($path, '/');

        // Check if request is targeting login, wp-admin or custom secret gateway
        $is_login_path = (strpos($raw_path, 'wp-login.php') !== false);
        $is_admin_path = ($trimmed_path === 'wp-admin' || strpos($trimmed_path, 'wp-admin/') === 0);
        $slug = $this->custom_login_slug;
        $is_custom_slug = (!empty($slug) && ($trimmed_path === $slug || strpos($trimmed_path, $slug . '/') === 0));

        if (!$is_login_path && !$is_admin_path && !$is_custom_slug) {
            return;
        }

        // Allow public admin ajax, cron, rest, admin-post
        $is_ajax = (defined('DOING_AJAX') && DOING_AJAX) || (strpos($request_uri, 'admin-ajax.php') !== false);
        $is_cron = (defined('DOING_CRON') && DOING_CRON);
        $is_admin_post = (strpos($request_uri, 'admin-post.php') !== false);
        $is_rest = (defined('REST_REQUEST') && REST_REQUEST) || (strpos($request_uri, '/wp-json/') !== false);

        if ($is_ajax || $is_cron || $is_admin_post || $is_rest) {
            return;
        }

        // Avoid accidental lockout if whitelist only contains local loopback IPs on a public live site
        $server_host = strtolower($_SERVER['HTTP_HOST'] ?? '');
        $is_public_site = ($server_host !== 'localhost' && strpos($server_host, '127.0.0.1') === false && strpos($server_host, '::1') === false);
        $has_public_whitelist = false;
        foreach ($allowed_ips as $entry) {
            if (!in_array($entry, ['127.0.0.1', '::1', 'localhost'], true)) {
                $has_public_whitelist = true;
                break;
            }
        }
        if ($is_public_site && !$has_public_whitelist) {
            return;
        }

        $client_ip = $this->get_client_ip();

        // Check if client IP is authorized
        $is_allowed = false;
        foreach ($allowed_ips as $entry) {
            if ($this->ip_matches_entry($client_ip, $entry)) {
                $is_allowed = true;
                break;
            }
        }

        if (!$is_allowed) {
            // Allow unauthenticated visitors to reach login page rather than harsh 403 lockout
            if (function_exists('is_user_logged_in') && !is_user_logged_in() && $is_admin_path) {
                return;
            }
            status_header(403);
            nocache_headers();
            $this->render_admin_ip_blocked_screen($client_ip);
            exit;
        }
    }

    /**
     * Check whether an IP matches an allowed whitelist entry (single IP or CIDR block).
     */
    public function ip_matches_entry($client_ip, $allowed_entry) {
        $allowed_entry = trim($allowed_entry);
        if ($client_ip === $allowed_entry) {
            return true;
        }
        // Subnet CIDR match e.g. 192.168.1.0/24
        if (strpos($allowed_entry, '/') !== false) {
            $parts = explode('/', $allowed_entry, 2);
            $subnet = $parts[0];
            $bits = intval($parts[1]);
            if (filter_var($client_ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) && filter_var($subnet, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
                $ip_long = ip2long($client_ip);
                $subnet_long = ip2long($subnet);
                $mask = -1 << (32 - $bits);
                $subnet_long &= $mask;
                return ($ip_long & $mask) == $subnet_long;
            }
        }
        return false;
    }

    /**
     * Renders high-security professional block screen for unauthorized IP attempting admin access.
     */
    public function render_admin_ip_blocked_screen($client_ip) {
        $site_name = get_bloginfo('name') ?: 'WordPress';
        $ref_id = 'AIP-' . strtoupper(substr(md5($client_ip . time()), 0, 8));
        ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noindex, nofollow, noarchive, nosnippet">
    <title>403 Forbidden - Admin Gateway Restricted</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            background-color: #0b0f19;
            color: #f8fafc;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            padding: 20px;
        }
        .mdf-card {
            background: #111827;
            border: 1px solid #1f2937;
            border-radius: 14px;
            max-width: 560px;
            width: 100%;
            padding: 36px 32px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.4);
            text-align: left;
        }
        .mdf-badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            background: rgba(15, 23, 42, 0.8);
            border: 1px solid #374151;
            color: #94a3b8;
            font-size: 11px;
            font-weight: 700;
            letter-spacing: 0.5px;
            padding: 4px 10px;
            border-radius: 6px;
            margin-bottom: 20px;
            text-transform: uppercase;
        }
        .mdf-title {
            font-size: 20px;
            font-weight: 700;
            color: #ffffff;
            margin-bottom: 12px;
        }
        .mdf-desc {
            font-size: 13.5px;
            color: #9ca3af;
            line-height: 1.6;
            margin-bottom: 24px;
        }
        .mdf-meta-box {
            background: #0b0f19;
            border: 1px solid #1f2937;
            border-radius: 8px;
            padding: 14px 16px;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 12px;
            margin-bottom: 24px;
        }
        .mdf-meta-label {
            font-size: 11px;
            font-weight: 700;
            color: #6b7280;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 4px;
        }
        .mdf-meta-value {
            font-size: 13px;
            font-family: monospace;
            font-weight: 700;
            color: #f3f4f6;
        }
        .mdf-footer {
            display: flex;
            align-items: center;
            justify-content: space-between;
            font-size: 12px;
            color: #6b7280;
            padding-top: 16px;
            border-top: 1px solid #1f2937;
        }
        .mdf-footer a {
            color: #94a3b8;
            text-decoration: none;
            font-weight: 600;
        }
        .mdf-footer a:hover {
            color: #ffffff;
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="mdf-card">
        <div class="mdf-badge">
            <span>&#9679; Security Gateway Policy</span>
        </div>
        <h1 class="mdf-title">Administrative Gateway Restricted</h1>
        <p class="mdf-desc">
            Access to the administration portal and login gateway for <strong><?php echo esc_html($site_name); ?></strong> is restricted strictly to authorized IP addresses. Your IP address does not match any authorized administrative whitelist rule.
        </p>

        <div class="mdf-meta-box">
            <div>
                <div class="mdf-meta-label">Your Client IP</div>
                <div class="mdf-meta-value"><?php echo esc_html($client_ip); ?></div>
            </div>
            <div>
                <div class="mdf-meta-label">Incident Reference</div>
                <div class="mdf-meta-value"><?php echo esc_html($ref_id); ?></div>
            </div>
        </div>

        <div class="mdf-footer">
            <span>Protected by MDefender-Pro AI</span>
            <a href="<?php echo esc_url(home_url('/')); ?>">&larr; Return to Website</a>
        </div>
    </div>
</body>
</html>
        <?php
    }

    public function filter_site_url($url, $path = '', $scheme = null) {
        if (empty($this->custom_login_slug)) return $url;
        if ($path && strpos($path, 'wp-login.php') !== false) {
            if (is_admin() && !wp_doing_ajax()) return $url;
            $query = strpos($path, '?') !== false ? strstr($path, '?') : '';
            return home_url($this->custom_login_slug . '/' . $query, $scheme);
        }
        return $url;
    }

    public function filter_login_url($url, $redirect = '', $force_reauth = false) {
        if (empty($this->custom_login_slug)) return $url;
        $args = [];
        if (!empty($redirect)) $args['redirect_to'] = urlencode($redirect);
        if ($force_reauth) $args['reauth'] = '1';
        return add_query_arg($args, home_url($this->custom_login_slug . '/'));
    }

    public function filter_logout_url($url, $redirect = '') {
        if (empty($this->custom_login_slug)) return $url;
        $args = ['action' => 'logout'];
        if (!empty($redirect)) $args['redirect_to'] = urlencode($redirect);
        $args['_wpnonce'] = wp_create_nonce('log-out');
        return add_query_arg($args, home_url($this->custom_login_slug . '/'));
    }

    public function filter_lostpassword_url($url, $redirect = '') {
        if (empty($this->custom_login_slug)) return $url;
        $args = ['action' => 'lostpassword'];
        if (!empty($redirect)) $args['redirect_to'] = urlencode($redirect);
        return add_query_arg($args, home_url($this->custom_login_slug . '/'));
    }

    public function filter_register_url($url) {
        if (empty($this->custom_login_slug)) return $url;
        return add_query_arg(['action' => 'register'], home_url($this->custom_login_slug . '/'));
    }

    public function filter_login_redirect($location, $status) {
        if (empty($this->custom_login_slug)) return $location;
        if (strpos($location, 'wp-login.php') !== false) {
            $location = str_replace('wp-login.php', $this->custom_login_slug, $location);
        }
        return $location;
    }

    public function on_logout_redirect() {
        if ($this->custom_login_slug) {
            wp_redirect(home_url($this->custom_login_slug));
            exit;
        }
    }

    /* =====================================================================
       MDEFENDER PRO ADVANCED BOT DEFENSE & BIOMETRIC VERIFICATION
       ===================================================================== */

    /**
     * MDefender Pro Unbypassable Biometric 'Press & Hold' Challenge
     */
    public function render_hold_press_challenge() {
        $client_ip = $this->get_client_ip();
        $render_time = time();
        $seed_nonce = bin2hex(random_bytes(16));
        $duration_ms = intval(get_option('waf_hold_press_duration_ms', 2000));
        if ($duration_ms < 1000 || $duration_ms > 5000) $duration_ms = 2000;

        $secret = wp_salt('nonce') . '|mdefender_biometric_salt';
        $payload = "{$client_ip}|{$render_time}|{$seed_nonce}|{$duration_ms}";
        $sig = hash_hmac('sha256', $payload, $secret);
        $token = base64_encode("{$payload}|{$sig}");

        // Store active seed in transient with 300s expiration
        set_transient("mdf_hp_{$seed_nonce}", $client_ip, 300);
        ?>
        <div class="mdf-hold-press-wrapper" style="margin: 16px 0 18px 0; user-select: none;">
            <button type="button" id="mdfHoldButton" style="width: 100%; height: 48px; position: relative; overflow: hidden; border: 1.5px solid #CBD5E1; background: #FFFFFF; color: #0F172A; font-weight: 700; font-size: 13.5px; border-radius: 9px; cursor: pointer; transition: all 0.2s ease; outline: none; box-shadow: 0 1px 3px rgba(0,0,0,0.04); display: flex; align-items: center; justify-content: center;">
                <span id="mdfHoldProgress" style="position: absolute; left: 0; top: 0; bottom: 0; width: 0%; background: linear-gradient(90deg, #0B2522, #184841); opacity: 0.95; transition: width 0.04s linear; pointer-events: none;"></span>
                <span id="mdfHoldText" style="position: relative; z-index: 2; display: flex; align-items: center; justify-content: center; gap: 8px; pointer-events: none;">
                    <svg id="mdfIconFp" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#0B2522" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M12 2a10 10 0 0 0-10 10c0 3.2 1.5 6 3.8 7.8"/>
                        <path d="M12 6a6 6 0 0 0-6 6c0 1.8.8 3.5 2.1 4.6"/>
                        <path d="M12 10a2 2 0 0 0-2 2c0 .6.3 1.2.7 1.6"/>
                        <path d="M12 14v4"/>
                        <path d="M12 18v2"/>
                    </svg>
                    <span id="mdfLabel" style="font-weight: 700; font-size: 13.5px; color: #0F172A;">Press &amp; Hold to Verify</span>
                </span>
            </button>
            <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 6px; padding: 0 4px;">
                <span style="font-size: 11px; color: #64748B; font-weight: 600;">Biometric Proof-of-Work</span>
                <span id="mdfHoldStatus" style="font-size: 11px; font-weight: 700; color: #0B2522;">Hold 2s</span>
            </div>
            <input type="hidden" name="waf_hold_press_token" id="mdfHoldToken" value="<?php echo esc_attr($token); ?>" />
            <input type="hidden" name="waf_hold_press_proof" id="mdfHoldProof" value="" />
            <script>
            (function(){
                var btn = document.getElementById('mdfHoldButton');
                var prog = document.getElementById('mdfHoldProgress');
                var label = document.getElementById('mdfLabel');
                var iconFp = document.getElementById('mdfIconFp');
                var pField = document.getElementById('mdfHoldProof');
                var stat = document.getElementById('mdfHoldStatus');
                var holdTimer = null;
                var startTime = 0;
                var duration = <?php echo intval($duration_ms); ?>;
                var isVerified = false;
                var jitterCount = 0;

                function onMove() { jitterCount++; }
                window.addEventListener('mousemove', onMove);
                window.addEventListener('touchmove', onMove);

                function startHold(e) {
                    if (isVerified) return;
                    e.preventDefault();
                    startTime = Date.now();
                    btn.style.borderColor = '#0B2522';
                    btn.style.boxShadow = '0 0 0 3px rgba(11, 37, 34, 0.15)';
                    label.style.color = '#FFFFFF';
                    holdTimer = setInterval(function() {
                        var elapsed = Date.now() - startTime;
                        var pct = Math.min(100, (elapsed / duration) * 100);
                        prog.style.width = pct + '%';
                        if (elapsed >= duration) {
                            clearInterval(holdTimer);
                            isVerified = true;
                            pField.value = btoa(elapsed + '|' + jitterCount);
                            prog.style.background = '#0B2522';
                            prog.style.width = '100%';
                            btn.style.borderColor = '#0B2522';
                            btn.style.background = '#0B2522';
                            btn.style.cursor = 'default';
                            label.innerText = 'Verified Human';
                            label.style.color = '#FFFFFF';
                            iconFp.outerHTML = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#E8792F" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>';
                            stat.innerText = '✓ Verified';
                            stat.style.color = '#0B2522';
                        }
                    }, 25);
                }

                function stopHold() {
                    if (isVerified) return;
                    clearInterval(holdTimer);
                    prog.style.width = '0%';
                    btn.style.borderColor = '#CBD5E1';
                    btn.style.boxShadow = '0 1px 3px rgba(0,0,0,0.04)';
                    label.style.color = '#0F172A';
                }

                btn.addEventListener('mousedown', startHold);
                btn.addEventListener('mouseup', stopHold);
                btn.addEventListener('mouseleave', stopHold);
                btn.addEventListener('touchstart', startHold);
                btn.addEventListener('touchend', stopHold);
            })();
            </script>
        </div>
        <?php
    }

    /**
     * MDefender Pro Unbypassable Biometric 'Press & Hold' Challenge Pre-Validation
     * Hooks into 'authenticate' filter (priority 10) to block automated brute-force scripts before credentials check
     */
    public function validate_login_challenge($user, $username, $password) {
        if (defined('DOING_CRON') && DOING_CRON) return $user;
        if (defined('XMLRPC_REQUEST') && XMLRPC_REQUEST) {
            $hold_press_enabled = get_option('waf_hold_press_enabled', 'no') === 'yes';
            if ($hold_press_enabled) {
                return new WP_Error('waf_hold_xmlrpc_denied', '<strong>Security Verification Required:</strong> Biometric verification is enforced on this site. Direct XML-RPC login is denied.');
            }
            return $user;
        }
        if (empty($_POST) || !isset($_POST['log'])) {
            return $user;
        }
        if (is_wp_error($user)) return $user;

        $hold_press_enabled = get_option('waf_hold_press_enabled', 'no') === 'yes';
        if ($hold_press_enabled) {
            $token_raw = sanitize_text_field($_POST['waf_hold_press_token'] ?? '');
            $proof_raw = sanitize_text_field($_POST['waf_hold_press_proof'] ?? '');

            if (empty($token_raw) || empty($proof_raw)) {
                remove_filter('authenticate', 'wp_authenticate_username_password', 20);
                remove_filter('authenticate', 'wp_authenticate_email_password', 20);
                return new WP_Error('waf_hold_fail', '<strong>Bot Verification Required:</strong> Please press and hold the security button to authenticate as a human.');
            }

            // Verify physical hold duration proof
            $proof_decoded = base64_decode($proof_raw);
            if ($proof_decoded && strpos($proof_decoded, '|') !== false) {
                list($proof_elapsed, $proof_jitter) = explode('|', $proof_decoded);
                $min_allowed_ms = intval(get_option('waf_hold_press_duration_ms', 2000)) * 0.9;
                if (intval($proof_elapsed) < $min_allowed_ms) {
                    remove_filter('authenticate', 'wp_authenticate_username_password', 20);
                    remove_filter('authenticate', 'wp_authenticate_email_password', 20);
                    return new WP_Error('waf_hold_fail', '<strong>Bot Detected:</strong> Biometric physical hold duration insufficient.');
                }
            }

            $decoded = base64_decode($token_raw);
            if (!$decoded) {
                remove_filter('authenticate', 'wp_authenticate_username_password', 20);
                remove_filter('authenticate', 'wp_authenticate_email_password', 20);
                return new WP_Error('waf_hold_fail', '<strong>Security Verification Failed:</strong> Malformed token.');
            }

            $parts = explode('|', $decoded);
            if (count($parts) !== 5) {
                remove_filter('authenticate', 'wp_authenticate_username_password', 20);
                remove_filter('authenticate', 'wp_authenticate_email_password', 20);
                return new WP_Error('waf_hold_fail', '<strong>Security Verification Failed:</strong> Invalid token structure.');
            }

            list($tok_ip, $render_time, $seed_nonce, $dur_str, $tok_sig) = $parts;
            $client_ip = $this->get_client_ip();

            // Verify HMAC signature
            $secret = wp_salt('nonce') . '|mdefender_biometric_salt';
            $expected_sig = hash_hmac('sha256', "{$tok_ip}|{$render_time}|{$seed_nonce}|{$dur_str}", $secret);
            if (!hash_equals($expected_sig, $tok_sig)) {
                return new WP_Error('waf_hold_fail', '<strong>Security Verification Failed:</strong> Tampered signature.');
            }

            // Check IP match (anti-token-hijacking)
            if ($client_ip !== $tok_ip && $tok_ip !== '127.0.0.1' && $client_ip !== '127.0.0.1' && $client_ip !== '::1') {
                return new WP_Error('waf_hold_fail', '<strong>Security Verification Failed:</strong> Network mismatch.');
            }

            // Replay Attack check & Token Burn
            $transient_key = "mdf_hp_{$seed_nonce}";
            $saved_ip = get_transient($transient_key);
            if (!$saved_ip) {
                return new WP_Error('waf_hold_fail', '<strong>Security Verification Expired:</strong> Challenge token already used or expired. Please reload.');
            }
            delete_transient($transient_key); // BURN TOKEN IMMEDIATELY!

            // Human Timing check: Form submit cannot be faster than the required hold time
            $elapsed_since_render = time() - intval($render_time);
            $required_seconds = max(1, floor(intval($dur_str) / 1000));
            if ($elapsed_since_render < $required_seconds) {
                return new WP_Error('waf_hold_fail', '<strong>Bot Detected:</strong> Automated submission was too fast.');
            }

            return $user; // Biometric Passed!
        }

        return $user;
    }

    /* =====================================================================
       BRUTE FORCE THRESHOLDS & TEMPORARY LOCKOUTS
       ===================================================================== */

    public function check_login_locked($user, $username) {
        if (empty($username)) return $user;

        $enabled = get_option('waf_fw_login_lockout_enabled', 'yes');
        if ($enabled !== 'yes') return $user;

        $ip = $this->get_client_ip();
        if (WAF_FW_IP_Filter::instance()->is_whitelisted($ip)) return $user;

        if ($this->is_gateway_locked($ip) || $this->is_login_locked($ip)) {
            $remaining = max($this->get_gateway_remaining_seconds($ip), $this->get_remaining_block_time($ip));
            $remaining_seconds = max(5, $remaining);
            $cooldown_reason = "Too many failed login attempts detected. Access to the login portal is temporarily restricted for your account security. Public pages remain accessible.";
            $client_ip = $ip;
            $result = [
                'ip' => $ip,
                'attack_type' => 'Login Brute-Force Rate Limited',
                'reference_id' => 'GW-' . strtoupper(substr(md5($ip . time()), 0, 8))
            ];
            $tpl = defined('WAF_FW_PLUGIN_DIR') ? (WAF_FW_PLUGIN_DIR . 'rate-limit-template.php') : (dirname(__DIR__) . '/rate-limit-template.php');
            if (file_exists($tpl)) {
                include $tpl;
                exit;
            }
            $minutes = ceil($remaining / 60);
            return new WP_Error(
                'waf_login_locked',
                sprintf(
                    'Too many failed login attempts from your IP. Please try again in approximately %d minute(s).',
                    $minutes
                )
            );
        }

        return $user;
    }

    public function on_login_failed($username) {
        $ip = $this->get_client_ip();

        // Log failed login attempt to Live Admin Attack Stream!
        WAF_FW_Logger::instance()->log_attack([
            'ip' => $ip,
            'url' => $_SERVER['REQUEST_URI'] ?? '/wp-login.php',
            'method' => $_SERVER['REQUEST_METHOD'] ?? 'POST',
            'attack_type' => 'Failed Login (User: ' . sanitize_text_field($username) . ')',
            'status' => 'blocked',
            'rule_matched' => 'Brute Force Login Protection',
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
            'details' => ['username' => $username, 'event' => 'login_failed']
        ]);

        $enabled = get_option('waf_fw_login_lockout_enabled', 'yes');
        if ($enabled !== 'yes') return;

        if (WAF_FW_IP_Filter::instance()->is_whitelisted($ip)) return;

        $this->increment_attempts($ip);

        $attempts = $this->get_attempts($ip);
        $threshold = $this->get_brute_force_threshold();

        if ($attempts >= $threshold) {
            $this->auto_block_ip($ip);
        }
    }

    public function on_login_success($user_login, $user) {
        $ip = $this->get_client_ip();
        $this->clear_attempts($ip);
        $this->clear_gateway_lockout($ip);

        // Request is already captured once by the WAF engine upon request ingress.
    }

    public function get_attempts($ip) {
        global $wpdb;
        $table = WAF_FW_DB::instance()->get_login_attempts_table();
        $row = $wpdb->get_row($wpdb->prepare(
            "SELECT attempts FROM $table WHERE ip = %s",
            $ip
        ));
        return $row ? (int) $row->attempts : 0;
    }

    public function increment_attempts($ip) {
        global $wpdb;
        $table = WAF_FW_DB::instance()->get_login_attempts_table();
        $now = current_time('mysql');

        $exists = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $table WHERE ip = %s",
            $ip
        ));

        if ($exists) {
            $wpdb->query($wpdb->prepare(
                "UPDATE $table SET attempts = attempts + 1, last_attempt = %s WHERE ip = %s",
                $now,
                $ip
            ));
        } else {
            $wpdb->insert($table, [
                'ip' => $ip,
                'attempts' => 1,
                'first_attempt' => $now,
                'last_attempt' => $now,
            ]);
        }
    }

    public function clear_attempts($ip) {
        global $wpdb;
        $table = WAF_FW_DB::instance()->get_login_attempts_table();
        $wpdb->delete($table, ['ip' => $ip]);
    }

    public function is_login_locked($ip) {
        global $wpdb;
        $table = WAF_FW_DB::instance()->get_blacklist_table();
        $row = $wpdb->get_row($wpdb->prepare(
            "SELECT block_expires_at FROM $table WHERE ip = %s AND type = 'temporary' AND block_expires_at IS NOT NULL",
            $ip
        ));
        if (!$row) return false;

        if (strtotime($row->block_expires_at) <= current_time('timestamp')) {
            $wpdb->delete($table, ['ip' => $ip]);
            return false;
        }
        return true;
    }

    public function get_remaining_block_time($ip) {
        global $wpdb;
        $table = WAF_FW_DB::instance()->get_blacklist_table();
        $row = $wpdb->get_row($wpdb->prepare(
            "SELECT block_expires_at FROM $table WHERE ip = %s AND block_expires_at IS NOT NULL",
            $ip
        ));
        if (!$row) return 0;

        $expires = strtotime($row->block_expires_at);
        $now = current_time('timestamp');
        return max(0, $expires - $now);
    }

    public function auto_block_ip($ip) {
        $duration = $this->get_lockout_duration();
        $threshold = $this->get_brute_force_threshold();
        $scope = get_option('waf_fw_login_lockout_scope', 'gateway_only');
        $reason = sprintf('Auto-blocked after %d failed login attempts (Brute-Force Shield)', $threshold);

        if ($scope === 'gateway_only') {
            $lock_duration = $duration > 0 ? $duration : (86400 * 365);
            $this->add_gateway_lockout($ip, $lock_duration, $reason);
        } else {
            // Global blacklist across entire fleet
            if ($duration <= 0) {
                WAF_FW_IP_Filter::instance()->add_permanent_block($ip, $reason);
            } else {
                WAF_FW_IP_Filter::instance()->add_temporary_block($ip, $reason, $duration);
            }
        }
    }

    public function add_gateway_lockout($ip, $duration_seconds = 3600, $reason = '') {
        $duration_seconds = max(60, intval($duration_seconds));
        $expires_at = time() + $duration_seconds;
        $key = 'waf_gw_lock_' . md5($ip);
        if (function_exists('set_transient')) {
            set_transient($key, $expires_at, $duration_seconds);
        }
        $locks = get_option('waf_fw_gateway_locked_ips', []);
        if (!is_array($locks)) $locks = [];
        $locks[$ip] = [
            'expires_at' => $expires_at,
            'reason' => $reason,
            'locked_at' => time()
        ];
        // Prune expired
        $now = time();
        foreach ($locks as $k => $v) {
            if (!empty($v['expires_at']) && $v['expires_at'] < $now) {
                unset($locks[$k]);
            }
        }
        update_option('waf_fw_gateway_locked_ips', $locks);
    }

    public function is_gateway_locked($ip) {
        if (empty($ip)) return false;
        if (class_exists('WAF_FW_IP_Filter') && WAF_FW_IP_Filter::instance()->is_whitelisted($ip)) {
            return false;
        }

        $key = 'waf_gw_lock_' . md5($ip);
        if (function_exists('get_transient')) {
            $exp = get_transient($key);
            if ($exp !== false && intval($exp) > time()) {
                return true;
            }
        }

        $locks = get_option('waf_fw_gateway_locked_ips', []);
        if (is_array($locks) && isset($locks[$ip])) {
            $exp = intval($locks[$ip]['expires_at'] ?? 0);
            if ($exp > time()) {
                return true;
            } else {
                unset($locks[$ip]);
                update_option('waf_fw_gateway_locked_ips', $locks);
            }
        }
        return false;
    }

    public function get_gateway_remaining_seconds($ip) {
        $key = 'waf_gw_lock_' . md5($ip);
        if (function_exists('get_transient')) {
            $exp = get_transient($key);
            if ($exp !== false && intval($exp) > time()) {
                return intval($exp) - time();
            }
        }
        $locks = get_option('waf_fw_gateway_locked_ips', []);
        if (is_array($locks) && isset($locks[$ip])) {
            $exp = intval($locks[$ip]['expires_at'] ?? 0);
            return max(0, $exp - time());
        }
        return 0;
    }

    public function clear_gateway_lockout($ip) {
        $key = 'waf_gw_lock_' . md5($ip);
        if (function_exists('delete_transient')) {
            delete_transient($key);
        }
        $locks = get_option('waf_fw_gateway_locked_ips', []);
        if (is_array($locks) && isset($locks[$ip])) {
            unset($locks[$ip]);
            update_option('waf_fw_gateway_locked_ips', $locks);
        }
    }

    public function get_blocked_login_count() {
        global $wpdb;
        $table = WAF_FW_DB::instance()->get_blacklist_table();
        $bl_count = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM $table WHERE type = 'temporary' AND (block_expires_at IS NULL OR block_expires_at > NOW())"
        );
        $locks = get_option('waf_fw_gateway_locked_ips', []);
        $gw_count = is_array($locks) ? count($locks) : 0;
        return $bl_count + $gw_count;
    }

    private function get_brute_force_threshold() {
        $synced = get_option('waf_fw_login_lockout_threshold', '');
        if ($synced !== '') return max(1, (int) $synced);
        $harden = get_option('waf_harden_brute_force_threshold', '');
        return $harden !== '' ? (int) $harden : (int) get_option('waf_fw_login_threshold', 5);
    }

    private function get_lockout_duration() {
        $synced_mins = get_option('waf_fw_login_lockout_duration', '');
        if ($synced_mins !== '') {
            $mins = (int) $synced_mins;
            return $mins > 0 ? ($mins * 60) : 0; // 0 means permanent
        }
        $harden = get_option('waf_harden_login_lockout_time', '');
        return $harden !== '' ? (int) $harden : (int) get_option('waf_fw_login_block_duration', 3600);
    }

    private function get_client_ip() {
        if (!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) {
            return trim($_SERVER['HTTP_CF_CONNECTING_IP']);
        }
        if (!empty($_SERVER['HTTP_X_REAL_IP'])) {
            return trim($_SERVER['HTTP_X_REAL_IP']);
        }
        if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ips = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
            return trim($ips[0]);
        }
        return trim($_SERVER['REMOTE_ADDR'] ?? '127.0.0.1');
    }
}
