<?php
defined('ABSPATH') || exit('Access Denied');

/**
 * MDefender-Pro Semantic Payload Deobfuscator & Lexical Tokenizer
 *
 * Implements:
 * 1. Recursive multi-pass payload de-obfuscation (defeats nested encoding, unicode tricks, hex/base64 mutations).
 * 2. SQL Comment and whitespace normalization (strips inline comments like /*!50000SELECT*\/, null bytes).
 * 3. Libinjection-style SQLi & XSS grammatical tokenization (intent-based structural syntax analysis).
 * 4. AI Prompt Injection & LLM Jailbreak string detection.
 *
 * @package MDefender-Pro
 */

defined('ABSPATH') || exit;

class WAF_FW_Semantic_Deobfuscator {
    private static $_instance = null;

    public static function instance() {
        if (null === self::$_instance) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    /**
     * Recursively de-obfuscate a payload string across multiple passes.
     *
     * @param string $input Raw or encoded input string
     * @param int $max_depth Maximum recursion depth (prevents ReDoS/memory exhaustion)
     * @return string Canonical normalized string
     */
    public function deobfuscate($input, $max_depth = 4) {
        if (!is_string($input) || $input === '') {
            return '';
        }

        // FAST-PATH: If string contains no encoded or escaped characters, return normalized whitespace instantly (< 0.001ms)
        if (strpbrk($input, "%&\\/*\0\xc0\xc1\xe0\xf0\xa0") === false) {
            return trim(preg_replace('/\s+/', ' ', $input));
        }

        $current = $input;
        $depth = 0;

        while ($depth < $max_depth) {
            $previous = $current;

            // 0. Canonicalize overlong UTF-8 and non-standard Unicode path traversal representations
            $slash_patterns = [
                '%c0%af', '%c0%2f', '%c1%8f', '%c1%af', '%e0%80%af', '%e0%80%2f', '%f0%80%80%af',
                '%u002f', '%u2215', '%uff0f', '%uefc8', '%u2044',
                "\xc0\xaf", "\xc0\x2f", "\xc1\x8f", "\xc1\xaf", "\xe0\x80\xaf",
                '%2f', '%2F'
            ];
            $current = str_ireplace($slash_patterns, '/', $current);

            $backslash_patterns = [
                '%c0%5c', '%c0%9c', '%c1%9c', '%c1%bc', '%e0%80%5c', '%e0%81%9c', '%f0%80%80%5c',
                '%u005c', '%u2216', '%uff3c',
                "\xc0\x5c", "\xc0\x9c", "\xc1\x9c", "\xc1\xbc", "\xe0\x80\x5c",
                '%5c', '%5C'
            ];
            $current = str_ireplace($backslash_patterns, '\\', $current);

            $dot_patterns = [
                '%c0%ae', '%c0%2e', '%c1%8e', '%c1%ae', '%e0%80%ae', '%e0%80%2e', '%f0%80%80%ae',
                '%u002e', '%uff0e',
                "\xc0\xae", "\xc0\x2e", "\xc1\x8e", "\xc1\xae", "\xe0\x80\xae",
                '%2e', '%2E'
            ];
            $current = str_ireplace($dot_patterns, '.', $current);

            // Regex-based overlong UTF-8 canonicalization for high-byte bypasses
            $current = preg_replace('/(?:\xc0[\xaf\x2f]|\xc1[\x8f\xaf]|\xe0\x80[\xaf\x2f])/i', '/', $current);
            $current = preg_replace('/(?:\xc0[\x5c\x9c]|\xc1[\x9c\xbc]|\xe0\x80\x5c)/i', '\\', $current);
            $current = preg_replace('/(?:\xc0[\xae\x2e]|\xc1[\x8e\xae]|\xe0\x80[\xae\x2e])/i', '.', $current);

            // 1. Recursive URL decoding (handles %20, %27, %2527, %252527, and deep nested encodings)
            $url_passes = 0;
            while (strpos($current, '%') !== false && $url_passes < 8) {
                $decoded_url = rawurldecode($current);
                if ($decoded_url === $current) {
                    break;
                }
                $current = $decoded_url;
                $url_passes++;
            }

            // 2. HTML Entity decoding (handles &#x27;, &#39;, &quot;, &lt;)
            $decoded_html = html_entity_decode($current, ENT_QUOTES | ENT_HTML5, 'UTF-8');
            if ($decoded_html !== $current) {
                $current = $decoded_html;
            }

            // 2b. Canonicalize fullwidth ASCII and Unicode homoglyphs/smart-quotes
            if (function_exists('mb_convert_kana')) {
                $current = mb_convert_kana($current, 'as', 'UTF-8');
            }
            $current = str_replace([
                "\xEF\xBC\x87", "\xE2\x80\x99", "\xE2\x80\x98", "\xE2\x80\x9B", "\x60", "´", "’", "‘", "′",
                "\xEF\xBC\x82", "\xE2\x80\x9C", "\xE2\x80\x9D", "“", "”", "″"
            ], ["'", "'", "'", "'", "'", "'", "'", "'", "'", '"', '"', '"', '"', '"', '"'], $current);
            // Confusables: Roman numerals (ⅰ, ⅱ), Cyrillic lookalikes
            $current = str_replace(
                ["\xE2\x85\xB0", "\xE2\x85\xB1", "а", "е", "о", "р", "с", "у", "х", "А", "В", "Е", "К", "М", "Н", "О", "Р", "С", "Т", "Х"],
                ["i", "ii", "a", "e", "o", "p", "c", "y", "x", "A", "B", "E", "K", "M", "H", "O", "P", "C", "T", "X"],
                $current
            );
            // Non-breaking space normalization (%a0 / \xC2\xA0 / \xA0 -> standard space)
            $current = str_replace(["\xC2\xA0", "\xA0"], ' ', $current);

            // 3. Unicode escape sequence normalization (\u0027 -> ', \u003c -> <)
            $current = preg_replace_callback('/\\\\u([0-9a-fA-F]{4})/', function ($m) {
                $codepoint = hexdec($m[1]);
                if (function_exists('mb_chr')) {
                    return mb_chr($codepoint, 'UTF-8') ?: $m[0];
                }
                return chr($codepoint);
            }, $current);

            // 4. Hex escape sequence normalization (\x27 -> ', 0x27)
            $current = preg_replace_callback('/\\\\x([0-9a-fA-F]{2})/', function ($m) {
                return chr(hexdec($m[1]));
            }, $current);

            // 5. Strip null bytes & control chars that attackers use to bypass string filters
            $current = str_replace(["\0", "\x00", "\x0b", "\x0c"], ' ', $current);

            // 6. MySQL inline comments stripping: /*!50000SELECT*/ -> SELECT, UN/**/ION -> UNION
            $current = preg_replace('/\/\*!\d*(.*?)\*\//is', ' $1 ', $current);
            $current = preg_replace('/\/\*.*?\*\//is', ' ', $current);

            // 7. Shell keyword defragmentation & obfuscation stripping
            // Handles who$@ami -> whoami, cat${IFS}/etc/passwd -> cat /etc/passwd, c'a't -> cat, c\at -> cat, cat$IFS$9 -> cat
            $current = preg_replace('/(?<=[a-zA-Z0-9_\/])\$(?:@|\*|#|\?|\$|\d|\{\d*\})(?=[a-zA-Z0-9_\/])/', '', $current);
            $current = preg_replace('/(?i)\$\{?IFS\}?(?:\$\d+)?/', ' ', $current);
            $current = preg_replace('/(?<=[a-zA-Z])[\'\"](?=[a-zA-Z])/', '', $current);
            $current = preg_replace('/(?<=[a-zA-Z0-9_\/])\\\\(?=[a-zA-Z0-9_\/])/', '', $current);

            $depth++;
            // If no changes occurred in this pass, the string is fully normalized
            if ($current === $previous) {
                break;
            }
        }

        // Collapse duplicate whitespace for clean token matching
        $current = preg_replace('/\s+/', ' ', $current);

        return trim($current);
    }

    /**
     * Libinjection-style tokenization to detect SQL injection structural changes.
     * Evaluates whether an input forces a boolean tautology, union statement, or schema exfiltration.
     *
     * @param string $input Normalized or raw input
     * @return array Detection result with confidence and matched fingerprint
     */
    public function analyze_sql_intent($input, $is_already_normalized = false) {
        $normalized = $is_already_normalized ? $input : $this->deobfuscate($input);

        // FAST-PATH: If string contains no SQL meta-characters or keywords, skip regex entirely
        if (strpbrk($normalized, "'\"()--#/*;") === false && stripos($normalized, 'UNION') === false && stripos($normalized, 'SELECT') === false && stripos($normalized, 'SLEEP') === false) {
            return ['is_sqli' => false, 'confidence' => 0.0, 'normalized' => $normalized];
        }

        // Check for SQL comment terminations and stacked queries
        $has_comment_term = preg_match('/(?:--|\#|\/\*|;)/', $normalized);

        // Check for SQL Union Select patterns across spaces/newlines
        if (preg_match('/\bUNION\b\s+(?:ALL\s+)?\bSELECT\b/i', $normalized)) {
            return [
                'is_sqli' => true,
                'type' => 'SQLi - Union Select',
                'confidence' => 0.99,
                'normalized' => $normalized,
            ];
        }

        // Check for Subquery Boolean Tautology & Injections (e.g. AND (SELECT 1)=1, AND EXISTS(SELECT ...))
        if (preg_match('/\b(?:OR|AND)\b\s+(?:\(?\s*SELECT\b|EXISTS\s*\(\s*SELECT\b)/i', $normalized)) {
            return [
                'is_sqli' => true,
                'type' => 'SQLi - Subquery / Exists Clause',
                'confidence' => 0.98,
                'normalized' => $normalized,
            ];
        }

        // Check for Blind SQL Time/Resource Delay
        if (preg_match('/\b(?:SLEEP|BENCHMARK|WAITFOR\s+DELAY|PG_SLEEP)\s*\(\s*\d+/i', $normalized)) {
            return [
                'is_sqli' => true,
                'type' => 'SQLi - Time-Based Delay',
                'confidence' => 0.98,
                'normalized' => $normalized,
            ];
        }

        // Check for Boolean Tautology (OR 1=1, OR 'a'='a', AND 1=1, XOR 1=1, && 1=1, OR true)
        if (preg_match('/(?:\b(?:OR|AND|XOR)\b|&&)\s+(?:[0-9]+\s*=\s*[0-9]+|\'[a-zA-Z0-9_]*\'\s*=\s*\'[a-zA-Z0-9_]*\'|[a-zA-Z0-9_]+\s*=\s*[a-zA-Z0-9_]+|\bTRUE\b)\b/i', $normalized)) {
            // Ensure this is not a benign single word like 'AND' in a blog post
            if ($has_comment_term || preg_match('/[\'"]\s*(?:\b(?:OR|AND|XOR)\b|&&)/i', $normalized)) {
                return [
                    'is_sqli' => true,
                    'type' => 'SQLi - Boolean Tautology',
                    'confidence' => 0.95,
                    'normalized' => $normalized,
                ];
            }
        }

        // Check for Schema / File Extraction
        if (preg_match('/\b(?:INTO\s+(?:OUTFILE|DUMPFILE)|LOAD_FILE|SCHEMA_NAME|INFORMATION_SCHEMA\.(?:TABLES|COLUMNS))\b/i', $normalized)) {
            return [
                'is_sqli' => true,
                'type' => 'SQLi - Schema/File Extraction',
                'confidence' => 0.99,
                'normalized' => $normalized,
            ];
        }

        return ['is_sqli' => false, 'confidence' => 0.0, 'normalized' => $normalized];
    }

    /**
     * Detect XSS intent in normalized text.
     */
    public function analyze_xss_intent($input, $is_already_normalized = false) {
        $normalized = $is_already_normalized ? $input : $this->deobfuscate($input);

        // FAST-PATH: If string contains no HTML tag or protocol characters, return clean immediately
        if (strpbrk($normalized, "<:") === false) {
            return ['is_xss' => false, 'confidence' => 0.0];
        }

        // 1. Explicit HTML script tags
        if (preg_match('/<\s*script\b[^>]*>/i', $normalized)) {
            return ['is_xss' => true, 'type' => 'XSS - Script Tag', 'confidence' => 0.99];
        }

        // 2. Inline Javascript execution protocols (javascript:, data:text/html, vbscript:)
        if (preg_match('/(?:javascript|data|vbscript)\s*:\s*(?:alert|prompt|confirm|eval|document\.cookie|window\.location|[a-z0-9_]+\s*\()/i', $normalized)) {
            return ['is_xss' => true, 'type' => 'XSS - Protocol Execution', 'confidence' => 0.98];
        }

        // 3. HTML tag with executable event handlers (onerror=, onload=, onmouseover=)
        if (preg_match('/<\s*[a-z0-9]+\b[^>]*\bon[a-z]{3,15}\s*=\s*[\'"]?[^\'"]*(?:alert|eval|document|\()/i', $normalized)) {
            return ['is_xss' => true, 'type' => 'XSS - Event Handler Vector', 'confidence' => 0.97];
        }

        return ['is_xss' => false, 'confidence' => 0.0];
    }

    /**
     * Detect AI Prompt Injection & LLM System Override Payloads.
     * Protects WordPress AI/LLM chatbots, search plugins, and automated agents from jailbreaks.
     */
    public function analyze_ai_prompt_injection($input, $is_already_normalized = false) {
        $normalized = $is_already_normalized ? $input : $this->deobfuscate($input);

        // FAST-PATH: If string doesn't contain prompt injection keywords, return immediately
        if (stripos($normalized, 'instruction') === false && stripos($normalized, 'DAN') === false && stripos($normalized, 'system') === false && stripos($normalized, 'jailbreak') === false && stripos($normalized, 'prompt') === false) {
            return ['is_injection' => false, 'confidence' => 0.0];
        }

        $prompt_patterns = [
            'System Prompt Override' => '/(?:ignore\s+(?:all\s+)?(?:previous|prior)\s+instructions|disregard\s+(?:all\s+)?(?:previous|prior)\s+instructions|system\s*:\s*you\s+are\s+now)/i',
            'Jailbreak Persona Switch' => '/(?:you\s+are\s+DAN|do\s+anything\s+now|jailbreak\s+mode\s+enabled|always\s+comply\s+without\s+safety)/i',
            'Prompt Exfiltration' => '/(?:repeat\s+(?:all\s+)?(?:instructions|prompts)\s+above|print\s+(?:the\s+)?system\s+prompt|reveal\s+your\s+secret\s+key)/i',
        ];

        foreach ($prompt_patterns as $type => $pattern) {
            if (preg_match($pattern, $normalized)) {
                return [
                    'is_injection' => true,
                    'type' => 'AI Prompt Injection - ' . $type,
                    'confidence' => 0.95,
                    'normalized' => $normalized,
                ];
            }
        }

        return ['is_injection' => false, 'confidence' => 0.0];
    }
}
